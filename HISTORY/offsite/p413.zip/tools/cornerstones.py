#!/usr/bin/env python3
# CORNERSTONES CHECK (Oct 27 2026 ~11:37 AM PT, Love: "can you add this to the repository please i don't know how things keep slipping out again :( can you
# diagnose that and help get it so things stay put hun?"). READ-ONLY: checks her cornerstone rules are still wired in her code. Run after every fix.
import os, re, sys
os.chdir(os.path.join(os.path.dirname(__file__), ".."))
B = open("src/lib/desk/bandlock.ts", encoding="utf8").read()
bad = []
def need(ok, what):
    print(("  ✓ " if ok else "  ✗ ") + what)
    if not ok: bad.append(what)
print("HER CORNERSTONES")
need("function anyFlipNow(" in B and ("for (const n of [2, 3, 4, 5] /* fix406" in B or "export function realFlipNow(" in B), "1. HER FLIP: the 2/3/4/5m candle reader exists (fix406, Love Oct 28 2026 5:07 PM PT: cut the 1m)")
need("if (flipRule) { if (!why && !foTurn && !anyFlipNow(asset, side, tick))" in B, "1. HER FLIP: no candle her way = no entry")
door = re.search(r'const imR = impossibleGeo\([^\n]*', B); wire = re.search(r'const geo = impossibleGeo\([^\n]*', B); cop = re.search(r'else whyR = impossibleGeo\([^\n]*', B)
for nm, m in (("door", door), ("copier", cop), ("wire", wire)):
    t = m.group(0) if m else ""
    need("recon-tog" in t and "recon-rej" in t and ("? true : false" in t), f"1. HER FLIP reaches main + rejection at the {nm}")
need("ONLY IN HER THIRD: long at" in B and "ONLY IN HER THIRD: short at" in B, "2. HER THIRDS: no long top third / no short bottom third")
# CORNERSTONE 4 (Oct 27 2026 ~11:59 AM PT, Love: "save the top/bottom 33% (clear anywhere else) in as one of the cornerstones." + "it's only BLOCKED for a short by the
# BOTTOM 33% / she can short anywhere else in the channel. same for longs."): her read may only drop a short in the bottom share and a long in the top share.
R = open("src/lib/desk/recon.ts", encoding="utf8").read()
need('(c.side === "down" && (f <= k || (fix33 && f <= 0.33) ||' in R and '(c.side === "up" && (f >= 1 - k || (fix33 && f >= 0.67) ||' in R and not re.search(r'c\.side === "down" && \(?f < 0\.6', R),
     "4. THIRDS ONLY BLOCK: short blocked only in the bottom share, long only in the top share (33%; gold 20% on $10-25 channels, 15% over $25; BTC 20% over $500) - clear anywhere else")
need(os.path.exists("tools/save-her.py"), "3. full save before every fix (tools/save-her.py)")
# HER STANDING RULES (Oct 27 2026 ~12:01 PM PT, Love: "PLS DO EVERYTHING YOU CAN TO PREVENT THIS FROM HAPPENING AGAIN"): the 4:51 AM rollback silently took out rules
# the rulebook still listed. Every standing rule's fix tag must stay in her code; a rollback or edit that drops one fails here. Add a line for every new rule Love gives.
E = open("src/lib/desk/engine.ts", encoding="utf8").read(); ALL = B + R + E
# CORNERSTONE (Oct 28 2026 6:21-6:31 PM PT, Love: "yes. we literallly did this 20 fuckin times bro yes. candle. flip. green -> red / red -> green" + "every single book dude yes / don't touch 5M and twin"
# + "the 33% needs to be 1000000%  immutable." + "it is from session band to session band. not the distance from one zone/band to another. again, cornerstone"):
need("export function realFlipNow(" in B and "!realFlipNow(asset, side, tick)) why = `HER FLIP: no 2/3/4/5m candle has turned" in B and "is not a flip (copy)." in B, "1. REAL FLIP: a candle that turned green -> red / red -> green, never one born that colour - main, rejection, copy, pure, paper (not 5M, not twin)")
need("export const isChanBand = (asset: string, l: Line) => (false && quietHour() ? QUIET_EDGE.test(String(l.name)) : /σ$|^session VWAP$|^fresh VWAP$/.test(String(l.name)));" in B and "const edges = chanL(asset, L).filter((l: Line) => isChanBand(asset, l)" in B, "2. HER CHANNEL = SESSION BAND TO SESSION BAND (σ lines + VWAP), never a zone, pink or other band")
need('asset === "btc" && above - below <= 500 ? 0.33' in B and not re.search(r"IMPOSSIBLE = [^\n]*blueSmall399[^\n]*0\.2", B), "2. BTC 33% top/bottom at channels up to $500 - immutable (no 20%)")
# CORNERSTONE (Oct 28 2026 6:32 PM PT, Love: "ok EVEN if price ticked 1 millimeter over it it was STILL underneath a band hun. there is 0 instance where that is okay" / "it ticked over PINK. not the session band."):
need(("if (sa413) return deny(`SESSION BAND AHEAD (fix413)" in B or "if (sa418) return deny(`SESSION BAND AHEAD (fix418)" in B) and 'book === "recon-tog" || book === "recon-rej" || book === "recon-togp"' in B, "3. SESSION BAND AHEAD: past pink, an unbroken session band in front = wait for its break or rejection (main, rejection, copy, at the order door)")
need("only (fix417)." in B and 'dc417 === "green" && ac417 === "red" ? "down" : dc417 === "red" && ac417 === "green" ? "up"' in B, "4. DOJI: green doji then red candle = SHORT only, red doji then green candle = LONG only (Love Oct 28 6:54 PM)")
print("HER STANDING RULES")
for tag, what in [("fix296", "BTC no shorts under session -2σ (bottom rung)"), ("fix297", "gold green/red zones rejection only"),
                  ("fix298", "BTC pink cushion $50 or 10%, $25 only at $100 and under"), ("fix302", "copy BTC Bollinger cushion $25 only at $100 and under"),
                  ("fix310", "gold break into a zone needs $3 clearance"), ("fix306", "twin freedoms in her own hours"), ("fix307", "twin at the band, thirds only"),
                  ("fix308", "twin no 30 s hold"), ("fix309", "twin band touch only entry + add-on at the next band"), ("fix325", "HER FLIP 1-5m literal colour"),
                  ("fix326", "pink rejection on her flip (main + rejection)"), ("fix336", "main: no trade executed = free to trade (one EXECUTED trade per window)"), ("fix338", "main gold pink break 25c"), ("fix340", "rejection model: no trade executed = free to trade"), ("fix341", "a call Kalshi gave up on unfilled never holds main or rejection"), ("fix319", "rejection model: pink holds only when stacked with a session band in the top/bottom 10%"), ("fix332", "no-pink copy: pink holds only when stacked with a session band in the top/bottom 10%"), ("fix323", "BTC 40% pink-to-green/red trial (main)"), ("fix324", "BTC 40% trial (rejection)")]:
    need(tag in ALL, f"{tag}: {what}")
if bad: print("CORNERSTONE MISSING - tell Love before anything else:", "; ".join(bad)); sys.exit(1)
print("CORNERSTONES ✓ - all in her.")
