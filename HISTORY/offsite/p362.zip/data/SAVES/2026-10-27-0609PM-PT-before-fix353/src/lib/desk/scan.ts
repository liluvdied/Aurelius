import { fetchCandles } from "./candles";
import { goldBookClosed } from "./hours";
import { fetchSeriesMarket } from "./kalshi";
import { buildSetup } from "./setup";
import {
  ASSET_META,
  DEFAULT_SETTINGS,
  type AssetId,
  type AssetSnapshot,
  type DeskSettings,
  type DeskSnapshot,
  type Pattern,
} from "./types";
import { noteEvent } from "./memory";
import { bandInWay, closeByBand, brokeUnder, closedThrough } from "./auto";
import { readySpine } from "./spine-ready";
import { computeVwap, bandRun, detectPattern, resample5m, sortAsc } from "./vwap";
import { chartCandles } from "./tv";
import { navFor } from "./nav";
import { quoteTick, feedHealth } from "./quotes";

const EMPTY_PATTERN: Pattern = {
  kind: "none",
  side: null,
  band: null,
  quality: 0,
  label: "No band interaction",
  reasons: ["Waiting on tape."],
};

type Cache = { at: number; snap: DeskSnapshot };
let cache: Cache | null = null;
let scanFlight: Promise<DeskSnapshot> | null = null;
const KALSHI_BACK = Date.parse("2026-09-24T09:00:00Z");
const TTL = 1500; // MAGLEV (Oct 14 ~7:20 AM PT): was 5000; a background warmer (engine.ts) keeps it fresh

// MAGLEV nav (Oct 14 ~7:40 AM PT): the nav frames (5 chart reads) took ~3 s and held every BTC scan. The last result under
// 15 s old is used at once while a fresh one is read in the background (each frame keeps its own refresh clock in nav.ts).
const navMem: Record<string, { at: number; v: any }> = {};
const navFly: Record<string, Promise<any> | null> = {};
function navQuick(asset: string): Promise<any> {
  const kick = () => {
    if (navFly[asset]) return navFly[asset]!;
    navFly[asset] = navFor(asset).then((v) => { if (v) navMem[asset] = { at: Date.now(), v }; return v; }).catch(() => null).finally(() => { navFly[asset] = null; });
    return navFly[asset]!;
  };
  const m = navMem[asset];
  if (m && Date.now() - m.at < 15000) { void kick(); return Promise.resolve(m.v); }
  return kick();
}
async function scanAsset(asset: AssetId, settings: DeskSettings): Promise<AssetSnapshot> {
  const meta = ASSET_META[asset];
  // MAGLEV (Oct 14 ~7:35 AM PT): the market, the candles, gold's 5-minute band bars and the nav frames are all read at the
  // same time. They used to run one after another (market+candles, then gold's 5m bars, then nav), 7-10 s per full scan.
  const T0 = Date.now();
  const navP = asset === "btc" || asset === "gold" ? navQuick(asset) : Promise.resolve(null);
  const g5P = asset === "gold" ? chartCandles("gold5").catch(() => null) : Promise.resolve(null);
  const [marketRes, tapeRes] = await Promise.allSettled([
    fetchSeriesMarket(meta.series),
    fetchCandles(asset),
  ]);
  const T1 = Date.now();

  let market = marketRes.status === "fulfilled" ? marketRes.value : null;
  const tape = tapeRes.status === "fulfilled" ? tapeRes.value : null;
  const candles = tape ? sortAsc(tape.candles) : [];
  const last = candles[candles.length - 1];
  // GOLD SPOT (Oct 7, Love: "she longed into a band it hadn't broken thru yet"). The gold 15-minute chart needs 8 bars of
  // the new session before it loads, so every day from the 2 PM PT break until ~4:45 PM PT it served its last pre-break
  // close (4110.45 for 111 min today; 4164.54 / 4140.52 on earlier days). The band-at-target check, the exits' "near the
  // strike" test and her DNA all read that frozen price. Gold's spot is now the live TVC 1-minute candle her lines use.
  let liveGold: number | null = null;
  const navEarly = await navP;
  const T2 = Date.now();
  // Oct 14 ~2:20 PM PT (Love: "she's definitely slow... why"): BTC's price froze at $81,646.74 for 15+ min because its chart
  // read kept failing and the last good bars were reused. BTC now takes its price from the live 1-minute nav candle too (the
  // same Pepperstone chart), like gold; the chart bars stay the fallback.
  if (asset === "gold" || asset === "btc") {
    try {
      liveGold = (await import("./nav")).liveClose(asset);
    } catch {
      liveGold = null;
    }
  }
  // Second live source (Oct 14 ~2:20 PM PT): the pivot books' own 1-minute chart read (read every ~1 s around each minute
  // turn), used when the nav read is older than 20 s. Then the chart bars.
  let pivLive: number | null = null;
  if (liveGold == null && (asset === "gold" || asset === "btc")) {
    try {
      const pc = (globalThis as any).__pivBars?.[asset];
      const pl = pc?.bars?.[pc.bars.length - 1];
      if (pl && Date.now() - Number(pc.at) < 20000 && Date.now() / 1000 - Number(pl.t) < 130 && Number(pl.c) > 0) pivLive = Number(pl.c);
    } catch {}
  }
  // ONE ENGINE FOR PAPER 24/7 (Oct 19 ~5:50 PM PT, Love: "i do want em quick unilaterally... just new engine"): PAPER's setups now read the
  // live quote stream (under 3 s old, feed healthy) - the same price the pivot/break lanes decide on - instead of the 1-minute live-candle
  // read (up to 20 s old). The nav read, the pivot read and the chart bars stay the fallbacks, in that order. Setups and rules unchanged.
  let fastSpot: number | null = null;
  if (asset === "gold" || asset === "btc") {
    try { const q = quoteTick(asset); if (q && q.c > 0 && Date.now() - q.at <= 3000 && feedHealth(asset).ok) fastSpot = q.c; } catch { fastSpot = null; }
  }
  const spot = fastSpot ?? liveGold ?? pivLive ?? last?.c ?? 0;

  const c5 = candles.length ? resample5m(candles) : [];
  const recent = candles.slice(-60);
  const onChart = asset === "gold" || asset === "silver" || asset === "btc";
  // Bands = Love's TradingView VWAP (session, hlc3, volume-weighted). Gold bands use 5-minute bars.
  let bandCandles = candles;
  if (asset === "gold") {
    try {
      const g5 = (await g5P) ?? (await chartCandles("gold5"));
      if (g5.candles.length >= 2) bandCandles = sortAsc(g5.candles); // Oct 7: young session loads from bar 2 (tv.ts)
    } catch {
      // fall back to the 15-minute bars
    }
  }
  const vwap1m = onChart
    ? (bandCandles.length ? computeVwap(bandCandles) : null)
    : (recent.length ? computeVwap(recent) : null);
  const vwap5m = c5.length ? computeVwap(c5.slice(-12)) : null;
  const nav = navEarly;
  try { ((globalThis as any).__scanT ||= {})[asset] = { mk: T1 - T0, nav: T2 - T0, all: Date.now() - T0 }; } catch {}
  let pattern1m = candles.length ? detectPattern(candles, vwap1m) : EMPTY_PATTERN;
  const pattern5m = c5.length ? detectPattern(c5, vwap5m) : EMPTY_PATTERN;
  const primeLooks: { label: string; side: "up" | "down" }[] = [];
  const remember = (row?: { label?: string; side?: string | null } | null) => {
    if ((row?.side === "up" || row?.side === "down") && row.label) primeLooks.push({ label: row.label, side: row.side });
  };
  remember(pattern1m);
  remember(pattern5m);

  const kalshiLive =
    Boolean(market?.closeTime) &&
    (market!.status === "active" || market!.status === "open") &&
    Date.parse(market!.closeTime) > Date.now();
  if (asset === "btc" && !kalshiLive && Date.now() < KALSHI_BACK) {
    try {
      const poly = await import("./poly-live.server");
      const stand = await poly.btcStandIn();
      if (stand) market = stand;
    } catch {
      // Kalshi is dark and Polymarket had no window. Try again next pass.
    }
  }

  const closeMs = market?.closeTime ? Date.parse(market.closeTime) : NaN;
  const secondsLeft = Number.isFinite(closeMs)
    ? Math.max(0, Math.floor((closeMs - Date.now()) / 1000))
    : 0;
  if (vwap1m && spot > 0) {
    const broke = brokeUnder(candles, vwap1m.vwap, vwap1m.stdev, spot, asset);
    const crossed = closedThrough(candles, vwap1m.vwap, vwap1m.stdev, spot, asset);
    const opened = closeByBand(asset, spot, vwap1m.vwap, vwap1m.stdev);
    const strike = market?.target ?? 0;
    const spine = readySpine(asset, candles, vwap1m.vwap, vwap1m.stdev, spot, strike);
    remember(broke);
    remember(crossed);
    remember(opened);
    remember(spine);
    const long = crossed?.side === "up" ? crossed : opened?.side === "up" ? opened : null;
    const longCross = Boolean(long) && spot < vwap1m.vwap && strike > vwap1m.vwap;
    if (asset === "btc" || asset === "gold" || asset === "silver") pattern1m = spine ?? EMPTY_PATTERN;
    else if (spine) pattern1m = spine;
    else if (long && !longCross) pattern1m = long;
    else if (broke?.side) pattern1m = broke;
    else if (crossed?.side) pattern1m = crossed;
    else if (opened?.side) pattern1m = opened;
    if (pattern1m.side && bandInWay(pattern1m.side, spot, vwap1m.vwap, vwap1m.stdev, asset)) pattern1m = EMPTY_PATTERN;
  }
  const target = market?.target ?? null;
  const delta = target != null && spot > 0 ? spot - target : null;
  const deltaBps = delta != null && target ? (delta / target) * 10000 : null;
  const live =
    Boolean(market) &&
    (market!.status === "active" || market!.status === "open") &&
    secondsLeft > 0;

  let setup = buildSetup({
    asset,
    market,
    pattern1m,
    pattern5m,
    secondsLeft,
    delta,
    settings,
  });

  if (setup && setup.pattern.kind !== "tap_reject" && (asset === "btc" || asset === "gold")) {
    const run = bandRun(candles, vwap1m);
    if (run.violent && run.bands < 2) {
      const name = asset === "btc" ? "Bitcoin" : "Gold";
      const way = run.direction === "down" ? "selling" : "buying";
      const reason = `${name} is ${way} through the bands. Letting it clear two before an entry.`;
      setup = {
        ...setup,
        watchOnly: true,
        reasons: [reason, ...setup.reasons],
      };
      if (market?.ticker) {
        noteEvent({
          id: "knife-wait",
          asset,
          ticker: market.ticker,
          note: `${reason} ${run.bands} bands so far.`,
        });
      }
    }
  }

  if (asset === "gold" && goldBookClosed() && setup) {
    setup = {
      ...setup,
      watchOnly: true,
      localConviction: 0,
      reasons: ["Gold book is closed 2:00–3:00 PM PT. No new fills until 3."],
    };
  }

  const sparkSrc = candles.slice(-32);
  const spark = sparkSrc.map((c) => c.c).filter((n) => n > 0);
  const sparkVwap = sparkSrc.map(() => vwap1m?.vwap ?? spot);
  const lastPrints = candles.slice(-8).map((c) => ({
    t: c.t,
    o: c.o,
    h: c.h,
    l: c.l,
    c: c.c,
  }));

  return {
    asset,
    product: tape?.product ?? "tape unavailable",
    spot,
    close: last?.c ?? spot,
    target,
    delta,
    deltaBps,
    market,
    vwap1m,
    vwap5m,
    pattern1m,
    pattern5m,
    primeLooks,
    setup,
    spark,
    sparkVwap,
    lastPrints,
    secondsLeft,
    settlement: secondsLeft > 0 && secondsLeft <= 60,
    live,
    nav,
  };
}

const IDLE: AssetSnapshot = {
  asset: "btc",
  product: "",
  spot: 0,
  close: 0,
  target: null,
  delta: null,
  deltaBps: null,
  market: null,
  vwap1m: null,
  vwap5m: null,
  pattern1m: EMPTY_PATTERN,
  pattern5m: EMPTY_PATTERN,
  setup: null,
  spark: [],
  sparkVwap: [],
  lastPrints: [],
  secondsLeft: 0,
  settlement: false,
  live: false,
};

export async function scanDesk(settings: DeskSettings = DEFAULT_SETTINGS): Promise<DeskSnapshot> {
  if (cache && Date.now() - cache.at < TTL) return cache.snap;
  // MAGLEV (Oct 14 ~7:25 AM PT): never make the main loop wait on the network. With a snapshot under 12 s old, hand it back
  // at once and refresh in the background (the warmer in engine.ts asks every second, so it is normally 1-3 s old).
  if (cache && Date.now() - cache.at < 12000) {
    if (!scanFlight) scanFlight = scanDeskNow(settings).finally(() => { scanFlight = null; });
    return cache.snap;
  }
  if (scanFlight) return scanFlight;
  scanFlight = scanDeskNow(settings).finally(() => {
    scanFlight = null;
  });
  return scanFlight;
}

async function scanDeskNow(settings: DeskSettings): Promise<DeskSnapshot> {
  const t0 = Date.now();
  const [btc, gold, silver] = await Promise.allSettled([
    scanAsset("btc", settings),
    scanAsset("gold", settings),
    scanAsset("silver", settings),
  ]);

  const errors: string[] = [];
  const assets = {
    btc: btc.status === "fulfilled" ? btc.value : { ...IDLE, asset: "btc" as const },
    gold: gold.status === "fulfilled" ? gold.value : { ...IDLE, asset: "gold" as const },
    silver: silver.status === "fulfilled" ? silver.value : { ...IDLE, asset: "silver" as const },
  };
  if (btc.status === "rejected") errors.push(`BTC: ${String(btc.reason)}`);
  if (gold.status === "rejected") errors.push(`GOLD: ${String(gold.reason)}`);
  if (silver.status === "rejected") errors.push(`SILVER: ${String(silver.reason)}`);

  const snap: DeskSnapshot = {
    at: new Date().toISOString(),
    assets,
    error: errors.length ? errors.join(" · ") : undefined,
  };
  cache = { at: Date.now(), snap };
  // MAGLEV pace (Oct 14): how long each full scan takes and when it landed, for the speed check.
  try {
    const fs = await import("node:fs");
    fs.writeFileSync(`${process.cwd()}/data/scan-pace.json`, JSON.stringify({ at: snap.at, ms: Date.now() - t0, parts: (globalThis as any).__scanT || null }));
  } catch {}
  return snap;
}
