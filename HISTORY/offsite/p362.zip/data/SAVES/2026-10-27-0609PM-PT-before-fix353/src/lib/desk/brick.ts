// BRICK (Claude, 2026-10-02). Love: "rewrite the entry logic from the ground up — brick, not matchsticks."
// Written from scratch. It does NOT use Grok's setup.ts / auto.ts / spine-ready.ts / bandInWay. It reads
// only her own lines: the session VWAP bands on her chart (17:00 ET, ±0.5σ steps), the purple nav
// centers on 5m / 10m / 15m, and for BTC the nav upper / lower (Bollinger) lines.
//
// The audit behind it (scripts/wrong-side-audit.py, every Kalshi BTC/gold trade since Sep 21, 829 trades):
//   • 617 entries had a line right in front of them (long under one / short over one): 80% of all
//     dollars lost (-$4,074 of -$5,104). The worst: BTC with a purple/Bollinger line within $100
//     (-$484 net), BTC with any line within $25 (-$410), gold with a line $0.75-2.50 ahead (-$223).
//   • 156 entries still had to cross the strike to win: 29-38% winners, -$462 net.
//   Blocking exactly those leaves 245 trades: 163W-82L, +$423 (in-sample; paper proves it forward).
//
// ENTRIES (a closed 5-minute candle decides, never a wiggle):
//   REJECTION: the last closed 5m candle wicked through a line and closed back → trade away from it.
//   BREAK:     the last closed 5m candle closed through a line the candle before closed on the other
//              side of, and the latest 1m close is still through it → trade the break.
// BRICK GATES (all must pass, no exceptions, no "precedence" overrides):
//   1. (Love, 10:30 AM) The road to the strike is clear: no session band, VWAP or nav line sits
//      between price and the strike. Price does NOT have to be through the strike already.
//   2. Nothing in front: BTC no purple/Bollinger line within $100 and no session band within $25 in
//      the trade's direction; gold no line $0.75-$2.50 in the trade's direction.
//   3. 1.38x-2.5x (BTC 1.38x-1.8x), more than 2 minutes left, one trade per window, no conflict
//      (a long and a short signal at once = no trade).
// Paper only. It books on the night ledger as BRICK and never sends an order.
import { writeFileSync } from "node:fs";
import { join } from "node:path";
import type { AssetSnapshot } from "./types";
import { brickCleanConsider, brickConsider, diamondConsider, setBookTag, soleConsider, twinConsider } from "./nightbook";
import { dnaLog, dnaNow, dnaNowFrame } from "./dna";

type Line = { name: string; kind: "session" | "purple" | "bollinger"; price: number; rank: number };
type Signal = { side: "up" | "down"; label: string; line: Line };

export function herLines(a: AssetSnapshot, asset: "btc" | "gold"): Line[] {
  const out: Line[] = [];
  const vw = a.vwap1m?.vwap ?? 0;
  const sd = a.vwap1m?.stdev ?? 0;
  if (vw > 0 && sd > 0) {
    for (let k = -6; k <= 6; k += 1) out.push({ name: k === 0 ? "session VWAP" : `${k > 0 ? "+" : ""}${k / 2}σ`, kind: "session", price: vw + (k / 2) * sd, rank: k === 0 ? 3 : 1 });
  }
  const nav = a.nav;
  for (const [key, label, rank] of [["m5", "5m", 4], ["m10", "10m", 5], ["m15", "15m", 6]] as const) {
    const f = nav?.[key];
    if (!f) continue;
    out.push({ name: `${label} purple`, kind: "purple", price: f.c, rank });
    if (asset === "btc") {
      out.push({ name: `${label} upper`, kind: "bollinger", price: f.up, rank: rank - 1 });
      out.push({ name: `${label} lower`, kind: "bollinger", price: f.dn, rank: rank - 1 });
    }
  }
  return out.filter((l) => Number.isFinite(l.price) && l.price > 0);
}

/** Gate 2: the line in front of the trade, or null when the road is clear. */
export function lineInFront(asset: "btc" | "gold", side: "up" | "down", spot: number, lines: Line[]): Line | null {
  for (const l of lines) {
    const ahead = side === "up" ? l.price - spot : spot - l.price;
    if (!(ahead > 0)) continue;
    if (asset === "btc") {
      if ((l.kind === "purple" || l.kind === "bollinger") && ahead <= 100) return l;
      if (l.kind === "session" && ahead <= 25) return l;
    } else if (ahead > 0.75 && ahead <= 2.5) return l;
  }
  return null;
}

function signals(a: AssetSnapshot, lines: Line[]): Signal[] {
  const nav = a.nav;
  const bar = nav?.bar5m;
  const prev = nav?.prev5m;
  const c1 = nav?.close1m;
  if (!bar || !(bar.c > 0)) return [];
  const out: Signal[] = [];
  for (const l of lines) {
    const L = l.price;
    if (bar.l < L && bar.c > L && bar.o >= L) out.push({ side: "up", label: `BRICK rejection up off the ${l.name}`, line: l });
    else if (bar.h > L && bar.c < L && bar.o <= L) out.push({ side: "down", label: `BRICK rejection down off the ${l.name}`, line: l });
    else if (prev != null && prev < L && bar.c > L && (c1 == null || c1 > L)) out.push({ side: "up", label: `BRICK 5m close above the ${l.name}`, line: l });
    else if (prev != null && prev > L && bar.c < L && (c1 == null || c1 < L)) out.push({ side: "down", label: `BRICK 5m close below the ${l.name}`, line: l });
  }
  return out.sort((x, y) => y.line.rank - x.line.rank);
}

// BRICK · PUSH v2 (Love, Oct 6 ~11:45 PM PT: "a push thru purple is clear to enter, the only thing we'd do differently is
// instead of entering when shes under or above the purple band by default, she waits to see how it behaves off the purple
// band first. if it goes up, taps, rejects and pushes off, THEN she enters, but if price goes up to the band and breaks
// thru, she enters"). Paper twin "brickp". v1 (Oct 6 ~12:30 PM, waited for a retest after a break) is replaced.
//   - BRICK breaking THROUGH a purple (5m close through it), and BRICK's 5m rejections: entered at once, like BRICK.
//   - Any other BRICK signal with an unbroken purple close in front of it (within 0.5 sd of price on the trade's side):
//     no entry yet. She watches that purple for the rest of the window:
//       * price gets there and a 1m candle closes THROUGH it (0.1 sd beyond)      -> enter WITH the break;
//       * price taps it (within 0.15 sd) and a later 1m candle closes back off it
//         (0.1 sd away on the near side)                                         -> enter the REJECTION side;
//       * neither before the last 2 minutes                                      -> no trade.
//   - No purple close in front: entered like BRICK.
//   - Every BRICK gate is re-checked at the moment she enters (nothing between price and the strike, her 25% channel rule,
//     1.38x-1.8x BTC / 2.5x gold). BRICK's exits. Paper only until Love turns its RUN on. Log: data/brick-push-log.jsonl.
type PushWait = { ticker: string; name: string; approach: 1 | -1; label: string; armedAt: number; touchedAt: number };
const gp = globalThis as unknown as { __brickPush2?: Record<string, PushWait> };
function pushLog(x: Record<string, unknown>) {
  try {
    void import("node:fs").then((fs) => fs.appendFileSync(join(process.cwd(), "data", "brick-push-log.jsonl"), JSON.stringify({ at: new Date().toISOString(), ...x }) + "\n"));
  } catch {
  }
}
function pushEnter(id: "btc" | "gold", a: AssetSnapshot, lines: Line[], side: "up" | "down", price: number, label: string): string | null {
  const m = a.market;
  if (!m) return "no market";
  const target = a.target;
  if (target == null || !(target > 0)) return "no strike";
  const mustCross = side === "up" ? target > price : target < price;
  const wall = mustCross ? lines.find((x) => x.price > Math.min(price, target) && x.price < Math.max(price, target)) : undefined;
  if (wall) return `the ${wall.name} sits between price and the strike`;
  const dna = dnaNow(id, side, price, target, "chan");
  if (dna) return `25% channel rule: ${dna}`;
  const ask = side === "up" ? m.yesAsk : m.noAsk;
  if (!(ask > 0.02 && ask < 0.98)) return "no ask";
  const mult = 1 / ask;
  if (mult < 1.38 || mult > (id === "btc" ? 1.8 : 2.5)) return `${mult.toFixed(2)}x outside 1.38-${id === "btc" ? 1.8 : 2.5}x`;
  twinConsider("brickp", { ticker: m.ticker, side, ask, label }, id, { spot: price, vwap: a.vwap1m?.vwap ?? null, sd: a.vwap1m?.stdev ?? null, nav: a.nav ?? null, target });
  return null;
}
function pushTick(id: "btc" | "gold", a: AssetSnapshot, lines: Line[]) {
  const pend = (gp.__brickPush2 ||= {});
  const p = pend[id];
  const m = a.market;
  if (!p || !m) return;
  if (p.ticker !== m.ticker || !(a.secondsLeft > 120)) {
    pushLog({ asset: id, ticker: p.ticker, line: p.name, status: "expired", why: "price never broke or rejected the purple before the last 2 minutes" });
    delete pend[id];
    return;
  }
  const l = lines.find((x) => x.name === p.name);
  const sd = Number(a.vwap1m?.stdev) || 0;
  if (!l || !(sd > 0)) return;
  const L = l.price;
  const nv = a.nav as unknown as { close1m?: number; close1mAt?: number } | null | undefined;
  const c1 = Number(nv?.close1m) || 0;
  const c1At = (Number(nv?.close1mAt) || 0) * 1000;
  const k = p.approach; // +1: price below the purple, coming up; -1: above it, coming down
  if (!p.touchedAt && a.spot > 0 && k * (L - a.spot) <= 0.15 * sd) p.touchedAt = Date.now();
  if (!(c1 > 0) || !(c1At > p.armedAt)) return;
  let side: "up" | "down" | null = null;
  let label = "";
  if (k * (c1 - L) >= 0.1 * sd) {
    side = k > 0 ? "up" : "down";
    label = `BREAK ${side} through the ${p.name} (waited at the band)`;
  } else if (p.touchedAt && c1At > p.touchedAt && k * (L - c1) >= 0.1 * sd) {
    side = k > 0 ? "down" : "up";
    label = `REJECT ${side} off the ${p.name} (waited at the band)`;
  }
  if (!side) return;
  const why = pushEnter(id, a, lines, side, c1, label);
  pushLog({ asset: id, ticker: p.ticker, line: p.name, status: why ? "skipped" : "entered", side, label, why, waitedSec: Math.round((Date.now() - p.armedAt) / 1000) });
  delete pend[id];
}
function pushOn(id: "btc" | "gold", a: AssetSnapshot, s: Signal, ask: number, bands: Record<string, unknown>, lines: Line[], spot: number) {
  const m = a.market;
  if (!m) return;
  const brokePurple = s.line.kind === "purple" && /5m close (above|below)/.test(s.label);
  const rejection = /rejection/.test(s.label);
  const sd = Number(a.vwap1m?.stdev) || 0;
  const dir = s.side === "up" ? 1 : -1;
  const front = !brokePurple && !rejection && sd > 0
    ? lines.filter((l) => l.kind === "purple" && dir * (l.price - spot) > 0 && dir * (l.price - spot) <= 0.5 * sd).sort((x, y) => Math.abs(x.price - spot) - Math.abs(y.price - spot))[0]
    : undefined;
  if (!front) {
    twinConsider("brickp", { ticker: m.ticker, side: s.side, ask, label: s.label }, id, bands);
    return;
  }
  const pend = (gp.__brickPush2 ||= {});
  if (pend[id]?.ticker === m.ticker) return;
  pend[id] = { ticker: m.ticker, name: front.name, approach: dir as 1 | -1, label: s.label, armedAt: Date.now(), touchedAt: 0 };
  pushLog({ asset: id, ticker: m.ticker, line: front.name, status: "watching", why: `${s.label}, but the ${front.name} (${front.price.toFixed(2)}) is ${Math.abs(front.price - spot).toFixed(2)} in front: waiting to see if it breaks or rejects` });
}

export type BrickLook = { asset: string; at: string; spot: number; target: number | null; signal: string | null; side: string | null; verdict: string };
const g = globalThis as unknown as { __brickLook?: Record<string, BrickLook> };

/** Every desk tick: look for a BRICK entry on BTC and gold; book it on paper if every gate passes. */
export function brickTick(assets: Record<string, AssetSnapshot> | null | undefined) {
  if (!assets) return;
  const looks = g.__brickLook || (g.__brickLook = {});
  setTimeout(brickWrite, 0);
  for (const id of ["btc", "gold"] as const) {
    const a = assets[id];
    const m = a?.market;
    if (!a || !m?.ticker || !(a.spot > 0)) continue;
    const spot = a.nav?.close1m && a.nav.close1m > 0 ? a.nav.close1m : a.spot;
    const look: BrickLook = { asset: id, at: new Date().toISOString(), spot, target: a.target, signal: null, side: null, verdict: "no 5m signal" };
    looks[id] = look;
    const lines = herLines(a, id);
    try {
      pushTick(id, a, lines);
    } catch {
    }
    // PUSH ENTRIES, BRICK · CLEAN only (Love, Oct 4 ~12:15 AM PT: "the candles flip on both sides of the purple band... they
    // reject or break off the session ones, THOSE are the real entries... a push off the purple band should be the entry").
    // Last 1m close touched a session band (within 0.15 sd) and this 1m close pushed 0.1 sd+ away from it: trade the push.
    // A push off a purple counts only when a session band sits with it (within 0.25 sd). Minute tape, Oct 2-4: pushes off
    // session bands won 71-74% (+$129 to +$183 at $22 held to the bell). Every rule still applies (25% rule, no band in the way).
    try {
      const nv = a.nav;
      const c1 = Number(nv?.close1m) || 0;
      const p1 = Number(nv?.prev1m) || 0;
      const sdP = Number(a.vwap1m?.stdev) || 0;
      if (c1 > 0 && p1 > 0 && sdP > 0 && a.secondsLeft > 180 && a.target != null && a.target > 0) {
        const sessL = lines.filter((l) => l.kind === "session");
        // Love, Oct 4 ~12:25 AM PT: "a push off the purple band is good enough" -> any purple counts, no session band needed.
        const purL = lines.filter((l) => l.kind === "purple");
        let push: { side: "up" | "down"; name: string } | null = null;
        for (const l of [...sessL, ...purL]) {
          if (Math.abs(p1 - l.price) > 0.15 * sdP) continue;
          const d = c1 - l.price;
          if (Math.abs(d) < 0.1 * sdP) continue;
          push = { side: d > 0 ? "up" : "down", name: l.name };
          break;
        }
        if (push) {
          const askP = push.side === "up" ? m.yesAsk : m.noAsk;
          const multP = askP > 0 ? 1 / askP : 0;
          if (multP >= 1.37 && multP <= (id === "btc" ? 1.8 : 2.5) && !dnaNow(id, push.side, c1, a.target, "chan")) {
            brickCleanConsider({ ticker: m.ticker, side: push.side, ask: askP, label: `PUSH ${push.side === "up" ? "up" : "down"} off the ${push.name}` }, id, { spot: c1, vwap: a.vwap1m?.vwap ?? null, sd: sdP, nav: a.nav ?? null, target: a.target });
          }
        }
      }
    } catch {
    }
    const sig = signals(a, lines);
    if (!sig.length) continue;
    const sides = new Set(sig.map((s) => s.side));
    // PURPLE CHOP (Love, Oct 3 ~10:15 PM PT: "it flips over and over... it does that at the purple band. if it leaves
    // the purple band and breaks thru the next one, clear to engage"). When the candle argues both ways, set aside the
    // purple signals; if what's left all points one way and includes a 5m CLOSE through a non-purple line, that's the
    // trade. Love, Oct 3 ~10:20 PM PT: "i'd like her to take those" -> BRICK (live) and BRICK · CLEAN both take it, tagged.
    let chopSide: Signal | null = null;
    if (sides.size > 1) {
      const rest = sig.filter((x) => x.line.kind !== "purple");
      const restSides = new Set(rest.map((x) => x.side));
      const brk = rest.filter((x) => /close (above|below)/.test(x.label));
      if (restSides.size === 1 && brk.length) chopSide = { ...brk[0], label: `${brk[0].label} (left the purple chop)` };
      if (!chopSide) {
        look.verdict = "long and short signals at once: no trade";
        continue;
      }
    }
    const s = chopSide ?? sig[0];
    const chop = chopSide != null;
    look.signal = s.label;
    look.side = s.side;
    if (!(a.secondsLeft > 120)) { look.verdict = "under 2 minutes left"; continue; }
    const target = a.target;
    if (target == null || !(target > 0)) { look.verdict = "no strike yet"; continue; }
    const lo = Math.min(spot, target);
    const hi2 = Math.max(spot, target);
    const mustCross = s.side === "up" ? target > spot : target < spot;
    const wall = mustCross ? lines.find((l) => l.price > lo && l.price < hi2) : undefined;
    if (wall) { look.verdict = `gate 1: the ${wall.name} ${wall.price.toFixed(2)} sits between price and the strike ${target}`; continue; }
    // HER DNA (dna.ts), the same law every book carries.
    // TWO DNAs (Love, Oct 2 ~midnight): her fix books as always; the DNA x ATR twin books tagged rows.
    // SOLE5+ (Love, Oct 3 ~6:35 PM PT: "YES"): BRICK's own signals judged by 5M SOLE's rules only (session bands + 5m nav,
    // her 25% channel rule, 1.38x+). Desk setups reach SOLE5+ through the SOLE loop in engine.ts. Paper, one per window.
    try {
      const askP = s.side === "up" ? m.yesAsk : m.noAsk;
      if (!chop && askP > 0.02 && askP <= 0.725 && !dnaNowFrame(id, s.side, spot, target, "m5")) soleConsider({ ticker: m.ticker, side: s.side, ask: askP, label: `${s.label} (BRICK signal)` }, id, "sole5p");
    } catch {
    }
    // 2 FEEDS (Love, Oct 3 ~9:50 PM PT: "not take the trade if it breaks thru on the other symbol... use one as
    // confirmation"): every BTC BRICK signal is also judged on Vantage's lines and logged (twin.ts), so the 2-FEED view
    // can show what each book does when Vantage has to agree. Study only.
    if (id === "btc") {
      const askT = s.side === "up" ? m.yesAsk : m.noAsk;
      void import("./twin").then((t) => t.twinLook({ ticker: m.ticker, side: s.side, ask: askT, label: s.label }, spot, target, null)).catch(() => {});
    }
    const dna = dnaNow(id, s.side, spot, target, "fixed");
    const dnaA = dnaNow(id, s.side, spot, target, "atr");
    if (dna) dnaLog(id, s.side, s.label, m.ticker, dna, "brick/diamond");
    // Oct 3 ~1:15 AM PT (Love: "before the fix at 11:55"): main = BRICK/DIAMOND on their own gates, no DNA;
    // her 11:55 fix -> "fix" twin; DNA x ATR -> "atr" twin.
    const dnaC = dnaNow(id, s.side, spot, target, "chan"); // main: Love's 25%-of-the-channel rule
    const modes = ([dnaC ? null : "chan", dna ? null : "fixed", dnaA ? null : "atr"] as const).filter((x): x is "chan" | "fixed" | "atr" => x !== null);
    if (!modes.length) { look.verdict = dnaC ?? "DNA"; continue; }
    const inMode = (mode: "chan" | "fixed" | "atr", fn: () => void) => {
      setBookTag(mode === "atr" ? "atr" : mode === "fixed" ? "fix" : "");
      try {
        fn();
      } finally {
        setBookTag("");
      }
    };
    // DIAMOND sees BRICK's 5m signals too (it runs its own gates).
    {
      const ask0 = s.side === "up" ? m.yesAsk : m.noAsk;
      if (!chop && ask0 > 0.02 && ask0 < 0.98) for (const md of modes) inMode(md, () => diamondConsider({ ticker: m.ticker, side: s.side, ask: ask0, label: s.label, target }, id, { spot, vwap: a.vwap1m?.vwap ?? null, sd: a.vwap1m?.stdev ?? null, nav: a.nav ?? null, target }, spot));
    }
    const front = lineInFront(id, s.side, spot, lines);
    // Oct 3 ~1 AM PT (Love: wake BRICK): gate 2's $100 / $25 stays on the twins; the main book already passed her 25% channel rule.
    const modesB = front ? modes.filter((x) => x === "chan") : modes;
    if (!modesB.length) { look.verdict = `gate 2: ${front!.name} ${front!.price.toFixed(2)} right ${s.side === "up" ? "above the long" : "below the short"}`; continue; }
    const ask = s.side === "up" ? m.yesAsk : m.noAsk;
    if (!(ask > 0.02 && ask < 0.98)) { look.verdict = "no ask"; continue; }
    const mult = 1 / ask;
    const hi = id === "btc" ? 1.8 : 2.5;
    if (mult < 1.38 || mult > hi) { look.verdict = `gate 3: ${mult.toFixed(2)}x is outside 1.38-${hi}x`; continue; }
    look.verdict = "TAKEN";
    const vw = a.vwap1m?.vwap ?? null;
    const sd = a.vwap1m?.stdev ?? null;
    for (const md of modesB) inMode(md, () => brickConsider({ ticker: m.ticker, side: s.side, ask, label: s.label }, id, { spot, vwap: vw, sd, nav: a.nav ?? null, target }));
    if (modesB.includes("chan")) {
      try {
        pushOn(id, a, s, ask, { spot, vwap: vw, sd, nav: a.nav ?? null, target }, lines, spot);
      } catch {
      }
      // BRICK · SESSION (Claude's suggestion, Oct 7 ~12 AM PT, Love: "im open to seeing how that does"). Loss lab, 1,211 paper
      // trades Oct 4-7: BRICK-family closes through a SESSION band (VWAP / sigma) were the best setup and held up in both
      // halves ($6.2 then $10.2 a trade); purple and nav-band signals earned less. Only BRICK's session-band signals. Paper.
      try {
        if (s.line.kind === "session") twinConsider("bricks", { ticker: m.ticker, side: s.side, ask, label: s.label }, id, { spot, vwap: vw, sd, nav: a.nav ?? null, target });
      } catch {
      }
    }
    // BRICK · CLEAN: same trade, unless it's a rejection off a purple with no session line within 0.08 sd of that purple.
    if (modesB.includes("chan")) {
      try {
        let skip = false;
        const pm = /rejection .* off the (5m|10m|15m) purple/i.exec(s.label);
        if (pm) {
          const fr = pm[1] === "5m" ? "m5" : pm[1] === "10m" ? "m10" : "m15";
          const purple = Number((a.nav as Record<string, { c?: number } | null | undefined> | null | undefined)?.[fr]?.c) || 0;
          const sessLines = vw && sd ? [vw, ...[0.5, 1, 1.5, 2, 2.5, 3].flatMap((k) => [vw + k * sd, vw - k * sd])] : [];
          // 0.08 sd (~$4 on BTC): "sitting in the same place". 0.2 sd was too loose (covered 80% of the chart) and kept the losers.
          const lined = purple > 0 && sd ? sessLines.some((x) => Math.abs(x - purple) <= 0.08 * sd) : false;
          skip = !lined;
        }
        if (!skip) brickCleanConsider({ ticker: m.ticker, side: s.side, ask, label: s.label }, id, { spot, vwap: vw, sd, nav: a.nav ?? null, target });
      } catch {
      }
    }
  }
}

export function brickLooks() {
  return g.__brickLook ?? {};
}
// What BRICK saw on its last look (diagnostic, read only).
export function brickWrite() {
  try {
    writeFileSync(join(process.cwd(), "data", "brick-now.json"), JSON.stringify(g.__brickLook ?? {}, null, 1));
  } catch {
    // diagnostic only
  }
}
