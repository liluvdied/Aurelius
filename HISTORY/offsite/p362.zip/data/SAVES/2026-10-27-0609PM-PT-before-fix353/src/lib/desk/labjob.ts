// LAB JOB (Claude, Oct 12 ~12:30 PM PT, Love: "could you test them against our lines / our model right now"). READ ONLY:
// fetches public data only (Kalshi settled 15M commodity markets, futures 1m candles, Kalshi combo collections) into
// data/lab/ so the analysis can run offline. Never places, changes or cancels anything. Triggered once by
// data/lab-req.json {kind}; status in data/lab/status.json.
import { existsSync, readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { kget } from "./scanner";

const D = (f: string) => join(process.cwd(), "data", f);
const g = globalThis as unknown as { __labBusy?: boolean };
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const SERIES: Record<string, string> = { gold: "KXGOLD15M", silver: "KXSILVER15M", platinum: "KXPLATINUM15M", palladium: "KXPALLADIUM15M", copper: "KXCOPPER15M", wti: "KXWTI15M", natgas: "KXNATGAS15M" };
const YAHOO: Record<string, string> = { gold: "GC=F", silver: "SI=F", platinum: "PL=F", palladium: "PA=F", copper: "HG=F", wti: "CL=F", natgas: "NG=F" };

function status(s: any) { try { writeFileSync(D("lab/status.json"), JSON.stringify({ at: new Date().toISOString(), ...s }, null, 1)); } catch {} }

async function commodities() {
  const out: any = {};
  const since = Math.floor(Date.now() / 1000) - 7 * 86400;
  for (const [a, s] of Object.entries(SERIES)) {
    const ms: any[] = [];
    let cursor = "";
    try {
      for (let p = 0; p < 10; p++) {
        const j = await kget(`/trade-api/v2/markets?series_ticker=${s}&status=settled&limit=1000&min_close_ts=${since}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`);
        for (const m of j?.markets ?? []) ms.push({ t: m.ticker, open: m.open_time, close: m.close_time, strike: m.floor_strike, settle: m.expiration_value, result: m.result, vol: m.volume_fp ?? m.volume, last: m.last_price_dollars ?? m.last_price });
        cursor = j?.cursor || "";
        if (!cursor) break;
        await sleep(400);
      }
    } catch (e) { out[`${a}_err`] = String(e).slice(0, 160); }
    out[a] = ms.length;
    writeFileSync(D(`lab/kalshi-${a}.json`), JSON.stringify(ms));
    status({ step: `kalshi ${a}`, n: ms.length });
    await sleep(500);
  }
  for (const [a, sym] of Object.entries(YAHOO)) {
    try {
      const res = await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(sym)}?interval=1m&range=7d`, { headers: { "User-Agent": "Mozilla/5.0" }, signal: AbortSignal.timeout(15000) });
      const j: any = await res.json();
      const r = j?.chart?.result?.[0];
      const ts: number[] = r?.timestamp ?? [];
      const q = r?.indicators?.quote?.[0] ?? {};
      const bars = ts.map((t, i) => [t, q.open?.[i], q.high?.[i], q.low?.[i], q.close?.[i], q.volume?.[i]]).filter((b) => b.slice(1, 5).every((x) => Number.isFinite(Number(x))));
      writeFileSync(D(`lab/bars-${a}.json`), JSON.stringify(bars));
      out[`${a}_bars`] = bars.length;
      if (!bars.length) out[`${a}_barsErr`] = `status ${res.status}`;
    } catch (e) { out[`${a}_barsErr`] = String(e).slice(0, 160); }
    status({ step: `bars ${a}`, out });
    await sleep(600);
  }
  return out;
}

async function combos() {
  const out: any = {};
  try {
    const j = await kget(`/trade-api/v2/multivariate_event_collections?status=open&limit=200`);
    const cs = j?.multivariate_contracts ?? j?.multivariate_event_collections ?? [];
    writeFileSync(D("lab/mve-collections.json"), JSON.stringify(cs, null, 1));
    out.collections = cs.length;
  } catch (e) { out.err = String(e).slice(0, 200); }
  return out;
}

export async function labTick() {
  const rq = D("lab-req.json");
  if (g.__labBusy || !existsSync(rq)) return;
  let req: any = {};
  try { req = JSON.parse(readFileSync(rq, "utf8")); } catch { return; }
  if (!req?.kind || req.done) return;
  g.__labBusy = true;
  writeFileSync(rq, JSON.stringify({ ...req, done: new Date().toISOString() }));
  try { mkdirSync(D("lab"), { recursive: true }); } catch {}
  try {
    const res: any = {};
    if (req.kind === "commodities" || req.kind === "all") res.commodities = await commodities();
    if (req.kind === "combos" || req.kind === "all") res.combos = await combos();
    if (req.kind === "combotry") {
      // one shadow quote on a combo built from the current 15M crypto favorites (nothing bought)
      const cs = JSON.parse(readFileSync(D("combos-status.json"), "utf8"));
      const legs: any[] = [];
      let est = 1;
      for (const m of cs?.markets ?? []) {
        if (!/^KX(BTC|ETH|SOL|XRP|DOGE|HYPE|ZEC|BNB)15M/.test(m.t)) continue;
        const ya = Number(m.ya), na = Number(m.na);
        const side = ya >= na ? "yes" : "no", ask = Math.max(ya, na);
        if (!(ask >= 0.5 && ask < 0.99)) continue;
        legs.push({ market_ticker: m.t, event_ticker: String(m.t).replace(/-[^-]+$/, ""), side }); est *= ask;
        if (legs.length >= 3) break;
      }
      const live: any = await import("./kalshi-live.server");
      res.combotry = legs.length >= 2 ? await live.comboBuyQuote(legs, 5, est) : { err: "no legs", n: (cs?.markets ?? []).length };
      res.combotry.legsIn = legs;
    }
    if (req.kind === "hourbt") {
      // 15 days of Kalshi BTC / gold 15M results + 1m bars (Yahoo, 7-day chunks) for the hours backtest (Oct 12, Love)
      const since = Math.floor(Date.now() / 1000) - 15 * 86400;
      res.hourbt = {};
      for (const [a, s] of [["btc", "KXBTC15M"], ["gold", "KXGOLD15M"]] as const) {
        const ms: any[] = [];
        let cursor = "";
        for (let p = 0; p < 20; p++) {
          try {
            const j = await kget(`/trade-api/v2/markets?series_ticker=${s}&status=settled&limit=1000&min_close_ts=${since}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`);
            for (const m of j?.markets ?? []) ms.push({ t: m.ticker, open: m.open_time, close: m.close_time, strike: m.floor_strike, result: m.result });
            cursor = j?.cursor || "";
            if (!cursor) break;
          } catch { await sleep(3000); }
          await sleep(1200);
        }
        writeFileSync(D(`lab/hb-kalshi-${a}.json`), JSON.stringify(ms));
        const sym = a === "btc" ? "BTC-USD" : "GC=F";
        const bars: any[] = [];
        const now = Math.floor(Date.now() / 1000);
        for (let k = 3; k >= 0; k--) {
          const p2 = now - k * 6 * 86400, p1 = p2 - 6 * 86400;
          try {
            const r = await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(sym)}?interval=1m&period1=${p1}&period2=${p2}`, { headers: { "User-Agent": "Mozilla/5.0" }, signal: AbortSignal.timeout(20000) });
            const j: any = await r.json();
            const x = j?.chart?.result?.[0];
            const q = x?.indicators?.quote?.[0] ?? {};
            (x?.timestamp ?? []).forEach((t: number, i: number) => { if ([q.open?.[i], q.high?.[i], q.low?.[i], q.close?.[i]].every((v) => v != null)) bars.push([t, q.open[i], q.high[i], q.low[i], q.close[i], q.volume?.[i] ?? 0]); });
          } catch {}
          await sleep(800);
        }
        writeFileSync(D(`lab/hb-bars-${a}.json`), JSON.stringify(bars));
        res.hourbt[a] = { markets: ms.length, bars: bars.length };
        status({ step: `hourbt ${a}`, res });
      }
    }
    if (req.kind === "hybridflags") {
      // HYBRID REPLAY (Oct 13 ~12:30 PM PT, Love: "show the trades she would have taken on that overnight"): for every one of
      // her books' paper rows since req.since, was price outside her +/-1 sigma channel at that moment? Session VWAP rebuilt
      // the way the desk builds it (5m bars since 5 PM ET: PEPPERSTONE:BTCUSD / TVC:GOLD, hlc3, volume-weighted).
      const { chartRaw } = await import("./tv");
      const { computeVwap } = await import("./vwap");
      const since = String(req.since || "2026-10-13T09:45:00Z");
      const bars: Record<string, any[]> = {};
      for (const [a, sym] of [["btc", "PEPPERSTONE:BTCUSD"], ["gold", "TVC:GOLD"]] as const) {
        try { bars[a] = ((await chartRaw(sym, "5", 900)) as any[]).sort((x, y) => x.t - y.t); } catch { bars[a] = []; }
      }
      const anchor = (tSec: number) => { const d = new Date(tSec * 1000); let a = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), 21) / 1000; if (a > tSec) a -= 86400; return a; };
      const g0 = JSON.parse(readFileSync(D("grok-og.json"), "utf8"));
      const rows: any[] = (Array.isArray(g0) ? g0 : g0?.rows ?? []).filter((r: any) => r.at >= since && /^(sp|ogp)(5|15)(-old|-both)?$/.test(String(r.lane)));
      const flags: Record<string, any> = {};
      for (const r of rows) {
        const t = Date.parse(r.at) / 1000;
        const bs = (bars[r.asset] ?? []).filter((b: any) => b.t >= anchor(t) && b.t + 300 <= t);
        const f: any = bs.length >= 2 ? computeVwap(bs.map((b: any) => ({ ...b, v: Number(b.v) || 0 })) as any) : null;
        const spot = Number(r.bar?.c) || (bs.length ? bs[bs.length - 1].c : 0);
        const sd = Math.max(Number(f?.stdev) || 0, (Number(f?.vwap) || 0) * 0.00015);
        flags[r.id] = f && sd > 0 && spot > 0 ? { outside: Math.abs(spot - f.vwap) > sd, vwap: Math.round(f.vwap * 100) / 100, sd: Math.round(sd * 100) / 100, spot } : null;
      }
      writeFileSync(D("lab/hybrid-flags.json"), JSON.stringify({ at: new Date().toISOString(), since, flags }));
      res.hybridflags = Object.keys(flags).length;
    }
    if (req.kind === "smreplay") {
      // SUPERMODEL REPLAY (Oct 13 ~1:40 AM PT, Love: "see what her opinion was on the two that lost... replicate the scenario"):
      // every combo since req.since, each leg read as of the moment the combo was built (bars closed by then only).
      const { smLegAt } = await import("./supermodel");
      const since = Date.parse(req.since || "2026-10-12T19:00:00Z");
      const rows = JSON.parse(readFileSync(D("combos.json"), "utf8")).filter((c: any) => Date.parse(c.at) >= since && !/-sm$/.test(String(c.lane || "")));
      const ids = new Set<string>((req.ids ?? []) as string[]);
      const out: any[] = [];
      let k = 0;
      for (const c of rows) {
        const at = Date.parse((ids.has(c.id) && req.asOf?.[c.id]) || c.at);
        const reads: any[] = [];
        for (const l of c.legs ?? []) {
          const r = l.kind === "sports" ? { ok: null, why: "sports" } : await smLegAt(l.series, l.side, c.window, at);
          reads.push({ series: l.series, side: l.side, ask: l.ask, result: l.result ?? null, ...r });
        }
        out.push({ id: c.id, lane: c.lane, at: c.at, window: c.window, cost: c.cost, result: c.result, pnl: c.pnl, holdPnl: c.holdPnl, reads });
        if (++k % 25 === 0) status({ step: `smreplay ${k}/${rows.length}` });
      }
      writeFileSync(D("lab/sm-replay.json"), JSON.stringify(out));
      res.smreplay = out.length;
    }
    if (req.kind === "calib") {
      // CALIBRATION (Oct 13 ~1:45 AM PT, Love: "do the lower multiples on the hourly contracts tend to stay true to the outcomes
      // more so than the 15m windows?"): minute candles of settled BTC 15M windows and of hourly KXBTCD strikes near the money.
      const hours = Number(req.hours) || 48;
      const now = Math.floor(Date.now() / 1000), since = now - hours * 3600;
      const candles = async (series: string, t: string, a: number, b: number) => {
        for (let k = 0; k < 3; k++) {
          try {
            const j = await kget(`/trade-api/v2/series/${series}/markets/${t}/candlesticks?start_ts=${a}&end_ts=${b}&period_interval=1`);
            return (j?.candlesticks ?? []).map((x: any) => [x.end_period_ts, x.yes_bid?.close_dollars ?? x.yes_bid?.close ?? null, x.yes_ask?.close_dollars ?? x.yes_ask?.close ?? null]);
          } catch { await sleep(2500); }
        }
        return null;
      };
      const out: any = { m15: [], h1: [] };
      const ms15 = JSON.parse(readFileSync(D("lab/dir-KXBTC15M.json"), "utf8")).filter((m: any) => Date.parse(m.close) / 1000 >= since && (m.result === "yes" || m.result === "no"));
      let k = 0;
      for (const m of ms15) {
        const a = Date.parse(m.open) / 1000, b = Date.parse(m.close) / 1000;
        out.m15.push({ t: m.t, close: m.close, result: m.result, c: await candles("KXBTC15M", m.t, a, b) });
        if (++k % 20 === 0) status({ step: `calib 15m ${k}/${ms15.length}` });
        await sleep(650);
      }
      writeFileSync(D("lab/calib.json"), JSON.stringify(out));
      // hourly: each settled KXBTCD hour event, the 10 strikes nearest its settle value
      for (let h = Math.ceil(since / 3600) * 3600; h <= now - 300; h += 3600) {
        const close = new Date(h * 1000).toISOString();
        let ms: any[] = [];
        try {
          const j = await kget(`/trade-api/v2/markets?series_ticker=KXBTCD&status=settled&min_close_ts=${h - 60}&max_close_ts=${h + 60}&limit=1000`);
          ms = (j?.markets ?? []).filter((m: any) => Date.parse(m.close_time) / 1000 === h);
        } catch { await sleep(2500); continue; }
        await sleep(650);
        const sv = Number(ms.find((m: any) => m.expiration_value)?.expiration_value) || 0;
        if (!ms.length || !sv) continue;
        const near = ms.sort((x: any, y: any) => Math.abs(Number(x.floor_strike) - sv) - Math.abs(Number(y.floor_strike) - sv)).slice(0, 10);
        for (const m of near) {
          out.h1.push({ t: m.ticker, close, strike: Number(m.floor_strike), settle: sv, result: m.result, c: await candles("KXBTCD", m.ticker, h - 3600, h) });
          await sleep(650);
        }
        status({ step: `calib 1h ${close}`, n: out.h1.length });
        writeFileSync(D("lab/calib.json"), JSON.stringify(out));
      }
      writeFileSync(D("lab/calib.json"), JSON.stringify(out));
      res.calib = { m15: out.m15.length, h1: out.h1.length };
    }
    if (req.kind === "candles") {
      // REBUILD (Oct 13 ~7:50 PM PT, Love: "i can't see anything from before today at 5am... is there any way you can get those
      // back"): read-only. For each 15M ticker: Kalshi's 1-minute candles (bid/ask) over its window + its result, all into
      // lab/candles.json, so the trimmed lineup rows can be rebuilt offline at the prices she'd have seen.
      // gentle on Kalshi (the live desk shares the rate limit): keeps what an earlier pass got, ~1 call a second, 429 = wait + retry
      let out: Record<string, any> = {};
      try { out = JSON.parse(readFileSync(D("lab/candles.json"), "utf8")); for (const k of Object.keys(out)) if (k.startsWith("err")) delete out[k]; } catch {}
      const kg = async (path: string) => { for (let a = 0; a < 4; a++) { try { return await kget(path); } catch (e) { if (!/429/.test(String(e)) || a === 3) throw e; await sleep(4000 * (a + 1)); } } };
      const MON = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
      const tks = (req.tickers ?? []) as string[];
      for (let i = 0; i < tks.length; i += 40) {
        try {
          if (tks.slice(i, i + 40).every((t) => out[t]?.result)) continue;
          const j: any = await kg(`/trade-api/v2/markets?tickers=${tks.slice(i, i + 40).join(",")}&limit=100`);
          for (const m of j?.markets ?? []) out[m.ticker] = { ...(out[m.ticker] || {}), result: m.result, open: m.open_time, close: m.close_time, strike: m.floor_strike };
        } catch (e) { out[`err${i}`] = String(e).slice(0, 160); }
        await sleep(400);
      }
      let k = 0;
      for (const t of tks) {
        const mm = /^(KX[A-Z]+15M)-(\d\d)([A-Z]{3})(\d\d)(\d\d)(\d\d)/.exec(t);
        if (!mm || out[t]?.candles?.length) continue;
        const end = Date.UTC(2000 + Number(mm[2]), MON.indexOf(mm[3]), Number(mm[4]), Number(mm[5]) + 4, Number(mm[6])) / 1000;
        try {
          const j: any = await kg(`/trade-api/v2/series/${mm[1]}/markets/${t}/candlesticks?start_ts=${end - 960}&end_ts=${end}&period_interval=1`);
          (out[t] ||= {}).candles = j?.candlesticks ?? []; delete out[t].err;
        } catch (e) { (out[t] ||= {}).err = String(e).slice(0, 160); }
        if (++k % 20 === 0) { status({ step: "candles", k, of: tks.length }); writeFileSync(D("lab/candles.json"), JSON.stringify(out)); }
        await sleep(1000);
      }
      writeFileSync(D("lab/candles.json"), JSON.stringify(out));
      res.candles = { n: Object.keys(out).length };
    }
    if (req.kind === "kprobe") {
      // read-only Kalshi GETs (public market data), saved for debugging (Oct 13)
      res.kprobe = {};
      for (const path of (req.paths ?? []) as string[]) {
        if (!/^\/trade-api\/v2\/(markets|events|series)/.test(path)) continue;
        try { const j = await kget(path); writeFileSync(D(`lab/kprobe-${path.replace(/[^a-z0-9]+/gi, "_").slice(-80)}.json`), JSON.stringify(j)); res.kprobe[path] = "ok"; } catch (e) { res.kprobe[path] = String(e).slice(0, 160); }
        await sleep(400);
      }
    }
    if (req.kind === "dirhist") {
      // DIRECTION HISTORY (Oct 13 ~12:50 AM PT, Love: "can you see where most trades end up heading directionally at different
      // times throughout the day? ... 3:15 long patterns for example?"): every settled 15M window Kalshi still lists, per series.
      const days = Number(req.days) || 120;
      const since = Math.floor(Date.now() / 1000) - days * 86400;
      res.dirhist = {};
      for (const s of (req.series ?? ["KXBTC15M", "KXGOLD15M"]) as string[]) {
        const ms: any[] = [];
        let cursor = "";
        for (let p = 0; p < 60; p++) {
          try {
            const j = await kget(`/trade-api/v2/markets?series_ticker=${s}&status=settled&limit=1000&min_close_ts=${since}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`);
            for (const m of j?.markets ?? []) ms.push({ t: m.ticker, open: m.open_time, close: m.close_time, strike: m.floor_strike, result: m.result, settle: m.expiration_value ?? null });
            cursor = j?.cursor || "";
            status({ step: `dirhist ${s} page ${p + 1}`, n: ms.length });
            if (!cursor) break;
          } catch { await sleep(3000); }
          await sleep(1100);
        }
        writeFileSync(D(`lab/dir-${s}.json`), JSON.stringify(ms));
        res.dirhist[s] = ms.length;
      }
    }
    if (req.kind === "tvbars") {
      const { chartRaw } = await import("./tv");
      for (const sym of (req.symbols ?? []) as string[]) { try { writeFileSync(D(`lab/tv-${sym.replace(/[^A-Z0-9]/gi, "_")}${req.resolution && req.resolution !== "1" ? "-" + req.resolution : ""}.json`), JSON.stringify(await chartRaw(sym, String(req.resolution || "1"), Number(req.count) || 400))); } catch {} }
      res.tvbars = true;
    }
    if (req.kind === "tvcheck") {
      const { chartRaw } = await import("./tv");
      res.tv = {};
      for (const sym of (req.symbols ?? []) as string[]) {
        try { const b: any[] = (await chartRaw(sym, "1", 120)) as any[]; const last = b.length ? Math.max(...b.map((x: any) => x.t)) : 0; res.tv[sym] = { n: b.length, lastAgoSec: last ? Math.round(Date.now() / 1000 - last) : null, lastC: b.length ? b.sort((x: any, y: any) => x.t - y.t)[b.length - 1].c : null }; } catch (e) { res.tv[sym] = { err: String(e).slice(0, 120) }; }
      }
    }
    status({ done: true, res });
  } catch (e) {
    status({ error: String(e).slice(0, 300) });
  } finally {
    g.__labBusy = false;
  }
}
