// TRAJECTORY (Claude, Oct 4 ~5 AM PT, Love: "a TRAJECTORY tab, that has the ability to see a projection of how all of the
// different books would perform at their current rate, with a window for error over a week / month / year, at different
// prices... a box for prices i can set... click thru the different books").
//
// How it projects: every settled trade a book has made is one draw (its return on its stake). Each simulated future first
// re-weights those trades at random (a Bayesian bootstrap), so the band also carries "we only have N trades, the real hit rate
// could be a bit better or worse", then deals out trades at the book's pace. Fixed $ per trade, no compounding.
import { useMemo, useState } from "react";
import type { TrajBook } from "@/lib/desk/fns";

const UP = "#3ddc84";
const DOWN = "#ff5c5c";
const NAME: Record<string, string> = {
  live: "LIVE · KALSHI",
  brick: "BRICK",
  brickc: "BRICK · CLEAN",
  cotc: "COTC",
  trend: "CLAUDE · TREND",
  claude: "CLAUDE",
  original: "ORIGINAL",
  new: "NEW",
  sole5: "5M SOLE",
  sole5p: "5M SOLE+",
  sole5v: "5M VANTAGE",
  sole5z: "5M ZONE",
  snap50: "SNAP +50",
  snap100: "SNAP +100",
  snap200: "SNAP +200",
  snap300: "SNAP +300",
  snaphold: "SNAP HOLD",
  x16_50: "16x +50",
  x16_100: "16x +100",
  x16_200: "16x +200",
  x16_300: "16x +300",
  x16hold: "16x HOLD",
  tap3x: "TAP 3x",
  taphold: "TAP HOLD",
  rescue: "RESCUE",
  bank: "BANK",
  bank5p: "BANK SOLE+",
  brickx: "BRICK 5M-X",
  bank5px: "BANK SOLE+ 5M-X",
  brickt: "BRICK TVC",
  brickp: "BRICK PUSH",
  bricks: "BRICK SESSION",
  brickcr: "CLEAN RIDE",
  brickc75: "CLEAN 75%",
  brickcf: "CLEAN FEES",
  brickcm: "CLEAN MAKER",
  brickcpt: "CLEAN PATIENT",
  brickcx: "CUT 2 BANDS",
  brickcw: "CUT WALL",
  brickcl: "CUT LATE",
  brickch: "HALF 75%",
  claudex: "CLAUDE 5M-X",
  trendx: "TREND 5M-X",
  bank2: "BANK 2",
  brk: "BREAK",
  hold90: "HOLD 90",
  hour: "HOURLY",
};
const TOP = ["live", "brick", "brickc", "cotc", "trend", "claude"];
const HORIZONS = [
  { key: "week", label: "WEEK", days: 7 },
  { key: "month", label: "MONTH", days: 30 },
  { key: "year", label: "YEAR", days: 365 },
] as const;

const money = (n: number) => `${n < 0 ? "−" : "+"}$${Math.abs(Math.round(n)).toLocaleString("en-US")}`;
const pct = (n: number) => `${Math.round(n * 100)}%`;

function project(rets: number[], asks: number[], perDay: number, days: number, stake: number, slipC: number) {
  const n = rets.length;
  const trades = Math.max(1, Math.round(perDay * days));
  const sims = trades > 4000 ? 300 : 600;
  const POINTS = 48;
  const step = Math.max(1, Math.ceil(trades / POINTS));
  // Paying slipC cents more per entry buys fewer contracts: return' = (1 + return) * ask / (ask + slip) - 1.
  const adj = rets.map((r, i) => (slipC > 0 && asks[i] > 0 ? ((1 + r) * asks[i]) / (asks[i] + slipC / 100) - 1 : r));
  const cols: number[][] = [];
  const finals: number[] = [];
  const cum = new Float64Array(n);
  for (let s = 0; s < sims; s++) {
    let tot = 0;
    for (let i = 0; i < n; i++) {
      tot += -Math.log(1 - Math.random());
      cum[i] = tot;
    }
    let pnl = 0;
    let col = 0;
    for (let t = 1; t <= trades; t++) {
      const u = Math.random() * tot;
      let lo = 0;
      let hi = n - 1;
      while (lo < hi) {
        const mid = (lo + hi) >> 1;
        if (cum[mid] < u) lo = mid + 1;
        else hi = mid;
      }
      pnl += adj[lo] * stake;
      if (t % step === 0 || t === trades) {
        (cols[col] ||= []).push(pnl);
        col += 1;
      }
    }
    finals.push(pnl);
  }
  const q = (arr: number[], p: number) => {
    const a = arr.slice().sort((x, y) => x - y);
    return a[Math.min(a.length - 1, Math.max(0, Math.floor(p * (a.length - 1))))];
  };
  const band = cols.map((c, i) => ({ x: Math.min(trades, (i + 1) * step) / trades, p5: q(c, 0.05), p25: q(c, 0.25), p50: q(c, 0.5), p75: q(c, 0.75), p95: q(c, 0.95) }));
  return {
    trades,
    band,
    p5: q(finals, 0.05),
    p50: q(finals, 0.5),
    p95: q(finals, 0.95),
    red: finals.filter((f) => f < 0).length / finals.length,
  };
}

function Fan({ band, days }: { band: { x: number; p5: number; p25: number; p50: number; p75: number; p95: number }[]; days: number }) {
  if (!band.length) return null;
  const W = 100;
  const H = 52;
  const lo = Math.min(0, ...band.map((b) => b.p5));
  const hi = Math.max(0, ...band.map((b) => b.p95));
  const span = hi - lo || 1;
  const y = (v: number) => 4 + (1 - (v - lo) / span) * (H - 8);
  const pts = [{ x: 0, p5: 0, p25: 0, p50: 0, p75: 0, p95: 0 }, ...band];
  const line = (k: "p5" | "p25" | "p50" | "p75" | "p95") => pts.map((b) => `${(b.x * W).toFixed(2)},${y(b[k]).toFixed(2)}`).join(" ");
  const area = (a: "p5" | "p25", b: "p95" | "p75") =>
    `M${pts.map((p) => `${(p.x * W).toFixed(2)},${y(p[b]).toFixed(2)}`).join(" L")} L${pts
      .slice()
      .reverse()
      .map((p) => `${(p.x * W).toFixed(2)},${y(p[a]).toFixed(2)}`)
      .join(" L")} Z`;
  const end = band[band.length - 1];
  const tone = end.p50 >= 0 ? UP : DOWN;
  return (
    <div className="relative">
      <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="h-48 w-full">
        <line x1="0" x2={W} y1={y(0)} y2={y(0)} stroke="rgba(255,255,255,0.25)" strokeWidth="0.3" vectorEffect="non-scaling-stroke" />
        <path d={area("p5", "p95")} fill={tone} opacity="0.1" />
        <path d={area("p25", "p75")} fill={tone} opacity="0.18" />
        <polyline points={line("p50")} fill="none" stroke="#fff" strokeWidth="1.6" vectorEffect="non-scaling-stroke" />
      </svg>
      <div className="mt-1 flex justify-between font-mono text-[9px] text-white/45">
        <span>NOW</span>
        <span>{days === 7 ? "7 DAYS" : days === 30 ? "30 DAYS" : "365 DAYS"}</span>
      </div>
    </div>
  );
}

export function TrajectoryPanel({ books }: { books: TrajBook[] }) {
  const usable = books.filter((b) => b.n >= 3);
  const [pick, setPick] = useState<string>("");
  const book = usable.find((b) => b.book === pick) ?? TOP.map((k) => usable.find((b) => b.book === k)).find(Boolean) ?? usable[0];
  const [stake, setStake] = useState("20");
  const [paceIn, setPaceIn] = useState<Record<string, string>>({});
  const [slipIn, setSlipIn] = useState<Record<string, string>>({});
  const [hz, setHz] = useState<(typeof HORIZONS)[number]["key"]>("week");
  const [seed, setSeed] = useState(0);
  const horizon = HORIZONS.find((h) => h.key === hz)!;
  const dollars = Math.max(1, Number(stake) || 20);
  const pace = book ? (Number(paceIn[book.book]) > 0 ? Number(paceIn[book.book]) : book.perDay) : 0;
  const slip = book ? (slipIn[book.book] != null && slipIn[book.book] !== "" ? Math.max(0, Number(slipIn[book.book]) || 0) : book.live ? 0 : 1) : 0;

  const res = useMemo(() => (book ? project(book.rets, book.asks, pace, horizon.days, dollars, slip) : null), [book, pace, horizon.days, dollars, slip, seed]);
  const perTrade = book ? book.rets.reduce((s, r) => s + r, 0) / book.n : 0;

  if (!book || !res) {
    return (
      <section className="rounded-[22px] border border-white/25 px-5 py-6 text-center text-[10px] tracking-[0.22em] text-white/60">
        TRAJECTORY · WAITING FOR SETTLED TRADES
      </section>
    );
  }
  const tone = res.p50 >= 0 ? UP : DOWN;
  return (
    <section className="space-y-4 rounded-[22px] border border-white/30 px-5 py-5 text-white shadow-[0_0_18px_rgba(255,255,255,0.08)]">
      <div className="flex items-baseline justify-between gap-3">
        <p className="text-[10px] tracking-[0.28em] text-white/80">TRAJECTORY</p>
        <p className="text-[9px] tracking-[0.18em] text-white/45">AT ITS CURRENT RATE · WITH THE WINDOW FOR ERROR</p>
      </div>

      {[
        { title: "HER LIVE BOOKS", list: TOP.map((k) => usable.find((b) => b.book === k)).filter((b): b is TrajBook => Boolean(b)) },
        { title: "PAPER LAB", list: usable.filter((b) => !TOP.includes(b.book)) },
      ].map((grp) => (grp.list.length ? (
      <div key={grp.title}>
      <p className="mb-1.5 text-[8px] tracking-[0.24em] text-white/45">{grp.title}</p>
      <div className="flex flex-wrap gap-1.5">
        {grp.list.map((b) => {
          const on = b.book === book.book;
          return (
            <button
              key={b.book}
              type="button"
              onClick={() => setPick(b.book)}
              className={`rounded-[6px] border px-2.5 py-1.5 text-left transition ${on ? "border-white bg-white text-black" : "border-white/25 text-white/80 hover:border-white/60"}`}
            >
              <span className="block text-[9px] tracking-[0.18em]">{NAME[b.book] ?? b.book.toUpperCase()}</span>
              <span className={`block font-mono text-[9px] ${on ? "text-black/60" : "text-white/45"}`}>
                {b.wins}-{b.n - b.wins} · {pct(b.wins / b.n)}
              </span>
            </button>
          );
        })}
      </div>
      </div>
      ) : null))}

      <div className="grid grid-cols-3 gap-2">
        <label className="rounded-[9px] border border-white/20 px-3 py-2">
          <span className="block text-[8px] tracking-[0.2em] text-white/50">$ PER TRADE</span>
          <input inputMode="decimal" value={stake} onChange={(e) => setStake(e.target.value.replace(/[^0-9.]/g, ""))} className="w-full bg-transparent font-mono text-lg text-white outline-none" />
        </label>
        <label className="rounded-[9px] border border-white/20 px-3 py-2">
          <span className="block text-[8px] tracking-[0.2em] text-white/50">TRADES / DAY</span>
          <input
            inputMode="decimal"
            value={paceIn[book.book] ?? String(book.perDay)}
            onChange={(e) => setPaceIn((p) => ({ ...p, [book.book]: e.target.value.replace(/[^0-9.]/g, "") }))}
            className="w-full bg-transparent font-mono text-lg text-white outline-none"
          />
        </label>
        <label className="rounded-[9px] border border-white/20 px-3 py-2">
          <span className="block text-[8px] tracking-[0.2em] text-white/50">LIVE FILL COST ¢</span>
          <input
            inputMode="decimal"
            value={slipIn[book.book] ?? String(slip)}
            onChange={(e) => setSlipIn((p) => ({ ...p, [book.book]: e.target.value.replace(/[^0-9.]/g, "") }))}
            className="w-full bg-transparent font-mono text-lg text-white outline-none"
          />
        </label>
      </div>

      <div className="flex gap-1.5">
        {HORIZONS.map((h) => (
          <button
            key={h.key}
            type="button"
            onClick={() => setHz(h.key)}
            className={`flex-1 rounded-[6px] border py-1.5 text-[10px] tracking-[0.22em] ${h.key === hz ? "border-white bg-white text-black" : "border-white/25 text-white/75"}`}
          >
            {h.label}
          </button>
        ))}
        <button type="button" onClick={() => setSeed((s) => s + 1)} className="rounded-[6px] border border-white/25 px-3 text-[10px] tracking-[0.2em] text-white/60" title="Run the futures again">
          ↻
        </button>
      </div>

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <div className="rounded-[9px] border border-white/15 px-3 py-2">
          <p className="text-[8px] tracking-[0.2em] text-white/50">LIKELY</p>
          <p className="font-mono text-xl" style={{ color: tone }}>{money(res.p50)}</p>
        </div>
        <div className="rounded-[9px] border border-white/15 px-3 py-2">
          <p className="text-[8px] tracking-[0.2em] text-white/50">ROUGH {horizon.label} · 1 IN 20</p>
          <p className="font-mono text-xl" style={{ color: res.p5 >= 0 ? UP : DOWN }}>{money(res.p5)}</p>
        </div>
        <div className="rounded-[9px] border border-white/15 px-3 py-2">
          <p className="text-[8px] tracking-[0.2em] text-white/50">GREAT {horizon.label} · 1 IN 20</p>
          <p className="font-mono text-xl" style={{ color: res.p95 >= 0 ? UP : DOWN }}>{money(res.p95)}</p>
        </div>
        <div className="rounded-[9px] border border-white/15 px-3 py-2">
          <p className="text-[8px] tracking-[0.2em] text-white/50">CHANCE OF A RED {horizon.label}</p>
          <p className="font-mono text-xl" style={{ color: res.red < 0.1 ? UP : res.red < 0.3 ? "#f5c542" : DOWN }}>{res.red < 0.005 ? "<1%" : pct(res.red)}</p>
        </div>
      </div>

      <Fan band={res.band} days={horizon.days} />

      <p className="text-[9px] leading-relaxed tracking-[0.06em] text-white/55">
        {NAME[book.book] ?? book.book.toUpperCase()}: {book.n} settled trades ({book.wins} won), {perTrade >= 0 ? "+" : ""}
        {Math.round(perTrade * 1000) / 10}% of the stake per trade on average, about {book.perDay} a day since{" "}
        {book.from ? new Date(book.from).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit", timeZone: "America/Los_Angeles" }) : "—"} PT.{" "}
        {res.trades.toLocaleString("en-US")} trades in this {horizon.label.toLowerCase()} at ${dollars} each. The white line is the middle future, the
        bright band holds half of them, the faint band 9 in 10. Few trades = a wide band: it narrows as she gives us more.{" "}
        {book.live ? "LIVE is Kalshi's own fills and settlements, fees included." : `Paper fills; LIVE FILL COST adds what Kalshi charges over paper (she has been paying about 1¢ more).`}
      </p>
    </section>
  );
}
