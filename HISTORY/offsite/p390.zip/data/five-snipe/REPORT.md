# 5m snipe paper book 🎯

Polymarket BTC 5m: main/rejection call at a band + 1m candle flip her way, her side at 1-15c, $10 paper, one per window. Since Sun 04:55 AM PT. Updated Wed 12:22 AM PT.

| Lane | Trades | Won | Win rate | P&L |
|---|---|---|---|---|
| cash at 3x | 38 | 10 | 26% | $+459.17 |
| cash at 5x | 38 | 9 | 24% | $+549.17 |
| cash at 7.5x | 38 | 8 | 21% | $+624.17 |
| cash at 10x | 38 | 8 | 21% | $+726.09 |

| When (PT) | Book | Side | Paid | Peak bid | 3x | 5x | 7.5x | 10x |
|---|---|---|---|---|---|---|---|---|
| Sun 06:43 AM | recon-tog | down | 0.04 | 0.05 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Sun 06:59 AM | recon-rej | up | 0.08 | 0.02 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Sun 07:43 AM | recon-tog | down | 0.02 | 0.01 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Sun 07:58 AM | recon-tog | down | 0.1 | 0.03 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Sun 08:28 AM | recon-tog | down | 0.12 | 0.11 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Sun 09:39 AM | recon-tog | up | 0.01 | 0.02 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Sun 09:43 AM | recon-tog | down | 0.02 | 0.02 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Sun 11:13 AM | recon-rej | up | 0.08 | 0.07 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Sun 11:43 AM | recon-rej | down | 0.07 | 0.99 | cashed 3x +20.00 | cashed 5x +40.00 | cashed 7.5x +65.00 | cashed 10x +90.00 |
| Sun 12:14 PM | recon-tog | down | 0.06 | 0.05 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Sun 04:37 PM | recon-tog | down | 0.13 | 0.11 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Sun 04:44 PM | recon-tog | up | 0.01 | 0.01 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Sun 05:13 PM | recon-tog | down | 0.07 | 0.05 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Sun 05:28 PM | recon-tog | down | 0.06 | 0.02 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Sun 06:22 PM | recon-tog | down | 0.08 | 0.07 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Sun 07:07 PM | recon-tog | down | 0.11 | 0.05 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Sun 07:22 PM | recon-tog | up | 0.13 | 0.1 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Sun 07:39 PM | recon-tog | down | 0.01 | 0.01 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Sun 07:44 PM | recon-tog | up | 0.03 | 0.09 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Sun 08:24 PM | recon-tog | down | 0.01 | 0.01 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Sun 08:38 PM | recon-tog | down | 0.12 | 0.11 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Sun 10:28 PM | recon-rej | down | 0.09 | 0.12 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Mon 12:29 AM | recon-tog | up | 0.01 | 0.01 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Mon 12:59 AM | recon-tog | down | 0.01 | 0.01 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Mon 01:12 AM | recon-tog | up | 0.06 | 0.03 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Mon 02:07 AM | recon-rej | down | 0.13 | 0.25 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Mon 03:23 AM | recon-tog | up | 0.14 | 0.76 | cashed 3x +20.00 | cashed 5x +40.00 | lost -10.00 | lost -10.00 |
| Mon 05:09 AM | recon-tog | down | 0.01 | 0.01 | bell win +490.00 | bell win +490.00 | bell win +490.00 | bell win +490.00 |
| Mon 05:37 AM | recon-tog | up | 0.07 | 0.09 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Mon 06:29 AM | recon-rej | up | 0.01 | 0.01 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Mon 07:28 AM | recon-tog | up | 0.03 | 0.03 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Mon 07:52 AM | recon-tog | up | 0.12 | 0.99 | cashed 3x +20.00 | cashed 5x +40.00 | cashed 7.5x +65.00 | bell win +66.92 |
| Mon 08:37 AM | recon-tog | down | 0.02 | 0.09 | cashed 3x +20.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Mon 08:43 AM | recon-rej | up | 0.06 | 0.17 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Mon 09:28 AM | recon-tog | up | 0.01 | 0.01 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Mon 09:38 AM | recon-tog | up | 0.05 | 0.97 | cashed 3x +20.00 | cashed 5x +40.00 | cashed 7.5x +65.00 | cashed 10x +90.00 |
| Mon 10:24 AM | recon-tog | up | 0.01 | 0.01 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Mon 10:29 AM | recon-tog | up | 0.01 | 0.01 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Mon 01:38 PM | recon-tog | up | 0.1 | 0.08 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Mon 02:38 PM | recon-tog | down | 0.09 | 0.07 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Mon 03:44 PM | recon-tog | down | 0.01 | 0.01 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Mon 05:09 PM | recon-tog | down | 0.04 | 0.03 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Mon 05:43 PM | recon-tog | up | 0.15 | 0.08 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Mon 06:38 PM | recon-tog | down | 0.05 | 0.03 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Mon 06:54 PM | recon-tog | up | 0.01 | 0.01 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Mon 07:59 PM | recon-tog | up | 0.01 | 0.01 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Mon 08:22 PM | recon-tog | down | 0.09 | 0.06 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Mon 09:38 PM | recon-tog | up | 0.09 | 0.06 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Mon 09:54 PM | recon-tog | up | 0.04 | 0.03 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Mon 10:24 PM | recon-tog | up | 0.02 | 0.01 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Mon 11:24 PM | recon-tog | up | 0.01 | 0.01 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Mon 11:52 PM | recon-tog | up | 0.15 | 0.29 | bell win +52.50 | bell win +52.50 | bell win +52.50 | bell win +52.50 |
| Tue 01:43 AM | recon-tog | up | 0.04 | 0.02 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Tue 01:54 AM | recon-tog | up | 0.01 | 0.01 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Tue 02:12 AM | recon-tog | up | 0.15 | 0.14 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Tue 02:59 AM | recon-tog | down | 0.01 | 0.01 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Tue 03:12 AM | recon-tog | up | 0.14 | 0.13 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Tue 04:44 AM | recon-tog | up | 0.04 | 0.02 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Tue 04:56 AM | recon-tog | down | 0.1 | 0.09 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Tue 05:12 AM | recon-tog | down | 0.15 | 0.13 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Tue 06:27 AM | recon-tog | up | 0.08 | 0.07 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Tue 08:39 AM | recon-tog | down | 0.01 | 0.01 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Tue 09:57 AM | recon-tog | down | 0.12 | 0.11 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Tue 11:09 AM | recon-tog | down | 0.02 | 0.01 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Tue 12:29 PM | recon-tog | down | 0.01 | 0.01 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Tue 02:59 PM | recon-tog | up | 0.01 | 0.01 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Tue 03:23 PM | recon-rej | up | 0.14 | 0.13 | bell win +56.67 | bell win +56.67 | bell win +56.67 | bell win +56.67 |
| Tue 03:28 PM | recon-tog | up | 0.12 | 0.11 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Tue 03:52 PM | recon-tog | up | 0.09 | 0.99 | cashed 3x +20.00 | cashed 5x +40.00 | cashed 7.5x +65.00 | bell win +90.00 |
| Tue 04:42 PM | recon-tog | down | 0.1 | 0.09 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Tue 05:07 PM | recon-tog | up | 0.15 | 0.14 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Tue 07:13 PM | recon-tog | down | 0.05 | 0.04 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Tue 07:53 PM | recon-tog | down | 0.04 | 0.11 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Tue 08:23 PM | recon-tog | down | 0.04 | 0.04 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Tue 08:44 PM | recon-tog | down | 0.04 | 0.03 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Tue 09:07 PM | recon-tog | up | 0.05 | 0.04 | lost -10.00 | lost -10.00 | lost -10.00 | lost -10.00 |
| Tue 09:59 PM | recon-tog | down | 0.01 | 0.01 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
| Tue 10:08 PM | recon-rej | up | 0.09 | 0.99 | cashed 3x +20.00 | cashed 5x +40.00 | cashed 7.5x +65.00 | bell win +90.00 |
| Tue 10:43 PM | recon-tog | down | 0.08 | 0.07 | open +0.00 | open +0.00 | open +0.00 | open +0.00 |
