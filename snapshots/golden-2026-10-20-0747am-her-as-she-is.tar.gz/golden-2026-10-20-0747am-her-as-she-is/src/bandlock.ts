// BAND LOCK (Oct 16 ~1:05 PM PT, Love: "i need you to make sure this sticks and doesn't fire again backwards in an hour. or the
// next window... please make sure that it is a physical impossibility to ever occur again").
// The last gate before a twin order reaches Kalshi, separate from goldlaw.ts / pivotbooks.ts / engine.ts so a change in any of
// them can't open the hole again. Every book, every asset (was: law books only): the order must be on
// the side of the CLOSEST band price is on right now (over it = long, under it = short). If that can't be verified (no fresh
// price, no fresh band list) or the law fails its self-test, the order is refused. The inverse (ogp5-inv) is not covered:
// trading against the twin is its job.
import { appendFileSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { quoteTick, feedHealth } from "./quotes";
import { RECON } from "./recon";

type Line = { name: string; price: number; unit?: number };
const LAW_BOOKS = /^ogp5-(fast|gw|boll|lock)$/;
const G = globalThis as any;
const D = (f: string) => join(process.cwd(), "data", f);

// Its own closest-band math (not imported), so a regression elsewhere can't fool it.
function nearSide(L: Line[], tick: number): { side: "up" | "down" | null; band: Line } | null {
  const ls = L.filter((l) => Number(l.price) > 0);
  if (!(tick > 0) || !ls.length) return null;
  let near = ls[0];
  for (const l of ls) if (Math.abs(tick - l.price) < Math.abs(tick - near.price)) near = l;
  return { side: tick < near.price ? "down" : tick > near.price ? "up" : null, band: near };
}
// BLOCK RANGE (Oct 18 ~1:00 PM PT, Love: "a band $86 away is not a reason to stop a long" / "the pink band was wayyyyyy too far away for her to
// BLOCK that. it was not an obstacle" - her picks: "Within $25 (BTC)", gold "Within $2.22", longs and shorts mirrored, every live book). An unbroken
// band only blocks a trade INTO it (closest-band rule, rejection memory) while price is within this range of it; further away it is not an obstacle.
// live-switch bandReach { btc, gold } overrides. 12:47 PM BTC: long off the tap below, pink $87 overhead -> both checks held her until 1.32x.
export function bandReach(asset: string): number {
  const def: Record<string, number> = { btc: 25, gold: 2.22 };
  if (!G.__stDefaultReach) { try { const v = Number(JSON.parse(readFileSync(D("live-switch.json"), "utf8"))?.bandReach?.[asset]); if (v > 0) return v; } catch {} }
  return def[asset] ?? Infinity;
}
const inReach = (asset: string, price: number, tick: number) => Math.abs(tick - Number(price)) <= bandReach(asset);
// RED / GREEN PIVOTS OWN RANGE (Oct 18 ~8:58 PM PT, Love: "make the red/green pivots $1.11 pls" - 8:54 PM gold: a break-up long was stopped by the 5m R1
// $1.46 above inside the $1.50 range): live-switch zoneReach[asset] is the range for the red/green pivot lines (R1/R2/S1/S2 on any timeframe) as walls in
// front; the pink and everything else keep bandReach. Unset = same as bandReach. The self-test always runs on the defaults.
export function zoneReach(asset: string): number {
  if (!G.__stDefaultReach) { try { const v = Number(JSON.parse(readFileSync(D("live-switch.json"), "utf8"))?.zoneReach?.[asset]); if (v > 0) return v; } catch {} }
  return bandReach(asset);
}
const isZoneLine = (l: Line) => /(^|\s)(R|S)\d$/.test(String(l.name));
const inReachL = (asset: string, l: Line, tick: number) => Math.abs(tick - Number(l.price)) <= (isZoneLine(l) ? zoneReach(asset) : bandReach(asset));
// NO REJECTION HOLD FOR TOGETHER (Oct 18 ~1:38 PM PT, Love: "yesss please, we can drop it for live orders / pls keep a twin that keeps it so we can
// compare the results"): both halves of TOGETHER (5M pivot = ogp5, PAPER 24/7 = pap247 / paper-247) skip "rejected off X and hasn't come back to it",
// like the session + pink book. Their paper twins ogp5-hold / paper-247-hold keep it (paper only).
export const NO_REJ_HOLD = new Set<string>(["ogp5", "pap247", "paper-247", "ogp5-pk2", "ogp5-pk3", "paper-247-pk2", "paper-247-pk3"]);
// HER RULE (Oct 18 ~1:46 PM PT, Love, in her words: "TRADE AWAY FROM THE CLOSEST BAND. NOT INTO IT. BAND BREAKS = TRADE THE DIRECTION OF THE BREAK.
// THAT IS IT." / "IF THERE IS A SESSION BAND ABOVE HER, TRADE AWAY FROM THEM"). 1:33 PM BTC: she longed with -1σ $135 above and -2σ $250 below
// because the old check counted the pink $30 below - a pink that had already BROKEN up - as "the closest band".
//  1) a break in THIS 5m candle in the trade's direction = the trade (break = trade the direction of the break);
//  2) otherwise the closest SESSION band decides (see awayVerdict) - trade AWAY from it: closest above = short only, closest below = long only.
//     A band price broke through still counts as a band behind her (trading away from it = the break's direction); a broken band never blocks
//     the break's direction (wallFor). Session bands count at any distance; the pink and
//     the other pivot lines count only within her block range ($25 BTC / $2.22 gold - "a band $86 away is not a reason to stop a long").
const isSessBand = (l: Line) => /σ$|^session VWAP$/.test(String(l.name));
export function freshBreakWith(asset: string, side: string, Bk: Map<string, "up" | "down">, nowS = Date.now() / 1000, st?: Record<string, { side: string; at: number }>): string {
  const S = st ?? (((G.__brokenWalls ||= {})[asset]) || {});
  const f0 = Math.floor(nowS / 300) * 300;
  for (const [nm, d] of Bk) { const b = S[nm]; if (d === side && b && b.side === side && Number(b.at) >= f0) return nm; }
  return "";
}
// BOLLINGER BOOK'S OWN BANDS (Oct 18 ~2:10 PM PT, Love: "price rejected off of the top bollinger band. it is a short. not a long. price rejects off
// lower bollinger = LONG."): for the Bollinger book its 5m BBSR upper/lower are bands in her rule like the session bands. 2:01:43 PM: it longed $31
// under its top Bollinger ($81,026) - the gate never saw those bands.
export const BB_BOOKS = new Set<string>(["ogp5-bbsr", "ogp5-dly"]); // + DELAYED (Love, Oct 18 ~6:05 PM PT: "you can have her use the bollinger bands too for the delayed entry book" + "Both")
// DELAYED NEEDS NO TAP (Oct 18 ~4:13 PM PT, Love: "for delayed entry, she doesn't need to wait for a tap"): the "at the band / at the pink - waiting for a
// break or a rejection" holds don't apply to the delayed book's fade at the next band. Every other check does.
export const NO_AT_WAIT = new Set<string>(["ogp5-dly"]);
// PINK THEORY (PAPER ONLY, Oct 18 ~3:53 PM PT, Love: "at the tap and rejection of the session band, she is clear to long. since price just broke the pink
// band, it is essentially already broken... provided it is within 2 candles (able to enter on the 2nd candle)" -> "test that on paper first... a 2 candle
// and 3 candle test"): on these paper twins of TOGETHER, a pink that broke within the last K five-minute candles is not a wall (no pink wall / pink wait /
// at-the-pink wait / pink in the road to the target) for a trade off the session band behind her. The candle that broke it still never trades against
// the break (candleBreakAgainst stays). Live books never use this.
export const PINK_RECENT: Record<string, number> = { "ogp5-pk2": 2, "paper-247-pk2": 2, "ogp5-pk3": 3, "paper-247-pk3": 3 };
export function pinkRecentFree(asset: string, L: Line[], tick: number, side: string, Bk: Map<string, "up" | "down">, K: number, o: { nowS?: number; st?: Record<string, { side: string; at: number }> } = {}): boolean {
  if (!(K > 0) || !(tick > 0) || !Bk.has("5m PP")) return false;
  const S = o.st ?? (((G.__brokenWalls ||= {})[asset]) || {});
  const b = S["5m PP"]; if (!b || !(Number(b.at) > 0)) return false;
  const f0 = Math.floor((o.nowS ?? Date.now() / 1000) / 300) * 300;
  if (Number(b.at) < f0 - (K - 1) * 300) return false; // broke within the last K 5m candles (this one counts as 1)
  const sess = L.filter((l) => isSessBand(l) && Number(l.price) > 0);
  const behind = side === "up" ? sess.filter((l) => l.price < tick).sort((a, c) => c.price - a.price)[0] : sess.filter((l) => l.price > tick).sort((a, c) => a.price - c.price)[0];
  return !!behind && inReach(asset, behind.price, tick); // she is trading off the session band right behind her
}
const noPink = (L: Line[]) => L.filter((l) => l.name !== "5m PP");
export function bbLines(asset: string): Line[] {
  const b = G.__bbsr?.[asset];
  if (!b || !(Number(b.bbU) > 0) || !(Number(b.bbL) > 0) || Date.now() - Number(b.at) > 20000) return [];
  return [{ name: "5m BBSR upper", price: Number(b.bbU) }, { name: "5m BBSR lower", price: Number(b.bbL) }];
}
// SESSION-BAND REJECTION (Oct 18 ~5:48 PM PT, Love: "yes bb" to: a pivot line price already broke through doesn't block a session-band
// rejection, gold and BTC - 5:01 PM gold: rejected down off +2σ, refused for "short INTO 5m R1 ($0.22 below)" that price had just climbed through).
export function isSessRej(x: any): boolean {
  if (!x) return false;
  const bn = String(typeof x.band === "string" ? x.band : x.band?.name ?? "");
  if (!/σ$|^session VWAP$/.test(bn)) return false;
  return x.from === "rejection" || /reject|bounce|tap/i.test(`${x.kind ?? ""} ${x.label ?? ""}`);
}
// A REAL REJECTION OUTRANKS THE 33% WALL (Oct 19 ~9:00 PM PT, Love picked "Rejection overrides the 33% wall" - the 8:46:04 PM gold pink-rejection long
// was called on time and her top-33% rule held the door 69 s under the unbroken +2σ): for the RECONSTRUCTED books, a qualified rejection in this 5m
// candle (tapped a line within $3 / 30c, never broke it ($6 / 33c), price moving away by the tap distance on the trade's side) waives channelOnly,
// the same way rejections already override the break direction. Wick read = 1m high/low + her live tick trail.
export function reconRejectNow(asset: string, L: Line[], tick: number, side: string): boolean {
  const tap = PINK_TAP[asset] ?? 0, brk = BREAK_DIST[asset] ?? 0;
  const o = fiveOpenNow(asset);
  const hl = fiveHLNow(asset);
  if (!(o > 0) || !(tick > 0) || !(tap > 0) || !(brk > 0)) return false;
  let h = hl ? hl.h : tick, l = hl ? hl.l : tick;
  try {
    const tk = Object.keys(G).filter((k) => /^__qtrail_\d+$/.test(k)).sort((a, b) => Number(b.slice(9)) - Number(a.slice(9)))[0];
    const f0 = Math.floor(Date.now() / 300000) * 300000;
    for (const x of ((tk && G[tk]?.[asset]) || []) as any[]) { if (x && x.c > 0 && x.t >= f0) { if (x.c > h) h = x.c; if (x.c < l) l = x.c; } }
  } catch {}
  h = Math.max(h, tick); l = Math.min(l, tick);
  // + THE PREVIOUS CANDLE'S TAP (Oct 19 ~9:15 PM PT: v4 let the books call rejections whose tap sat in the previous 5m candle, but this override only
  // knew the current one, so the 33% wall re-blocked exactly those - 369 refusals on the 9:06 PM BTC long. Same lookback as recon.ts bonesDecide.)
  let ph = 0, pl = 0;
  try {
    const bars = ((G.__pivBars?.[asset]?.bars ?? []) as any[]);
    const f0s = Math.floor(Date.now() / 1000 / 300) * 300;
    const inP = bars.filter((x) => x.t >= f0s - 300 && x.t < f0s);
    if (inP.length) { ph = Math.max(...inP.map((x) => x.h)); pl = Math.min(...inP.map((x) => x.l)); }
  } catch { ph = 0; pl = 0; }
  for (const ln of L) {
    const p = Number(ln.price); if (!(p > 0)) continue;
    if (side === "up" && o > p && l <= p + tap && l > p - brk && tick >= l + tap && tick > p) return true;
    if (side === "down" && o < p && h >= p - tap && h < p + brk && tick <= h - tap && tick < p) return true;
    if (pl > 0 && side === "up" && pl <= p + tap && pl > p - brk && l > p - brk && l > pl - tap && tick >= pl + tap && tick > p) return true;
    if (ph > 0 && side === "down" && ph >= p - tap && ph < p + brk && h < p + brk && h < ph + tap && tick <= ph - tap && tick < p) return true;
  }
  return false;
}
// THE 33% CHANNEL RULE, ALONE (Oct 19 ~6:33 PM PT, Love, after RECON TOGETHER's 6:30 PM BTC short "On 5m PP": "she shorted into a band directly in front of
// her on btc again... no shorts into an unbroken band in the lower 33% of the channel. longs only. no longs into an unbroken band in the top 33% of the
// channel. shorts only"): the channel part of awayVerdict (same code, same channelPct, same broken-band memory) with nothing else attached, for the
// RECONSTRUCTED books - her one addition to the Oct 12 model. Channel = nearest unbroken session band below to nearest unbroken session band above.
export function channelOnly(asset: string, L: Line[], tick: number, side: string, Bk: Map<string, "up" | "down">): string {
  if (!(tick > 0) || !(side === "up" || side === "down")) return "";
  let brokeNow = new Set<string>();
  try {
    const tk = Object.keys(G).filter((k) => /^__qtrail_\d+$/.test(k)).sort((a, b) => Number(b.slice(9)) - Number(a.slice(9)))[0];
    const f0 = Math.floor(Date.now() / 300000) * 300000;
    const trB = ((tk && G[tk]?.[asset]) || []).filter((x: any) => x && x.c > 0 && x.t >= f0);
    const opB = fiveOpenNow(asset);
    const dB = BREAK_DIST[asset] ?? 0;
    if (opB > 0 && dB > 0 && trB.length) {
      for (const b of L.filter((l) => isSessBand(l) && Number(l.price) > 0)) {
        const st0: string | null = opB > b.price ? "above" : opB < b.price ? "below" : null;
        for (const x of [...trB, { t: Number.MAX_SAFE_INTEGER, c: tick }]) {
          if (side === "up" && st0 === "below" && x.c >= b.price + dB) { brokeNow.add(b.name); break; }
          if (side === "down" && st0 === "above" && x.c <= b.price - dB) { brokeNow.add(b.name); break; }
        }
      }
    }
  } catch { brokeNow = new Set(); }
  const S = wallFor(wallLines(asset, L).filter((l) => Number(l.price) > 0 && isSessBand(l) && !brokeNow.has(l.name)), Bk, tick, side);
  // PRESSED PAST AN UNBROKEN BAND IS STILL AT THE BAND (Oct 19 ~11:08 PM PT, Love: "she shorted gold on the lower 33% of the
  // channel while it was rejecting off of a band, she fired properly on btc and longed - can you look into it?"): 11:00:04 PM, gold
  // 4119.24 with -2σ at 4119.47 - a 23c poke under the band is NOT a break (her 33c law), but it slid the channel math down to
  // -3σ..-2σ and called the very bottom of her channel "the top". While this 5m candle opened on the far side and price sits
  // within break distance past an unbroken band, that band is still her floor (or ceiling) - only trades AWAY from it may fire.
  try {
    const dPk = BREAK_DIST[asset] ?? 0;
    const oPk = fiveOpenNow(asset);
    if (dPk > 0 && oPk > 0) {
      if (side === "down") {
        const pr = S.filter((l) => l.price > tick && l.price - tick < dPk && oPk > l.price && Bk.get(l.name) !== "down").sort((a, b) => b.price - a.price)[0];
        if (pr) return `would short pressed $${(pr.price - tick).toFixed(2)} under unbroken ${pr.name} (${pr.price.toFixed(2)}) - a poke short of her break distance is not a break, that band is still her floor - longs only here`;
      }
      if (side === "up") {
        const pr = S.filter((l) => l.price < tick && tick - l.price < dPk && oPk < l.price && Bk.get(l.name) !== "up").sort((a, b) => a.price - b.price)[0];
        if (pr) return `would long pressed $${(tick - pr.price).toFixed(2)} over unbroken ${pr.name} (${pr.price.toFixed(2)}) - a poke short of her break distance is not a break, that band is still her ceiling - shorts only here`;
      }
    }
  } catch {}
  const up = S.filter((l) => l.price > tick).sort((a, b) => a.price - b.price)[0], dn = S.filter((l) => l.price < tick).sort((a, b) => b.price - a.price)[0];
  if (!up || !dn) return "";
  const frac = (tick - dn.price) / (up.price - dn.price);
  let cp = 0.33; try { const v = Number(JSON.parse(readFileSync(D("live-switch.json"), "utf8"))?.channelPct?.[asset]); if (v > 0 && v < 0.5) cp = v; } catch {}
  if (side === "up" && frac >= 1 - cp) return `would long INTO ${up.name} ($${(up.price - tick).toFixed(2)} above, unbroken) - price is in the top ${Math.round(cp * 100)}% of her channel (${dn.name} ${dn.price.toFixed(2)} to ${up.name} ${up.price.toFixed(2)}) - shorts only here`;
  if (side === "down" && frac <= cp) return `would short INTO ${dn.name} ($${(tick - dn.price).toFixed(2)} below, unbroken) - price is in the bottom ${Math.round(cp * 100)}% of her channel (${dn.name} ${dn.price.toFixed(2)} to ${up.name} ${up.price.toFixed(2)}) - longs only here`;
  return "";
}
// BAND BREAKS UP = TRADE UP, DOWN = TRADE DOWN (Oct 19 ~6:34 PM PT, Love, after RECON's 6:30:24 PM gold short "On -1.5σ" while gold broke a band up: "if a band
// breaks up, = trade up / band breaks down, = trade down"): this 5m candle's last band break sets the only side that may trade - her candleBreaks rule, direction
// only (no waiting when the candle hasn't broken anything - the Oct 12 entries stay instant). For the RECONSTRUCTED books.

// ZONE FLIP (Oct 20 ~2:32 AM PT, Love): the red/green zone rejection with a MUST-FLIP candle, as a direction - the recovery for an
// entry missed on her 1.38x floor or blocked under a zone. Same geometry as the bones signal in recon.ts.
export function zoneFlipNow(asset: string, L: Line[], tick: number, o: number, hl: { h: number; l: number } | null): "up" | "down" | null {
  const tapZ = PINK_TAP[asset] ?? 0, brkZ = BREAK_DIST[asset] ?? 0;
  if (!(o > 0) || !(tick > 0) || !hl || !(tapZ > 0) || !(brkZ > 0)) return null;
  const pZ = (n: string) => { const l0 = L.find((x) => String(x.name) === n); const p0 = Number(l0?.price); return p0 > 0 ? p0 : 0; };
  const r1 = pZ("5m R1"), r2 = pZ("5m R2"), s1 = pZ("5m S1"), s2 = pZ("5m S2");
  if (r1 > 0 && o < r1 && hl.h >= r1 - tapZ && hl.h < (r2 > 0 ? r2 : r1) + brkZ && tick < o && tick <= hl.h - tapZ) return "down";
  if (s1 > 0 && o > s1 && hl.l <= s1 + tapZ && hl.l > (s2 > 0 ? s2 : s1) - brkZ && tick > o && tick >= hl.l + tapZ) return "up";
  return null;
}

export function candleDirOnly(asset: string, L: Line[], tick: number, side: string): string {
  const o = fiveOpenNow(asset);
  if (!(o > 0) || !(tick > 0)) return "";
  // SCENARIO* (Oct 19 ~7:10 PM PT, Love: "if the band is broken UP from below, taps the pink band, and then rejects - ... she can short then - provided
  // the candle that broke the band is still connected to the other side of the band, via the wick through the band"): her Oct 18 break-one-tap-the-next
  // rejection (nextBandReject, same 5m candle, wick still spans the broken band) overrides the break direction - mirror for longs.
  try { const nr = nextBandReject(asset, L, tick, o, fiveHLNow(asset)); if (nr && nr.side === side) return ""; } catch {}
  // ZONE FLIP OVERRIDE (Oct 20 ~2:32 AM PT, Love): price rejected from the red/green zone and the candle FLIPPED - the rejection
  // trades even though this candle's break points the other way (the break she skipped is what brought price to the zone).
  try { const zf = zoneFlipNow(asset, L, tick, o, fiveHLNow(asset)); if (zf && zf === side) return ""; } catch {}
  const cb = candleBreaks(asset, wallLines(asset, L), o, tick, undefined, fiveHLNow(asset));
  // CANDLE FLIP AT THE SESSION BAND (Oct 20 ~12:37 AM PT, Love: "if pink is broken, and price rejects at the session band below and a red
  // candle FLIPS GREEN - MUST FLIP GREEN - in that scenario, yes. inverse applies as well. must be a candle flip at the session band to
  // enter though"): when THIS candle's break the other way was the PINK alone (no session band broke that way), and price tapped a session
  // band past it without breaking it, and the candle has FLIPPED back across its open - the rejection off the session band may trade
  // against the pink break's direction. A session-band break keeps its crown: no override over one, ever.
  try {
    const hlF = fiveHLNow(asset);
    const tapF = PINK_TAP[asset] ?? 0, brkF = BREAK_DIST[asset] ?? 0;
    const sessF = L.filter((l) => isSessBand(l) && Number(l.price) > 0);
    if (hlF && tapF > 0 && brkF > 0 && sessF.length) {
      const cbS = candleBreaks(asset, sessF, o, tick, undefined, hlF);
      if (side === "up" && cb.down && String(cb.down.band?.name) === "5m PP" && !cbS.down && tick > o && hlF.l < o &&
          sessF.some((b) => hlF.l <= b.price + tapF && hlF.l > b.price - brkF && tick > b.price)) return "";
      if (side === "down" && cb.up && String(cb.up.band?.name) === "5m PP" && !cbS.up && tick < o && hlF.h > o &&
          sessF.some((b) => hlF.h >= b.price - tapF && hlF.h < b.price + brkF && tick < b.price)) return "";
    }
  } catch {}
  if (side === "up" && cb.down) return `this 5m candle broke DOWN through ${cb.down.band.name} (${Number(cb.down.band.price).toFixed(2)}) - band breaks down = trade down`;
  if (side === "down" && cb.up) return `this 5m candle broke UP through ${cb.up.band.name} (${Number(cb.up.band.price).toFixed(2)}) - band breaks up = trade up`;
  return "";
}
export function awayVerdict(asset: string, L: Line[], tick: number, side: string, Bk: Map<string, "up" | "down">, o: { nowS?: number; st?: Record<string, { side: string; at: number }>; pinkFree?: boolean; sessRej?: boolean; trail?: { t: number; c: number }[]; open?: number } = {}, extra: Line[] = []): string {
  if (!(tick > 0) || !(side === "up" || side === "down")) return "";
  void o; // NO BREAK EXEMPTION (Oct 18 ~2:02 PM PT, Love: "just make her stop longing into a band above her. make her stop shorting into a band below
  // her. closest session band = trade. away. from. it."). 2:01:43 PM: the Bollinger book longed with -1σ $46 above because a 5m R1 (red line) broke
  // up that candle and the exemption let it through. A session band price broke through sits behind her, so a real break already points her right.
  // SESSION BANDS DECIDE THE SIDE (Oct 18 ~1:59 PM PT, Love: "session band above = closer to her than the session band below her == SHORT. NOT.
  // LONG. session band below her closer [than] the session band above = LONG. NOT. SHORT."). Any distance.
  // CHANNEL = HER SESSION BANDS (Oct 18 ~7:45 PM PT, Love: "if price is inside of the top of the channel, closer to the top band than she is the lower
  // band, i do not want her to long into it. i want her to short... closer to the band below than above = long"): only the session bands pick the side;
  // the Bollinger bands (extra) are walls in front within range, like the pivot lines, and never move the middle of her channel.
  // a session band THIS candle broke in the trade's direction stays broken (not a wall, not a channel edge) until a candle closes back past it
  let brokeNow = new Set<string>();
  try {
    if (side === "up" || side === "down") {
      let trB = o.trail;
      if (!trB && !G.__stDefaultReach) { const tk = Object.keys(G).filter((k) => /^__qtrail_\d+$/.test(k)).sort((a, b) => Number(b.slice(9)) - Number(a.slice(9)))[0]; const f0 = Math.floor(Date.now() / 300000) * 300000; trB = ((tk && G[tk]?.[asset]) || []).filter((x: any) => x && x.c > 0 && x.t >= f0); }
      const opB = o.open ?? (G.__stDefaultReach ? 0 : fiveOpenNow(asset));
      const dB = BREAK_DIST[asset] ?? 0;
      if (opB > 0 && dB > 0 && trB && trB.length) {
        for (const b of L.filter((l) => isSessBand(l) && Number(l.price) > 0)) {
          let st0: string | null = opB > b.price ? "above" : opB < b.price ? "below" : null;
          for (const x of [...trB, { t: Number.MAX_SAFE_INTEGER, c: tick }]) {
            if (side === "up" && st0 === "below" && x.c >= b.price + dB) { brokeNow.add(b.name); break; }
            if (side === "down" && st0 === "above" && x.c <= b.price - dB) { brokeNow.add(b.name); break; }
          }
        }
      }
    }
  } catch { brokeNow = new Set(); }
  const S = wallFor(wallLines(asset, L).filter((l) => Number(l.price) > 0 && isSessBand(l) && !brokeNow.has(l.name)), Bk, tick, side);
  const up = S.filter((l) => l.price > tick).sort((a, b) => a.price - b.price)[0], dn = S.filter((l) => l.price < tick).sort((a, b) => b.price - a.price)[0];
  // PRESSED PAST AN UNBROKEN BAND IS STILL AT THE BAND - ALL BOOKS (Oct 19 ~11:23 PM PT, Love: "and yes, fix the blind spot"
  // after the 11:00:04 PM gold short 23c under unbroken -2σ): same guard as channelOnly. While this 5m candle opened on the far
  // side and price sits within break distance past an unbroken band, that band is still her floor (or ceiling) - only trades away
  // from it may fire. A real break (her break distance, or a 1m close through) is excluded above and trades the break untouched.
  try {
    const dPk = BREAK_DIST[asset] ?? 0;
    const oPk = o.open ?? (G.__stDefaultReach ? 0 : fiveOpenNow(asset));
    if (dPk > 0 && oPk > 0) {
      if (side === "down") {
        const pr = S.filter((l) => l.price > tick && l.price - tick < dPk && oPk > l.price && Bk.get(l.name) !== "down").sort((a, b) => b.price - a.price)[0];
        if (pr) return `would short pressed $${(pr.price - tick).toFixed(2)} under unbroken ${pr.name} (${pr.price.toFixed(2)}) - a poke short of her break distance is not a break, that band is still her floor - longs only here`;
      }
      if (side === "up") {
        const pr = S.filter((l) => l.price < tick && tick - l.price < dPk && oPk < l.price && Bk.get(l.name) !== "up").sort((a, b) => a.price - b.price)[0];
        if (pr) return `would long pressed $${(tick - pr.price).toFixed(2)} over unbroken ${pr.name} (${pr.price.toFixed(2)}) - a poke short of her break distance is not a break, that band is still her ceiling - shorts only here`;
      }
    }
  } catch {}
  // TOP / BOTTOM 20% OF THE CHANNEL (Oct 18 ~8:04 PM PT, Love: "a band that is $143 away is not an obstacle... can you just make it the top 20% of the
  // channel? no longs into it if a band is unbroken / no shorts into the bottom 20% of the channel if the band is unbroken / if the band breaks, trade
  // the direction of the break"): channel = the nearest unbroken session band below to the nearest unbroken session band above. Long refused only in its
  // top 20%, short refused only in its bottom 20%; anywhere else the channel doesn't block. Replaces the closest-band rule, the 10% neutral zone and
  // the $25 cap on session bands. A break is judged by the latest-break rule (candleBreakAgainst).
  const frac = up && dn ? (tick - dn.price) / (up.price - dn.price) : -1;
  // GOLD 30% (Oct 18 ~10:16 PM PT, Love: "we can make the channel on gold from 20% to 30% right now"): live-switch channelPct[asset], default 20%.
  let cp = 0.2; if (!G.__stDefaultReach) { try { const v = Number(JSON.parse(readFileSync(D("live-switch.json"), "utf8"))?.channelPct?.[asset]); if (v > 0 && v < 0.5) cp = v; } catch {} }
  if (side === "up" && up && dn && frac >= 1 - cp) return `would long INTO ${up.name} ($${(up.price - tick).toFixed(2)} above, unbroken) - price is in the top ${Math.round(cp * 100)}% of her channel (${dn.name} ${dn.price.toFixed(2)} to ${up.name} ${up.price.toFixed(2)})`;
  // GOLD: NO BAND WITHIN $1.50 IN FRONT, SESSION BANDS TOO (Oct 18 ~10:03 PM PT, Love: "i just told you. not into a band within $1.50 for gold" - 10:00 PM
  // long with +2σ $1.30 above, allowed by the 20% rule): on gold an unbroken session band within her gold range (live-switch bandReach, $1.50) in front
  // of the trade blocks it, on top of the 20% channel rule.
  // + BTC (Oct 18 ~11:48 PM PT, Love: "i want her to do the same thing for btc. exactly." - after the 11:45 PM gold short off the pink): the same session-band
  // range on BTC, at BTC's range ($25).
  if (asset === "gold" || asset === "btc") {
    const fr = side === "up" ? up : dn;
    if (fr && inReach(asset, fr.price, tick)) return `would ${side === "up" ? "long" : "short"} INTO ${fr.name} ($${Math.abs(fr.price - tick).toFixed(2)} ${side === "up" ? "above" : "below"}, unbroken) - inside her $${bandReach(asset)} ${asset} range`;
  }
  // FALLING FROM THE TOP THIRD (Oct 18 ~11:07 PM PT, Love: "if price is actively falling from the top 33% of the channel, no long / if price is actively
  // rising from the bottom 33% of the channel, no short"): this 5m candle's high (its open included) sat in the top 33% of her channel and price is still
  // falling from it - at least half her break distance under that high and not yet bounced her break distance (BTC $8 / gold 33c) off the low since -
  // = no long. Mirror for shorts from the bottom 33%.
  if (up && dn) {
    // FROZEN (Oct 19 ~12:19 AM PT, Love: "freeze it til it's frozen - until i say to thaw it" - data/FROZEN.json): this rule keeps its own distances,
    // BTC $8 / gold 33c, whatever the break distance elsewhere becomes.
    const FROZEN_THIRD_DIST: Record<string, number> = { btc: 8, gold: 0.33 };
    const dist = FROZEN_THIRD_DIST[asset] ?? 0, w = up.price - dn.price;
    let tr = o.trail;
    if (!tr && G.__stDefaultReach) tr = []; // the self-test never reads her live prices
    if (!tr) { const tk = Object.keys(G).filter((k) => /^__qtrail_\d+$/.test(k)).sort((a, b) => Number(b.slice(9)) - Number(a.slice(9)))[0]; const f0 = Math.floor(Date.now() / 300000) * 300000; tr = ((tk && G[tk]?.[asset]) || []).filter((x: any) => x && x.c > 0 && x.t >= f0); }
    const op = o.open ?? (G.__stDefaultReach ? 0 : fiveOpenNow(asset));
    const pts = [...(op > 0 ? [{ t: 0, c: op }] : []), ...(tr || []), { t: Number.MAX_SAFE_INTEGER, c: tick }];
    if (dist > 0 && w > 0 && pts.length > 1) {
      if (side === "up") {
        let hi = pts[0], i0 = 0; pts.forEach((p, i) => { if (p.c >= hi.c) { hi = p; i0 = i; } });
        const loAfter = Math.min(...pts.slice(i0).map((p) => p.c));
        if ((hi.c - dn.price) / w >= 0.67 && hi.c - tick >= dist / 2 && tick - loAfter < dist) return `price is falling from the top third of her channel (high ${hi.c.toFixed(2)}, now ${tick.toFixed(2)}, ${dn.name} ${dn.price.toFixed(2)} to ${up.name} ${up.price.toFixed(2)}) - no long while it falls`;
      } else {
        let lo = pts[0], i0 = 0; pts.forEach((p, i) => { if (p.c <= lo.c) { lo = p; i0 = i; } });
        const hiAfter = Math.max(...pts.slice(i0).map((p) => p.c));
        if ((lo.c - dn.price) / w <= 0.33 && tick - lo.c >= dist / 2 && hiAfter - tick < dist) return `price is rising from the bottom third of her channel (low ${lo.c.toFixed(2)}, now ${tick.toFixed(2)}, ${dn.name} ${dn.price.toFixed(2)} to ${up.name} ${up.price.toFixed(2)}) - no short while it rises`;
      }
    }
  }
  if (side === "down" && up && dn && frac <= cp) return `would short INTO ${dn.name} ($${(tick - dn.price).toFixed(2)} below, unbroken) - price is in the bottom ${Math.round(cp * 100)}% of her channel (${dn.name} ${dn.price.toFixed(2)} to ${up.name} ${up.price.toFixed(2)})`;
  // PINK BY A SESSION BAND = WAIT FOR ITS BREAK (Oct 18 ~2:31 PM PT, Love: "if the pink band is directly above/below one of the session bands, wait until
  // it breaks the pink band before entering. do not long at a session band if the pink band has not been broken through if it is in the immediate area.
  // within $25. same goes for shorts" - gold $2.22): an unbroken pink in front of the trade within range of the band she's trading off = wait.
  const behind = side === "up" ? dn : up;
  const pk = o.pinkFree ? undefined : wallLines(asset, L).find((l) => l.name === "5m PP" && Number(l.price) > 0);
  if (behind && pk && Bk.get(pk.name) !== side && (side === "up" ? pk.price > tick : pk.price < tick) && Math.abs(pk.price - behind.price) <= bandReach(asset)) return `waiting for the pink to break: 5m PP (${pk.price.toFixed(2)}, unbroken) sits $${Math.abs(pk.price - behind.price).toFixed(2)} from ${behind.name} - no ${side === "up" ? "long" : "short"} until it breaks`;
  // the pink / pivot lines never pick the side; an unbroken one right in front (within her $25 / $2.22) is still a wall
  // a pivot line price already broke through (either way) is no wall for a session-band rejection; the pink keeps its own rules above
  const P = wallFor([...wallLines(asset, o.pinkFree ? noPink(L) : L), ...extra].filter((l) => Number(l.price) > 0 && !isSessBand(l) && inReachL(asset, l, tick) && !(o.sessRej && l.name !== "5m PP" && Bk.has(l.name))), Bk, tick, side);
  const wl = P.find((l) => (side === "up" ? l.price > tick : l.price < tick));
  if (wl) return `would ${side === "up" ? "long" : "short"} INTO ${wl.name} ($${Math.abs(wl.price - tick).toFixed(2)} ${wl.price > tick ? "above" : "below"}, unbroken, within range)`;
  return "";
}

// HER SIDE-OF-THE-BAND RULE (Oct 16 ~2:22 PM PT, Love: "PRICE = REJECTING UP AWAY FROM BAND ===== LONG / PRICE = FALLING DOWN
// AWAY FROM A BAND = SHORT"): the band that matters is the band her setup is about (the one price broke or rejected), not
// whichever band happens to be a few dollars closer. Long only while price is ABOVE that band, short only while BELOW it.
// A row with no setup band (the inverse) falls back to the closest band.
function setupBand(ticker: string, book: string, side = ""): { name: string; price: number } | null {
  if (!ticker || !book) return null;
  try {
    const c = (G.__setupRows ||= { at: 0, rows: [] as any[] });
    if (Date.now() - c.at > 2000) { const rs = JSON.parse(readFileSync(D("grok-og.json"), "utf8")); c.rows = Array.isArray(rs) ? rs.slice(0, 400) : []; c.at = Date.now(); }
    // same side only (Oct 16 ~11:15 PM PT): an "other side" row carries no setup band, and must not be judged by the refused side's band
    const r = c.rows.find((x: any) => x && x.ticker === ticker && x.lane === book && (!side || x.side === side) && x.band && Number(x.band.price) > 0);
    if (!r) return null;
    // ZONES (Oct 16 ~2:24 PM PT, Love: "why would a short off of the red zone be refused ???"): the red zone is R1 up to R2 and
    // the green zone S1 down to S2 - a rejection anywhere in the zone is the trade. So a red-zone short is judged against the
    // TOP of the zone (short while price is under R2) and a green-zone long against its BOTTOM (long while price is over S2).
    const gl = r.goldLaw || {};
    if (r.side === "down" && Number(gl.ceil) > 0) return { name: `${r.band.name} zone top`, price: Number(gl.ceil) };
    if (r.side === "up" && Number(gl.floor) > 0) return { name: `${r.band.name} zone bottom`, price: Number(gl.floor) };
    return { name: String(r.band.name), price: Number(r.band.price) };
  } catch { return null; }
}
export function sideOfBandOk(bandPx: number, tick: number, side: string): boolean {
  return side === "up" ? tick > bandPx : side === "down" ? tick < bandPx : false;
}
// GREEN IS FOR LONGS, RED IS FOR SHORTS (Oct 19 ~1:10 AM PT, Love: "THE GREEN LINE IS NOT A REASON FOR REJECTION FOR A LONG. GREEN IS MEANT TO LONG. DO NOT
// BLOCK A LONG IN THE GREEN ZONE. DO NOT BLOCK A SHORT IN THE RED ZONE." - 1:00:39 AM gold long on the break up through -1σ refused for 5m S1 76c above):
// the green lines (5m S1/S2) are never a wall, a rejection or a line to cross for a long; the red lines (5m R1/R2) never for a short. The break rule
// (a break down is never a long) and the red/green zone rule (no long into the red, no short into the green) are unchanged.
const rgOffFor = (side: string) => (X: Line[]) => X.filter((l) => !(side === "up" ? /^5m S[12]$/ : /^5m R[12]$/).test(String(l.name)));
export const PASS_THRU = new Set<string>(["brk-sesspk"]);
// CURRENT CANDLE = THE DIRECTION (Oct 19 ~4:54 PM PT, Love: "current candle band breaks down = trade down / current candle breaks band up = trade up /
// good for one candle. not hours"): her candle-break rule (candleBreaks - every band this 5m candle broke, her break distance, the last way it broke)
// applies to the session + pink book again, at paper and at the Kalshi door. Only for this 5m candle; the next candle starts fresh.
export function candleDirAgainst(asset: string, L: Line[], tick: number, side: string): string {
  const o = fiveOpenNow(asset);
  if (!(o > 0) || !(tick > 0)) return "";
  const cb = candleBreaks(asset, L, o, tick, undefined, fiveHLNow(asset));
  if (side === "up" && cb.down) return `this 5m candle broke DOWN through ${cb.down.band.name} (${Number(cb.down.band.price).toFixed(2)}) - trade down only this candle`;
  if (side === "down" && cb.up) return `this 5m candle broke UP through ${cb.up.band.name} (${Number(cb.up.band.price).toFixed(2)}) - trade up only this candle`;
  // THE BREAK IS IN THIS CANDLE (Oct 19 ~5:00 PM PT - 5:00:20 PM gold short off the 4:59 candle's close under the pink while the 5:00 candle hadn't broken
  // anything; it broke UP 10 s later): she trades a break only once THIS 5m candle has broken a band that way.
  if (!cb.last) return `waiting: this 5m candle hasn't broken a band ${side === "up" ? "up" : "down"} yet`;
  return "";
}
// BREAKS GO THROUGH A LINE IN THE WAY (Oct 19 ~3:18 PM PT, Love: "pls let her trade the breaks" + "Yes, session + pink only" - 3:16 PM gold broke
// down through the pink and her short was refused "would short INTO 5m S1 ($1.11 below)"): for these books a line between price and the strike
// (or the closest band ahead) never refuses a break. Every other rule stays. brk-sess keeps its wall.
export const WALL_FREE = new Set<string>(["brk-sesspk"]);

// RED/GREEN ZONES AT THE RECON DOOR (Oct 20 ~12:22 AM PT, Love: "yes i do" + "the ideal red/green zones would be $1.50" - the 12:15:12 AM
// gold short filled $1.37 above the green S1 and died): no short toward the green zone, no long toward the red zone, when price is inside
// it or its near edge is within $1.50 on gold / her $50 clearance on BTC (Oct 19 ~9:31 PM PT). Price through the FAR edge = the zone is
// broken behind her - not a barrier. Can't read the zones = can't verify = no order (never blind).
export function reconZoneGate(asset: string, tick: number, side: string): string {
  if (!(tick > 0) || !(side === "up" || side === "down")) return "";
  const Z = zonesNow(asset);
  if (!Z) return "can't verify the red/green zones right now";
  const reach = asset === "gold" ? 1.5 : 50;
  if (side === "down" && tick > Z.s2) {
    if (tick <= Z.s1) return `would short inside the green zone (${Z.s2.toFixed(2)}-${Z.s1.toFixed(2)}) - longs only off a rejection there`;
    if (tick - Z.s1 <= reach) return `would short into the green zone $${(tick - Z.s1).toFixed(2)} above its edge (her $${reach} zone rule)`;
  }
  if (side === "up" && tick < Z.r2) {
    if (tick >= Z.r1) return `would long inside the red zone (${Z.r1.toFixed(2)}-${Z.r2.toFixed(2)}) - shorts only off a rejection there`;
    if (Z.r1 - tick <= reach) return `would long into the red zone $${(Z.r1 - tick).toFixed(2)} under its edge (her $${reach} zone rule)`;
  }
  return "";
}


// NO TRADE AGAINST THE CANDLE AT THE CHANNEL'S EDGE - RECON (Oct 20 ~1:32 AM PT, Love: "she longed btc in the top 33% of the channel
// after price broke the pink band while the candle was falling from the top 33% - that's a short ... she shorted on a rising candle
// from the bottom 33% on the last window and that lost as well. tighten that up"): the same falling-from-the-top-third /
// rising-from-the-bottom-third wall her classic books carry (awayVerdict's FROZEN rule, BTC $8 / gold 33c), now at the RECON door.
// Falling from the top third refuses longs; rising from the bottom third refuses shorts. Breaks don't excuse it - her words above
// were about a candle that HAD broken the pink.
export function reconThirdAgainst(asset: string, L: Line[], tick: number, side: string, Bk: Map<string, "up" | "down">): string {
  if (!(tick > 0) || !(side === "up" || side === "down")) return "";
  const RT_DIST: Record<string, number> = { btc: 8, gold: 0.33 };
  const dist = RT_DIST[asset] ?? 0;
  const o = fiveOpenNow(asset);
  const S = wallFor(wallLines(asset, L).filter((l) => Number(l.price) > 0 && isSessBand(l)), Bk, tick, side);
  const up = S.filter((l) => l.price > tick).sort((a, b) => a.price - b.price)[0], dn = S.filter((l) => l.price < tick).sort((a, b) => b.price - a.price)[0];
  if (!up || !dn || !(o > 0) || !(dist > 0)) return "";
  const w = up.price - dn.price;
  const tk = Object.keys(G).filter((k) => /^__qtrail_\d+$/.test(k)).sort((a, b) => Number(b.slice(9)) - Number(a.slice(9)))[0];
  const f0 = Math.floor(Date.now() / 300000) * 300000;
  const tr = ((tk && G[tk]?.[asset]) || []).filter((x: any) => x && x.c > 0 && x.t >= f0);
  const pts = [{ t: 0, c: o }, ...tr, { t: Number.MAX_SAFE_INTEGER, c: tick }];
  if (!(w > 0) || pts.length < 2) return "";
  if (side === "up") {
    let hi = pts[0], i0 = 0; pts.forEach((p, i) => { if (p.c >= hi.c) { hi = p; i0 = i; } });
    const loAfter = Math.min(...pts.slice(i0).map((p) => p.c));
    if ((hi.c - dn.price) / w >= 0.67 && hi.c - tick >= dist / 2 && tick - loAfter < dist) return `price is falling from the top third of her channel (high ${hi.c.toFixed(2)}, now ${tick.toFixed(2)}, ${dn.name} ${dn.price.toFixed(2)} to ${up.name} ${up.price.toFixed(2)}) - that's a short, not a long`;
  }
  if (side === "down") {
    let lo = pts[0], i0 = 0; pts.forEach((p, i) => { if (p.c <= lo.c) { lo = p; i0 = i; } });
    const hiAfter = Math.max(...pts.slice(i0).map((p) => p.c));
    if ((lo.c - dn.price) / w <= 0.33 && tick - lo.c >= dist / 2 && hiAfter - tick < dist) return `price is rising from the bottom third of her channel (low ${lo.c.toFixed(2)}, now ${tick.toFixed(2)}, ${dn.name} ${dn.price.toFixed(2)} to ${up.name} ${up.price.toFixed(2)}) - that's a long, not a short`;
  }
  return "";
}

export function bandLockCheck(book: string, asset: string, side: string, ticker = ""): { ok: true } | { ok: false; reason: string } {
  // EVERY BOOK (Oct 16 ~1:10 PM PT, Love: "EVERY FUCKING BOOK WE OWN. EVERYTHING THAT EVER RUNS."): no exemptions - the
  // inverse included, any asset. An asset with no band feed can't be verified, so it can't open.
  void LAW_BOOKS;
  const deny = (reason: string, extra: Record<string, unknown> = {}) => {
    try { appendFileSync(D("band-lock.jsonl"), JSON.stringify({ at: new Date().toISOString(), book, asset, side, reason, ...extra }) + "\n"); } catch {}
    return { ok: false as const, reason };
  };
  if (!(asset === "gold" || asset === "btc")) return deny(`no band feed for ${asset} to verify against - it can't open`);
  // RECONSTRUCTED (Oct 19 ~6:16 PM PT, Love: "that exact configuration that traded that way that day"): the Oct 12 book had no band lock at the door -
  // its two refusals live in recon.ts at the decision. Here: a fresh price and a healthy feed, nothing else.
  if (RECON.has(book)) {
    const qR = quoteTick(asset); if (!qR || !(qR.c > 0) || Date.now() - qR.at > 3000) return deny("can't verify the price right now (no fresh price)");
    const fhR = feedHealth(asset); if (!fhR.ok) return deny(`price feed not healthy (${fhR.why})`);
    // + HER 33% CHANNEL RULE (Oct 19 ~6:33 PM PT, Love) - the one addition to the Oct 12 door.
    const lbR = G.__lawBands?.[asset];
    if (!lbR || !Array.isArray(lbR.L) || !lbR.L.length || Date.now() - Number(lbR.at) > 15000) return deny("can't verify the channel right now (band list not fresh)");
    const chR = channelOnly(asset, lbR.L, qR.c, side, refreshBroken(asset, lbR.L, qR.c)); // REJECTION OVERRIDE REMOVED (Oct 19 ~9:18 PM PT, Love: "let's remove the pink band rejection override... she shorted here and it would have been rejected for being in the bottom 33% on gold" - the wall rules over rejections again)
    if (chR) return deny(chR, { tick: qR.c });
    const cdR = candleDirOnly(asset, lbR.L, qR.c, side); // band breaks up = trade up (Oct 19 ~6:34 PM PT, Love)
    if (cdR) return deny(cdR, { tick: qR.c });
    const zR = reconZoneGate(asset, qR.c, side); // her red/green zones at the recon door (Oct 20 ~12:22 AM PT, Love: "yes i do")
    if (zR) return deny(zR, { tick: qR.c });
    const tR = reconThirdAgainst(asset, lbR.L, qR.c, side, refreshBroken(asset, lbR.L, qR.c)); // falling-from-top / rising-from-bottom wall (Oct 20 ~1:32 AM PT, Love: "tighten that up")
    if (tR) return deny(tR, { tick: qR.c });
    return { ok: true };
  }
  if (G.__bandLawBroken) return deny("band law failed its self-test - no orders until it passes");
  const lb = G.__lawBands?.[asset];
  if (!lb || !Array.isArray(lb.L) || !lb.L.length || Date.now() - Number(lb.at) > 15000) return deny("can't verify the closest band right now (band list not fresh)");
  // NEVER BLIND (Oct 17 ~2:42 PM PT, Love: "yes, both please"): no session bands on her list = can't verify = no order.
  if (!lb.L.some((l: Line) => /σ$|^session VWAP$/.test(String(l.name)))) return deny("can't verify the session bands right now (none on her list)");
  const q = quoteTick(asset);
  if (!q || !(q.c > 0) || Date.now() - q.at > 3000) return deny("can't verify the closest band right now (no fresh price)");
  const fh = feedHealth(asset);
  if (!fh.ok) return deny(`price feed not healthy (${fh.why})`);
  // PAPER = KALSHI (Oct 19 ~3:06 PM PT, Love: "just let her trades go thru when she takes them" + "let her trades thru for now ok we'll see if we
  // need to revise"): the session + pink break book's paper call goes straight to Kalshi - the door doesn't re-judge her band rules
  // (the 3:00 PM BTC long was booked on paper and refused here 700+ times). Feed health, fresh price and the 1.36x floor still apply.
  // ONE RULEBOOK FOR SESSION + PINK (Oct 19 ~5:25 PM PT, Love: "yes pls"): since 3:10 PM PASS_THRU let this book skip every band rule at the door
  // (8-4, +$6.06 before; 6-8, -$84.79 after - 4:45 PM gold it longed "Close above -2σ" while SESSION ONLY shorted the same band and won). It now runs
  // the same band law as SESSION ONLY (brk-sess). Kept from her 3:19 PM asks: no line-to-strike wall on a break (WALL_FREE), red/green zones off
  // (ZONES_OFF). Kept from 5:06 PM: the break must be in THIS 5m candle (candleDirAgainst). The 75c ceiling (floorFor) is unchanged.
  if (PASS_THRU.has(book)) { const cdA = candleDirAgainst(asset, wallLines(asset, lb.L), q.c, side); if (cdA) return deny(cdA, { tick: q.c }); }
  // NO TRADE AGAINST A BREAK IN THIS CANDLE (Oct 16 ~2:52 PM PT, Love: "SHE SHOULD NOT SHORT A RISING CANDLE THAT BROKE UP
  // THRU A BAND"): if the live 5m candle is rising and price has crossed up through a band since it opened, no short; if it is
  // falling and has crossed down through a band, no long. Checked on every order, whatever the setup was.
  // INVERSE TEST (Oct 16 ~4:05 PM PT, Love: "run the inverse book on the next windows @ $5 up through to 5pm... if she correctly
  // fires on the inverse book, that is a backwards fire on our main ones"). The inverse trades AGAINST the twin's call, so the
  // band rules below would refuse every order it makes; for her test it skips them (feed health still applies). Off at 5 PM.
  if (book === "ogp5-inv") { try { if (JSON.parse(readFileSync(D("live-switch.json"), "utf8"))?.invTest4pm) return { ok: true }; } catch {} }
  const W = wallLines(asset, lb.L);
  const rgOff = rgOffFor(side);
  const LZ: Line[] = rgOff(ZONES_OFF.has(book) ? noZ(lb.L) : lb.L);
  const rtD0 = pinkRetest(asset, lb.L, q.c); const rtD = !!(rtD0 && rtD0.side === side); // broke, tapped the pink, rejected = her entry (Oct 19 ~12:56 / 1:05 AM PT)
  const brk = rtD ? "" : candleBreakAgainst(asset, W, q.c, side) || sessionBreakPinkHold(asset, lb.L, q.c, side) || pinkRejectAgainst(asset, LZ, q.c, side) || (ZONES_OFF.has(book) || NO_REJ_HOLD.has(book) ? "" : rejCarryAgainst(asset, LZ, q.c, side)); // NO REJECTION HOLD on the session + pink book (Oct 17 ~6:33 PM PT, Love: "Remove the hold" - a push off a band goes straight in)
  if (brk) return deny(brk, { tick: q.c });
  const Bk = refreshBroken(asset, lb.L, q.c);
  const Wall = wallFor(rgOff(W), Bk, q.c, side); // broken walls don't block the break direction (Oct 17 ~1:19 / 1:38 AM PT)
  const tg = WALL_FREE.has(book) ? "" : crossToTarget(asset, Wall, q.c, side, targetNow(asset)); // no band between price and the target (Oct 17 ~2:02 AM PT); not for WALL_FREE books (Oct 19 ~3:18 PM PT), door = paper
  if (tg) return deny(tg, { tick: q.c, target: targetNow(asset) });
  const ab = NO_AT_WAIT.has(book) || rtD ? "" : atSessionBand(asset, Wall, q.c); // at the session band = wait (Oct 17 ~10:41 AM PT)
  if (ab) return deny(ab, { tick: q.c });
  // SESSION-AHEAD WAIT RETIRED (Oct 17 ~4:20 PM PT, Love: "pink band was plainly in the middle of the channel. price breaks pink band = get in. don't wait until
  // it's at the top of the channel to get in") - the 25% rule decides how high she can be. The $6 pink break still applies.
  const sa = NO_AT_WAIT.has(book) || rtD ? "" : atPink(asset, Wall, q.c);
  if (sa) return deny(sa, { tick: q.c });
  const pr = ROOM_TWIN[book] ? pinkInFront(asset, Wall, q.c, side, fiveOpenNow(asset), ROOM_TWIN[book]) : ""; // room rule only on its paper twins now (Oct 17 ~3:19 PM PT)
  if (pr) return deny(pr, { tick: q.c });
  const zg = ZONES_OFF.has(book) ? "" : zoneGate(asset, lb.L, q.c, side);
  if (zg) return deny(zg, { tick: q.c });
  const sb = setupBand(ticker, book, side);
  if (sb) {
    if (!sideOfBandOk(sb.price, q.c, side)) return deny(`would ${side === "up" ? "long" : "short"} on the wrong side of ${sb.name} (her setup band) - price ${q.c} vs band ${sb.price}`, { tick: q.c, band: sb });
  }
  // CLOSEST BAND DECIDES, EVERY ORDER (Oct 16 ~10:30 PM PT, Love: "when an unbroken band is closer in front of her than it is the
  // band behind it, she is to trade THAT band"): a setup band no longer skips this check. Closest band above price = short only,
  // closest band below = long only. Replay of Oct 14-16 live fills: 68 main-book fills went against the closest band, 44% right.
  const ns = nearSide(Wall, q.c);
  if (!ns) return deny("can't verify the closest band right now");
  // CLOSEST BAND IS BACK (Oct 17 ~4:54 PM PT, Love: "put it back under the closest band rule again hun") - replaces the 25% rule.
  let sRej = false; try { const c = G.__setupRows; const r = c && Array.isArray(c.rows) ? c.rows.find((x: any) => x && x.ticker === ticker && x.lane === book && x.side === side && x.band) : null; sRej = isSessRej(r); } catch {}
  { const aw = awayVerdict(asset, rgOff(lb.L), q.c, side, Bk, { sessRej: sRej }, BB_BOOKS.has(book) ? bbLines(asset) : []); if (aw) return deny(aw, { tick: q.c, band: ns.band }); } // HER RULE: away from the closest band, break = trade the break
  // PASS LOG (Oct 17 ~10:50 AM PT, after the 10:31 AM long under -2 sigma): what the gate saw on every order it let through. Read-out only.
  try { const near = Wall.slice().sort((a, b) => Math.abs(a.price - q.c) - Math.abs(b.price - q.c)).slice(0, 4).map((l) => ({ n: l.name, p: Math.round(l.price * 100) / 100 })); appendFileSync(D("band-pass.jsonl"), JSON.stringify({ at: new Date().toISOString(), book, asset, side, ticker, tick: q.c, near, dropped: W.filter((l) => !Wall.includes(l)).map((l) => l.name), broken: Object.fromEntries(Bk), target: targetNow(asset) }) + "\n"); } catch {}
  return { ok: true };
}

/** The gate's own rule: may an order on `side` go out with price `tick` and these bands? */
export function gateAllows(L: Line[], tick: number, side: string): boolean {
  const ns = nearSide(L, tick);
  return !!ns && (!ns.side || ns.side === side);
}
/** Self-test (no-flip version, Oct 16 ~2:20 PM PT): her setups may now disagree with the closest band - the GATE must refuse
 * every such order and pass every agreeing one. Random scenarios through the live goldLaw + the gate. Sets __bandLawBroken. */
// SELF-TEST ON THE DEFAULT RANGES (Oct 18 ~6:10 PM PT): the test cases are written for $25 BTC / $2.22 gold; a live-switch bandReach
// override (gold $1.11, Love ~5:53 PM PT) made 2 cases fail and the failed test blocked every order from 6:01 PM. The test now always
// runs on the defaults; live trading still uses her live-switch range.
export function bandSelfTest(goldLaw: (...a: any[]) => any, n = 2000): number {
  G.__stDefaultReach = true;
  try { return bandSelfTest0(goldLaw, n); } finally { G.__stDefaultReach = false; }
}
function bandSelfTest0(goldLaw: (...a: any[]) => any, n = 2000): number {
  let seed = (Date.now() % 100000) + 7;
  const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
  const bars = (open: number, k: number, vol: number) => { const out: any[] = []; let p = open; for (let i = 0; i < k; i++) { const o = p, c = o + (rnd() - 0.5) * vol; out.push({ o, c, h: Math.max(o, c) + rnd() * vol * 0.6, l: Math.min(o, c) - rnd() * vol * 0.6, t: i * 60 }); p = c; } return out; };
  const extra = ["+1σ", "-1σ", "+1.5σ", "-1.5σ", "+2σ", "-2σ", "session VWAP", "2m PP", "10m PP", "15m R1", "15m S1"];
  let bad = 0, calls = 0;
  for (let i = 0; i < n; i++) {
    const base = 4000 + rnd() * 80000, sp = base * (0.0002 + rnd() * 0.003), pp = base + (rnd() - 0.5) * sp * 2, st = sp * (0.5 + rnd());
    const L: Line[] = [{ name: "5m PP", price: pp }, { name: "5m R1", price: pp + st }, { name: "5m R2", price: pp + 2 * st }, { name: "5m S1", price: pp - st }, { name: "5m S2", price: pp - 2 * st }];
    for (const nm of extra) if (rnd() < 0.5) L.push({ name: nm, price: base + (rnd() - 0.5) * sp * 6 });
    const vol = sp * (0.2 + rnd() * 1.5), po = base + (rnd() - 0.5) * sp * 3, pb = bars(po, 5, vol), co = pb[4].c, nc = Math.floor(rnd() * 5), cb = bars(co, nc, vol);
    const tick = (nc ? cb[nc - 1].c : co) + (rnd() - 0.5) * vol * 2;
    const broken = L.filter(() => rnd() < 0.15).map((l) => ({ name: l.name, side: rnd() < 0.5 ? "up" : "down" }));
    let call: any = null;
    try { call = goldLaw(L, tick, { open: co, bars: cb }, { open: po, bars: pb }, nc ? cb[nc - 1] : pb[4], broken, null, false); } catch { bad++; continue; }
    if (!call) continue;
    calls++;
    const ns = nearSide(L, tick);
    const into = !!(ns && ns.side && ns.side !== call.side);
    if (gateAllows(L, tick, call.side) === into) bad++; // fallback gate must refuse exactly the into-band orders
    const bp = Number(call.band?.price);
    if (bp > 0 && sideOfBandOk(bp, tick, call.side) !== (call.side === "up" ? tick > bp : tick < bp)) bad++; // setup-band gate
  }
  { const T: Line[] = [{ name: "5m PP", price: 100 }];
    if (!candleBreakAgainst("x", T, 101, "down", 99)) bad++;   // rising candle broke up through PP -> short refused
    if (!candleBreakAgainst("x", T, 99, "up", 101)) bad++;     // falling candle broke down through PP -> long refused
    if (candleBreakAgainst("x", T, 101, "up", 99)) bad++;      // with the break -> allowed
    if (candleBreakAgainst("x", T, 99, "down", 101)) bad++; }
  { const Q: Line[] = [{ name: "session VWAP", price: 200, unit: 100 }, { name: "+1σ", price: 300, unit: 100 }, { name: "5m R1", price: 212 }];
    if (!pinkInFront("btc", Q, 200.5, "up")) bad++;    // $100 bands -> $15 room; R1 $11.50 above -> long refused
    if (pinkInFront("btc", Q, 170, "up")) bad++;       // VWAP $30 above -> ok
    if (!pinkInFront("btc", Q, 205, "down")) bad++;    // VWAP $5 below -> short refused
    if (pinkInFront("btc", Q, 250, "down")) bad++; }   // nearest band below $38 -> ok
  { const P: Line[] = [{ name: "5m PP", price: 100 }, { name: "5m R1", price: 123 }]; // no session unit -> flat fallback $25 / $1.50
    if (!pinkInFront("btc", P, 101, "up")) bad++;      // R1 $22 above (3:30 PM case) -> long refused
    if (!pinkInFront("btc", P, 90, "up")) bad++;      // pink $10 above -> long refused
    if (pinkInFront("btc", P, 70, "up")) bad++;       // pink $30 above -> long ok
    if (!pinkInFront("btc", P, 110, "down")) bad++;   // pink $10 below -> short refused
    if (pinkInFront("btc", P, 150, "up")) bad++;      // bands below a long -> ok
    if (!pinkInFront("gold", P, 99.5, "up")) bad++;   // gold $0.50 under pink -> long refused
    if (!pinkInFront("gold", P, 98.61, "up")) bad++;  // gold $1.39 under (the 12:45 PM case) -> refused
    if (pinkInFront("gold", P, 98.3, "up")) bad++; }  // gold $1.70 under -> ok
  { const Z = { pp: 100, r1: 110, r2: 120, s1: 90, s2: 80 }, V1 = { cur: 1, avg: 1, frac: 1 }, V3 = { cur: 3, avg: 1, frac: 1 };
    const S: Line[] = [{ name: "session VWAP", price: 115 }], F: Line[] = [{ name: "session VWAP", price: 50 }], G2: Line[] = [{ name: "session VWAP", price: 85 }];
    if (!zoneGate("x", S, 112, "up", { zones: Z, open: 108, vol: V1 })) bad++;   // long IN the red, band unbroken, weak volume -> refused
    if (zoneGate("x", S, 112, "up", { zones: Z, open: 108, vol: V3 })) bad++;    // same with strong volume -> long ok
    if (zoneGate("x", S, 116, "up", { zones: Z, open: 112, vol: V1 })) bad++;    // long IN the red after VWAP inside it broke up -> ok
    if (zoneGate("x", S, 112, "down", { zones: Z, open: 113, vol: V1 })) bad++;  // short IN the red (rejection, away from it) -> ok
    if (!zoneGate("x", F, 103, "up", { zones: Z, open: 101, vol: V1 })) bad++;   // R1 closest line above, weak volume -> long refused
    if (zoneGate("x", F, 103, "up", { zones: Z, open: 101, vol: V3 })) bad++;    // same with strong volume -> long ok
    if (zoneGate("x", F, 103, "down", { zones: Z, open: 104, vol: V1 })) bad++;  // short under the red -> ok
    if (zoneGate("x", F, 95, "up", { zones: Z, open: 94, vol: V1 })) bad++;      // long with S1 behind -> ok
    if (!zoneGate("x", F, 93, "down", { zones: Z, open: 95, vol: V1 })) bad++;   // S1 closest line below, weak volume -> short refused
    if (!zoneGate("x", G2, 87, "down", { zones: Z, open: 88, vol: V1 })) bad++;  // short IN the green, unbroken -> refused
    if (zoneGate("x", G2, 84, "down", { zones: Z, open: 88, vol: V1 })) bad++;   // short IN the green after VWAP inside it broke down -> ok
    if (zoneGate("x", F, 85, "up", { zones: Z, open: 84, vol: V1 })) bad++; }    // long IN the green (rejection, away) -> ok
  { const f0 = Math.floor(Date.now() / 300000) * 300, now = f0 + 120, P: Line[] = [{ name: "session VWAP", price: 100, unit: 110 }, { name: "5m PP", price: 115 }];
    const prevUp = [{ t: f0 - 300, o: 95, h: 104, l: 94, c: 103 }], prevFlat = [{ t: f0 - 300, o: 96, h: 99, l: 95, c: 98 }];
    if (!sessionBreakPinkHold("btc", P, 108, "down", { open: 95, bars: prevFlat, now })) bad++; // VWAP broke up THIS candle, pink $15 over -> no short
    if (!sessionBreakPinkHold("btc", P, 108, "up", { open: 95, bars: prevFlat, now })) bad++;   // ...and no long until the pink breaks
    if (sessionBreakPinkHold("btc", P, 108, "down", { open: 104, bars: prevUp, now })) bad++;   // new candle (broke last candle) -> pink rejection allowed
    if (sessionBreakPinkHold("btc", [{ name: "session VWAP", price: 100, unit: 110 }, { name: "5m PP", price: 140 }], 108, "down", { open: 95, bars: prevFlat, now })) bad++; // pink $40 away -> no hold
    if (!sessionBreakPinkHold("btc", [{ name: "session VWAP", price: 100, unit: 110 }, { name: "5m PP", price: 85 }], 92, "up", { open: 105, bars: prevFlat, now })) bad++; // mirror: no long off the pink this candle
    if (!candleBreakAgainst("x", [{ name: "+1σ", price: 100 }, { name: "5m PP", price: 90 }], 95, "up", 105, { h: 106, l: 89 })) bad++; } // falling candle broke +1σ, tapped pink -> still no long
  { const PP: Line[] = [{ name: "5m PP", price: 90 }];
    if (!candleBreakAgainst("btc", PP, 92, "up", 95, { h: 96, l: 81 })) bad++;   // punched $9 under the pink, snapped back -> a break: no long
    if (candleBreakAgainst("btc", PP, 92, "up", 95, { h: 96, l: 85 })) bad++;    // only $5 under -> a rejection: long ok
    if (!candleBreakAgainst("gold", PP, 90.5, "up", 91, { h: 91.2, l: 88.9 })) bad++; // gold $1.10 under -> break
    if (!candleBreakAgainst("btc", PP, 88, "down", 85, { h: 99, l: 84 })) bad++; } // mirror: punched $9 over, back under -> no short
  { const f0 = Math.floor(Date.now() / 300000) * 300, P: Line[] = [{ name: "5m PP", price: 90 }, { name: "session VWAP", price: 120, unit: 50 }];
    const st: any = {};
    if (!refreshBroken("btc", P, 92, { now: f0 + 100, open: 95, hl: { h: 96, l: 81 }, bars: [], state: st }).has("5m PP")) bad++;   // punched $9 through -> broken wall
    if (!refreshBroken("btc", P, 93, { now: f0 + 310, open: 93, hl: { h: 94, l: 91 }, bars: [{ t: f0, o: 95, h: 96, l: 81, c: 89 }], state: st }).has("5m PP")) bad++; // 5m closed 89, still under -> still broken
    if (refreshBroken("btc", P, 93, { now: f0 + 610, open: 93, hl: { h: 94, l: 91 }, bars: [{ t: f0 + 300, o: 93, h: 94, l: 91, c: 93 }], state: st }).has("5m PP")) bad++; // 5m closed 93 back over -> wall again
    const s2: any = {};
    refreshBroken("btc", P, 108, { now: f0 + 100, open: 125, hl: { h: 126, l: 105 }, bars: [], state: s2 });
    if (refreshBroken("btc", P, 122, { now: f0 + 130, open: 125, hl: { h: 126, l: 105 }, bars: [{ t: f0 + 60, o: 110, h: 122, l: 108, c: 121 }], state: s2 }).has("session VWAP")) bad++; } // 1m close back over VWAP -> wall again
  { const W: Line[] = [{ name: "+0.5σ", price: 81662, unit: 90 }, { name: "+1σ", price: 81707, unit: 90 }], Bk = new Map<string, "up" | "down">([["+1σ", "down"]]);
    if (!gateAllows(wallFor(W, Bk, 81696, "down"), 81696, "down")) bad++;  // +1 sigma broke down, still above: short allowed (the 1:36 AM case)
    if (gateAllows(wallFor(W, Bk, 81696, "up"), 81696, "up")) bad++;       // ...and the long under it refused
    const P2: Line[] = [{ name: "5m PP", price: 81675 }, { name: "+1σ", price: 81700, unit: 90 }], B2 = new Map<string, "up" | "down">([["5m PP", "down"]]);
    if (!gateAllows(wallFor(P2, B2, 81684, "down"), 81684, "down")) bad++; } // pink broke down, snapped back over: it can't block the short (12:46 case)
  { const T: Line[] = [{ name: "5m PP", price: 81689 }], U: Line[] = [{ name: "5m PP", price: 81660 }];
    if (!crossToTarget("btc", T, 81700, "down", 81669)) bad++;     // short at 81,700, pink 81,689 between it and the 81,669 target -> refused
    if (!crossToTarget("btc", U, 81650, "up", 81669)) bad++;       // long at 81,650, pink 81,660 between -> refused
    if (crossToTarget("btc", T, 81669.5, "up", 81669)) bad++;      // the 1:45 AM long: already at/past the target -> ok
    if (crossToTarget("btc", T, 81640, "up", 81669)) bad++;        // pink above the target, nothing between -> ok
    if (crossToTarget("btc", U, 81650, "down", 81669)) bad++;      // short already under the target -> ok
    if (!crossToTarget("btc", T, 81650, "up", 0)) bad++;           // no window-open price -> can't verify
    if (crossToTarget("btc", wallFor(U, new Map<string, "up" | "down">([["5m PP", "up"]]), 81655, "up"), 81655, "up", 81669)) bad++; } // pink broken up, no close back: not a wall -> ok
  if (Math.abs(chartTarget(81580, 81700 - 81640, 30) - 81670) > 0.001) bad++; // strike 81,580, index 81,640, Vantage 81,700 -> 81,670 on her chart
  { const T: Line[] = [{ name: "5m PP", price: 81690 }], U: Line[] = [{ name: "5m PP", price: 81665 }];
    if (crossToTarget("btc", T, 81700, "up", chartTarget(81580, 60, 30))) bad++;   // pink 81,690, long at 81,700: past 81,670 -> ok
    if (!crossToTarget("btc", U, 81660, "up", chartTarget(81580, 60, 30))) bad++; } // pink 81,665 between a long at 81,660 and the 81,670 target -> refused
  { const W2: Line[] = [{ name: "-2σ", price: 81292, unit: 128 }, { name: "5m PP", price: 81270 }];
    if (!atSessionBand("btc", W2, 81293)) bad++;   // the 10:31 AM long: $1 over -2 sigma -> wait
    if (!atSessionBand("btc", W2, 81288)) bad++;   // $4 under it -> wait
    if (atSessionBand("btc", W2, 81301)) bad++;    // $9 through -> the break, free
    if (atSessionBand("btc", W2, 81283)) bad++;    // pulled $9 back -> the rejection, free (closest band now decides the side)
    if (atSessionBand("btc", [{ name: "5m PP", price: 81270 }, { name: "-2σ", price: 81320, unit: 128 }], 81272)) bad++; // pink closest, not a session band -> this rule stays out
    if (!atSessionBand("gold", [{ name: "+1σ", price: 4165 }], 4165.3)) bad++;  // gold $0.30 off +1 sigma -> wait (50c break)
    if (atSessionBand("gold", [{ name: "+1σ", price: 4165 }], 4165.6)) bad++;   // gold $0.60 through -> free (50c break)
    if (atSessionBand("gold", [{ name: "+1σ", price: 4165 }], 4166.2)) bad++; } // gold $1.20 through -> free
  { const W3: Line[] = [{ name: "5m PP", price: 81526.19 }, { name: "session VWAP", price: 81558.05, unit: 130 }, { name: "-0.5σ", price: 81492.89, unit: 130 }];
    if (!sessionAheadWait("btc", W3, 81528.73, "up")) bad++;  // the 12:03 PM long: VWAP $29 ahead < -0.5 sigma $36 behind -> wait
    if (!sessionAheadWait("btc", W3, 81524, "down")) bad++;   // mirror: under the pink, -0.5 sigma $31 ahead < VWAP $34 behind -> wait
    if (sessionAheadWait("btc", W3, 81512, "up")) bad++;      // bounce off the pink with -0.5 sigma $19 behind, VWAP $46 ahead -> free
    if (sessionAheadWait("btc", W3, 81552, "down")) bad++; }  // closest wall is VWAP, not the pink -> this rule stays out
  { const PK: Line[] = [{ name: "5m PP", price: 81592.37 }];
    if (!pinkRejectAgainst("btc", PK, 81612.34, "down", { h: 81612.34, l: 81594.4 })) bad++; // the 1:01 PM short: tapped the pink, $20 up -> refused
    if (pinkRejectAgainst("btc", PK, 81612.34, "up", { h: 81612.34, l: 81594.4 })) bad++;    // the long with the rejection -> this rule stays out
    if (pinkRejectAgainst("btc", PK, 81597, "down", { h: 81598, l: 81593 })) bad++;          // only $4.63 up -> not a rejection yet
    if (pinkRejectAgainst("btc", PK, 81612, "down", { h: 81612, l: 81605 })) bad++;          // never came within $2 of the pink -> no tap
    if (pinkRejectAgainst("btc", PK, 81612, "down", { h: 81612, l: 81580 })) bad++;          // punched $12 under = a break, not a rejection
    if (!pinkRejectAgainst("btc", PK, 81570, "up", { h: 81591, l: 81570 })) bad++;           // mirror: tapped from below, $22 down -> no long
    if (!pinkRejectAgainst("gold", [{ name: "5m PP", price: 4165 }], 4166.3, "down", { h: 4166.3, l: 4165.1 })) bad++;
    if (!pinkRejectAgainst("btc", [{ name: "+0.5σ", price: 81622 }], 81605, "up", { h: 81621, l: 81605 })) bad++; } // session band: tapped +0.5 sigma from below, $17 down -> no long // gold tap $0.10, $1.30 up -> no short
  { const PW: Line[] = [{ name: "5m PP", price: 81606.6 }, { name: "+0.5σ", price: 81622.34, unit: 128 }, { name: "session VWAP", price: 81558.52, unit: 128 }];
    if (!atPink("btc", PW, 81602.76)) bad++;   // $3.84 under the pink -> wait ($8 pink wait, Oct 18 3:31 PM)
    if (!atPink("btc", [{ name: "5m PP", price: 81517.24 }, { name: "-0.5σ", price: 81492.61, unit: 128 }], 81522.5)) bad++; // $5.26 over -> wait
    if (!atPink("btc", PW, 81601.1)) bad++; /* $5.50 under -> still waiting ($6 break, Oct 19) */    // $6.70 under -> still waiting
    if (atPink("btc", PW, 81598)) bad++;       // $8.60 under -> broke: free
    if (atPink("btc", PW, 81618)) bad++;       // closest wall is +0.5 sigma, not the pink -> this rule stays out
    if (!atPink("gold", [{ name: "5m PP", price: 4165 }], 4165.3)) bad++;  // gold $0.30 -> wait (50c pink break)
    if (atPink("gold", [{ name: "5m PP", price: 4165 }], 4165.6)) bad++; } // gold $0.60 -> free
  { const Z2 = { pp: 81616.09, r1: 81644.15, r2: 81672.22, s1: 81588.03, s2: 81559.96 }, S2: Line[] = [{ name: "+0.5σ", price: 81622.65 }];
    if (!zoneGate("btc", S2, 81636.7, "up", { zones: Z2, open: 81628.81, vol: { cur: 0.88, avg: 1, frac: 1 } })) bad++; // the 1:34 PM long: R1 $7.45 above, 0.9x -> refused on BTC now
    if (zoneGate("btc", S2, 81636.7, "up", { zones: Z2, open: 81628.81, vol: { cur: 2.5, avg: 1, frac: 1 } })) bad++;  // same with a 2.5x push -> allowed
    if (!pinkRejectAgainst("btc", [{ name: "5m R1", price: 81644.15 }], 81626, "up", { h: 81643.79, l: 81626 })) bad++; } // tapped the red, $18 back down -> no long
  { const ss0 = 1000000000000, ss1 = ss0 + 86400000, c: any = {};
    sessCarryPick(c, ss0, 81564, 130);                                   // yesterday's session ends at VWAP 81,564 / sigma 130
    let r = sessCarryPick(c, ss1, 0, 0); if (!r.carried || r.v !== 81564) bad++;      // reset, no new bands yet -> carried
    r = sessCarryPick(c, ss1, 81300, 40); if (!r.carried || r.sd !== 130) bad++;       // new sigma 40 < 65 (50%) -> still carried
    r = sessCarryPick(c, ss1, 81320, 70); if (r.carried || r.sd !== 70) bad++;         // new sigma 70 >= 65 -> the new session's bands
    r = sessCarryPick({}, ss1, 0, 0); if (r.carried || r.v !== 0) bad++; }             // nothing to carry and no bands -> empty (gate refuses)
  { const Q4: Line[] = [{ name: "-1σ", price: 81000 }, { name: "+1σ", price: 81100 }];
    if (!quarterAllows(Q4, 81060, "up").ok) bad++;   // 60% up the gap -> long allowed (closest-band used to refuse this)
    if (quarterAllows(Q4, 81080, "up").ok) bad++;    // top 25% (80%) -> long refused
    if (!quarterAllows(Q4, 81040, "down").ok) bad++; // 40% -> short allowed
    if (quarterAllows(Q4, 81020, "down").ok) bad++;  // bottom 25% -> short refused
    if (!quarterAllows([{ name: "+1σ", price: 81100 }], 81090, "up").ok) bad++; // nothing below to measure -> no refusal from this rule
    if (!pinkInFront("btc", [{ name: "session VWAP", price: 200, unit: 100 }, { name: "+1σ", price: 225, unit: 100 }], 200.5, "up", 0, 0.30)) bad++; } // 30% twin: +1σ $24.50 above, room $30 -> refused
  { const Z3 = { pp: 81280, r1: 81352, r2: 81424, s1: 81208, s2: 81136 }, S3: Line[] = [{ name: "+1σ", price: 81389 }];
    if (zoneGate("btc", S3, 81380, "up", { zones: Z3, open: 81304, vol: { cur: 0, avg: 1, frac: 0.1 } })) bad++;  // the 3:40 PM rip: $76 up from the open (>= $72 range), volume 0 -> push, allowed
    if (!zoneGate("btc", S3, 81340, "up", { zones: Z3, open: 81304, vol: { cur: 0.3, avg: 1, frac: 1 } })) bad++; } // only $36 up, weak volume -> still refused
  { const PK2: Line[] = [{ name: "5m PP", price: 81326 }], mem: any = {};
    rejUpdate("btc", PK2, 81345, { h: 81345, l: 81327 }, mem, 1000);          // 4:40 PM: tapped the pink ($1 over), $19 up -> remembered
    if (!rejCarryAgainst("btc", PK2, 81345, "down", mem)) bad++;              // 4:45 PM new candle, short $19 over the pink -> still refused
    if (rejCarryAgainst("btc", PK2, 81352, "down", mem)) bad++;               // BLOCK RANGE: $26 over the pink -> too far to block (Oct 18 ~1:00 PM PT)
    if (rejCarryAgainst("btc", PK2, 81352, "up", mem)) bad++;                 // the long with it -> fine
    rejUpdate("btc", PK2, 81327.5, null, mem, 2000);                          // price comes back to the pink -> cleared
    if (rejCarryAgainst("btc", PK2, 81340, "down", mem)) bad++; }             // short allowed again
  { const PK3: Line[] = [{ name: "5m PP", price: 80956.88 }], m3: any = { "5m PP": { dir: "down", at: Date.now(), price: 80956.88 } };
    if (rejCarryAgainst("btc", PK3, 80870, "up", m3)) bad++;                   // Oct 18 12:47 PM: pink $87 overhead -> long not blocked
    if (!rejCarryAgainst("btc", PK3, 80940, "up", m3)) bad++;                  // pink $17 overhead -> still no long into it
    const G3: Line[] = [{ name: "-2σ", price: 80755.47 }, { name: "5m PP", price: 80956.88 }];
    const n3 = nearSide(G3, 80870); if (!n3 || n3.side !== "down" || inReach("btc", n3.band.price, 80870)) bad++; // closest is the pink, $87 away -> out of reach
    if (!inReach("btc", 80956.88, 80940) || !inReach("gold", 4000, 4002.2) || inReach("gold", 4000, 4002.3)) bad++; }
  { // HER RULE, today's trades (Oct 18): bands as the desk saw them
    const T: Line[] = [{ name: "session VWAP", price: 81445.69 }, { name: "-1σ", price: 81060.83 }, { name: "-2σ", price: 80675.96 }, { name: "-3σ", price: 80300 }, { name: "5m PP", price: 80895.97 }, { name: "5m R1", price: 80990 }, { name: "5m S1", price: 80800 }];
    const nowS = 1792356785, none = new Map<string, "up" | "down">();
    const pinkUp = new Map<string, "up" | "down">([["5m PP", "up"]]), oldBreak = { "5m PP": { side: "up", at: nowS - 1800 } }, newBreak = { "5m PP": { side: "up", at: nowS - 20 } };
    if (awayVerdict("btc", T, 80925.51, "up", pinkUp, { nowS, st: oldBreak })) bad++;       // 1:33 PM: 65% up the channel, -1σ $135 above = not an obstacle -> long ok (top-20% rule, Oct 18 ~8:04 PM PT)
    if (!awayVerdict("btc", T, 81040, "up", pinkUp, { nowS, st: oldBreak })) bad++;         // -1σ $21 above, closer than -2σ -> no long
    if (awayVerdict("btc", T, 80925.51, "down", pinkUp, { nowS, st: oldBreak })) bad++;     // ...the short is fine (away from -1σ)
    if (!awayVerdict("btc", T, 81045, "up", pinkUp, { nowS, st: newBreak })) bad++;         // -1σ $16 above -> no long
    if (!awayVerdict("btc", T, 80995.68, "up", new Map([["5m R1", "up"]]), { nowS, st: { "5m R1": { side: "up", at: nowS - 20 } } })) bad++; // -1σ $65 above, closer than -2σ -> no long (any distance)
    const BB: Line[] = [{ name: "5m BBSR upper", price: 81026.63 }, { name: "5m BBSR lower", price: 80781.53 }];
    if (!awayVerdict("btc", T, 81010, "up", none, { nowS, st: {} }, BB)) bad++;             // Bollinger book: top Bollinger $17 above -> no long
    if (awayVerdict("btc", T, 81010, "down", none, { nowS, st: {} }, BB)) bad++;            // ...short ok (away from it)
    if (awayVerdict("btc", T, 80790, "up", none, { nowS, st: {} }, BB)) bad++;              // near the bottom Bollinger -> long ok
    if (!awayVerdict("btc", T, 80790, "down", none, { nowS, st: {} }, BB)) bad++;           // ...no short into it
    const N: Line[] = [{ name: "-1σ", price: 81040 }, { name: "-2σ", price: 81000 }];
    // (Oct 18 ~11:48 PM PT) BTC now has the session-band range too ($25): in a $40 channel every spot is inside it -> both refused; zone % tested on a $400 channel
    if (!awayVerdict("btc", N, 81020.5, "down", none, { nowS, st: {} }) || !awayVerdict("btc", N, 81020.5, "up", none, { nowS, st: {} })) bad++;
    { const NW: Line[] = [{ name: "-1σ", price: 81400 }, { name: "-2σ", price: 81000 }];
      if (awayVerdict("btc", NW, 81200, "up", none, { nowS, st: {} }) || awayVerdict("btc", NW, 81200, "down", none, { nowS, st: {} })) bad++;   // middle: both ok
      if (awayVerdict("btc", NW, 81300, "up", none, { nowS, st: {} }) || !awayVerdict("btc", NW, 81340, "up", none, { nowS, st: {} })) bad++;   // 75% ok; 85% = top 20% (default) -> no long
      if (awayVerdict("btc", NW, 81100, "down", none, { nowS, st: {} }) || !awayVerdict("btc", NW, 81060, "down", none, { nowS, st: {} })) bad++; // 25% ok; 15% -> no short
      if (!awayVerdict("btc", NW, 81380, "up", none, { nowS, st: {} })) bad++; } // -1σ $20 above, inside $25 -> no long
    const PK: Line[] = [{ name: "-1σ", price: 81100 }, { name: "-2σ", price: 80755 }, { name: "5m PP", price: 80770 }];
    if (!awayVerdict("btc", PK, 80760, "up", none, { nowS, st: {} })) bad++;               // pink $15 over -2σ, unbroken -> wait, no long
    if (awayVerdict("btc", PK, 80780, "up", new Map([["5m PP", "up"]]), { nowS, st: {} })) bad++; // pink broken up -> long ok
    if (!awayVerdict("gold", [{ name: "-1σ", price: 4120 }, { name: "-2σ", price: 4100 }, { name: "5m PP", price: 4102 }], 4100.5, "up", none, { nowS, st: {} })) bad++;   // gold: pink $2 over -2σ -> wait
    // PINK THEORY (paper twins): pink broke DOWN 1 candle ago, price rejected up off -2σ $5 below -> free for K=2; broke 3 candles ago -> not free for K=2, free for K=3
    const PT2: Line[] = [{ name: "-1σ", price: 81100 }, { name: "-2σ", price: 80755 }, { name: "5m PP", price: 80770 }], Bdn = new Map<string, "up" | "down">([["5m PP", "down"]]);
    const f0 = Math.floor(nowS / 300) * 300;
    if (!pinkRecentFree("btc", PT2, 80760, "up", Bdn, 2, { nowS, st: { "5m PP": { side: "down", at: f0 - 200 } } })) bad++;
    if (pinkRecentFree("btc", PT2, 80760, "up", Bdn, 2, { nowS, st: { "5m PP": { side: "down", at: f0 - 500 } } })) bad++;   // broke in the 3rd candle back -> not within 2
    if (!pinkRecentFree("btc", PT2, 80760, "up", Bdn, 3, { nowS, st: { "5m PP": { side: "down", at: f0 - 500 } } })) bad++;  // ...but within 3
    if (pinkRecentFree("btc", PT2, 80760, "up", Bdn, 3, { nowS, st: { "5m PP": { side: "down", at: f0 - 700 } } })) bad++;   // 4th candle back -> not within 3
    if (awayVerdict("btc", PT2, 80760, "up", Bdn, { nowS, st: {}, pinkFree: true })) bad++;  // free: the broken pink doesn't wall her long
    if (!awayVerdict("btc", PT2, 80760, "up", Bdn, { nowS, st: {} })) bad++;                // live books: still waits
    const T2: Line[] = [{ name: "-1σ", price: 81121.22 }, { name: "-2σ", price: 80755.47 }, { name: "5m PP", price: 80956.88 }];
    if (awayVerdict("btc", T2, 80870, "up", none, { nowS, st: {} })) bad++;                 // 12:47 PM: pink $87 away, bands far -> long ok
    if (!awayVerdict("btc", T2, 80940, "up", none, { nowS, st: {} })) bad++;                // pink unbroken $17 above -> no long into it
    if (!awayVerdict("btc", T2, 80770, "down", none, { nowS, st: {} })) bad++;              // -2σ $15 below -> no short into it
    const T3: Line[] = [{ name: "-1σ", price: 81084.73 }, { name: "-2σ", price: 80707.7 }, { name: "5m PP", price: 80890.83 }];
    if (awayVerdict("btc", T3, 80834.53, "up", new Map([["-2σ", "up"]]), { nowS, st: { "-2σ": { side: "up", at: nowS - 3000 } } })) bad++;
    // 5:01 PM gold: rejected down off +2σ with a 5m R1 price had climbed through $0.22 below
    const GR: Line[] = [{ name: "+2σ", price: 4187.3 }, { name: "+1σ", price: 4183 }, { name: "5m R1", price: 4186.8 }], r1Up = new Map<string, "up" | "down">([["5m R1", "up"]]);
    if (awayVerdict("gold", GR, 4187.02, "down", r1Up, { nowS, st: {}, sessRej: true })) bad++;   // session-band rejection: the broken R1 doesn't block
    if (!awayVerdict("gold", GR, 4187.02, "down", r1Up, { nowS, st: {} })) bad++;                 // not a session-band rejection: R1 still walls it
    if (!awayVerdict("gold", GR, 4187.02, "down", none, { nowS, st: {}, sessRej: true })) bad++;  // unbroken R1 still walls it
    // 7:30 PM BTC: +1σ $56 above, VWAP $425 below -> top of the channel: no long, short ok; the bottom Bollinger $58 below doesn't move the middle
    const B730: Line[] = [{ name: "+1σ", price: 82354.44 }, { name: "session VWAP", price: 81873.19 }, { name: "5m PP", price: 82346.02 }], BBL: Line[] = [{ name: "5m BBSR upper", price: 82497.75 }, { name: "5m BBSR lower", price: 82240.55 }];
    if (!awayVerdict("btc", B730, 82298, "up", none, { nowS, st: {} }, BBL) || !awayVerdict("btc", B730, 82298, "up", none, { nowS, st: {} })) bad++;
    if (awayVerdict("btc", [{ name: "+1σ", price: 82354.44 }, { name: "session VWAP", price: 81873.19 }], 82298, "down", none, { nowS, st: {} })) bad++;
    // 7:30 PM gold: opened under the pink, spiked over it, fell back $2 under it -> latest break is DOWN: no long; back up through it -> long ok
    const G730: Line[] = [{ name: "5m PP", price: 4174.43 }, { name: "-1σ", price: 4170.86 }];
    const tr730 = [{ t: 1, c: 4171.5 }, { t: 2, c: 4174.0 }, { t: 3, c: 4174.95 }, { t: 4, c: 4173.8 }, { t: 5, c: 4172.36 }];
    if (!candleBreakAgainst("gold", G730, 4172.4, "up", 4170.65, null, tr730) || !candleBreakAgainst("gold", G730, 4172.4, "down", 4170.65, null, tr730)) bad++; // (Oct 19 ~12:38 PM PT, pink stays broken like the session bands) broke the pink UP, fell back under it: no long until it turns back up, never a short this candle
    if (candleBreakAgainst("gold", G730, 4175.0, "up", 4170.65, null, [...tr730, { t: 6, c: 4175.0 }]) || !candleBreakAgainst("gold", G730, 4175.0, "down", 4170.65, null, [...tr730, { t: 6, c: 4175.0 }])) bad++; // then 57c back over it = last break UP: long open, no short
    // 10:50 PM gold: up through +2σ, then back down 40c through it -> last break DOWN: short open, no long; a 20c hover back over it doesn't flip it
    { const P250: Line[] = [{ name: "+2σ", price: 4185.38 }], T250 = [{ t: 1, c: 4184.1 }, { t: 2, c: 4185.75 }, { t: 3, c: 4184.98 }];
      // (Oct 18 ~11:21 PM PT) a SESSION band broken up stays broken inside the candle that broke it: back under it 40c is not a break down -> still no short, long ok
      if (!candleBreakAgainst("gold", P250, 4184.98, "down", 4184.1, null, T250) || !candleBreakAgainst("gold", P250, 4184.98, "up", 4184.1, null, T250)) bad++; // no short (it broke up); no long yet (still at its low under the band)
      if (candleBreakAgainst("gold", P250, 4185.58, "up", 4184.1, null, [...T250, { t: 4, c: 4185.58 }])) bad++; }
    { const D1 = [{ t: 1, c: 100.8 }, { t: 2, c: 99.6 }, { t: 3, c: 100.2 }]; if (!candleBreakAgainst("gold", [{ name: "5m PP", price: 100 }], 100.2, "up", 101, null, D1) || !candleBreakAgainst("gold", [{ name: "5m PP", price: 100 }], 100.2, "down", 101, null, D1)) bad++; } // broke the pink down, hovering back above it: no long; short once it turns back down (pink stays broken, Oct 19)
    // BREAK ENTRY: gold broke down $0.71 through the pink, now 20c under it (closer to the pink above than -1σ below) -> short; snapped back over it -> nothing
    const BE: Line[] = [{ name: "5m PP", price: 4178.41 }, { name: "+1σ", price: 4180.05 }, { name: "session VWAP", price: 4175.7 }];
    const be1 = breakEntry("gold", BE, 4178.21, 4179.2, null, [{ t: 1, c: 4178.9 }, { t: 2, c: 4177.7 }, { t: 3, c: 4178.21 }]);
    if (!be1 || be1.side !== "down" || be1.band.name !== "5m PP") bad++;
    { const bk = breakEntry("gold", BE, 4178.82, 4179.2, null, [{ t: 1, c: 4178.9 }, { t: 2, c: 4177.7 }, { t: 3, c: 4178.82 }]); if (bk && bk.side === "up") bad++; }  // down through the pink, then 41c back over it: the pink stays broken DOWN for the candle (Oct 19 ~12:38 PM PT) -> never a long entry
    // broke the pink down, flipped up and broke the band ABOVE (+1σ) -> the last break applies: long open, short refused, long entry
    { const P2: Line[] = [{ name: "5m PP", price: 100 }, { name: "+1σ", price: 101 }], T2 = [{ t: 1, c: 99.6 }, { t: 2, c: 100.4 }, { t: 3, c: 101.4 }];
      if (candleBreakAgainst("gold", P2, 101.4, "up", 100.5, null, T2) || !candleBreakAgainst("gold", P2, 101.4, "down", 100.5, null, T2)) bad++;
      const e2 = breakEntry("gold", [...P2, { name: "+2σ", price: 104 }], 101.4, 100.5, null, T2); if (!e2 || e2.side !== "up" || e2.band.name !== "+1σ") bad++; }
    if (breakEntry("gold", BE, 4178.6, 4179.2, null, [{ t: 1, c: 4178.9 }, { t: 2, c: 4177.7 }, { t: 3, c: 4178.6 }])) bad++;  // back over the pink by only 19c: no new break, and closer to the pink below -> no short
    if (breakEntry("gold", BE, 4176.4, 4179.2, null, [{ t: 1, c: 4177.7 }, { t: 2, c: 4176.4 }])) bad++;                        // closer to the VWAP below than the pink above -> no short
    const be2 = breakEntry("gold", BE, 4180.7, 4179.5, null, [{ t: 1, c: 4180.2 }, { t: 2, c: 4180.6 }, { t: 3, c: 4180.7 }]);
    if (!be2 || be2.side !== "up" || be2.band.name !== "+1σ") bad++;
    // BTC: broke down $12 through the VWAP, still closer to it than the band below -> short; broke up $10 through +1σ -> long
    const BB2: Line[] = [{ name: "session VWAP", price: 82000 }, { name: "-1σ", price: 81600 }, { name: "+1σ", price: 82400 }];
    const b3 = breakEntry("btc", BB2, 81990, 82020, null, [{ t: 1, c: 82005 }, { t: 2, c: 81988 }, { t: 3, c: 81990 }]), b4 = breakEntry("btc", BB2, 82410, 82380, null, [{ t: 1, c: 82395 }, { t: 2, c: 82410 }]);
    if (!b3 || b3.side !== "down" || !b4 || b4.side !== "up") bad++;
    // 9:33 PM gold: broke up through the VWAP and the pink, tapped +1σ (26c over, no 33c break) and fell back 46c -> short off +1σ allowed; still under it by
    // only 10c -> no rejection yet; broke +1σ by 40c -> that's a break, no short
    { const N933: Line[] = [{ name: "session VWAP", price: 4176.03 }, { name: "5m PP", price: 4177.03 }, { name: "+1σ", price: 4180.25 }, { name: "+2σ", price: 4184.5 }];
      const t933 = [{ t: 1, c: 4175.2 }, { t: 2, c: 4176.5 }, { t: 3, c: 4177.5 }, { t: 4, c: 4179.6 }, { t: 5, c: 4180.51 }, { t: 6, c: 4179.79 }];
      const nr1 = nextBandReject("gold", N933, 4179.79, 4174.8, null, t933);
      if (!nr1 || nr1.side !== "down" || nr1.band.name !== "+1σ" || candleBreakAgainst("gold", N933, 4179.79, "down", 4174.8, null, t933)) bad++;
      if (nextBandReject("gold", N933, 4180.15, 4174.8, null, [...t933.slice(0, 5), { t: 6, c: 4180.15 }])) bad++;
      if (nextBandReject("gold", N933, 4179.79, 4174.8, null, [...t933.slice(0, 4), { t: 5, c: 4180.65 }, { t: 6, c: 4179.79 }])) bad++; }
    // NEAR TAP (add-ons): gold came within $1.20 of +1σ (no break), pushed down 40c off the high and 33c+ under the band -> short add-on; only 10c off the high -> not yet
    { const NT: Line[] = [{ name: "+1σ", price: 4180 }, { name: "session VWAP", price: 4174 }];
      if (!nearReject("gold", NT, 4178.4, "down", { h: 4178.8, l: 4177 }) || nearReject("gold", NT, 4178.7, "down", { h: 4178.8, l: 4177 }) || nearReject("gold", NT, 4178.4, "up", { h: 4178.8, l: 4177 })) bad++; }
    // 10:00 PM gold: +2σ $1.30 above (70% of the channel) -> no long (gold range covers session bands); $2.50 above -> long ok
    { const G10: Line[] = [{ name: "+1σ", price: 4180.65 }, { name: "+2σ", price: 4184.95 }];
      if (!awayVerdict("gold", G10, 4183.65, "up", none, { nowS, st: {} }) || awayVerdict("gold", G10, 4182.45, "up", none, { nowS, st: {} })) bad++; }
    // 11:00 PM gold: candle open 4184.56, falling to 4183.12 at its low -> no long; bounced 40c off a 4182.70 low -> long ok; mirror for shorts
    { const P11: Line[] = [{ name: "5m PP", price: 4182.64 }];
      if (!candleBreakAgainst("gold", P11, 4183.12, "up", 4184.56, null, [{ t: 1, c: 4184.3 }, { t: 2, c: 4183.6 }, { t: 3, c: 4183.12 }])) bad++;
      if (candleBreakAgainst("gold", P11, 4183.1, "up", 4184.56, null, [{ t: 1, c: 4184.3 }, { t: 2, c: 4182.7 }, { t: 3, c: 4183.1 }])) bad++;
      if (!candleBreakAgainst("gold", [{ name: "5m PP", price: 4190 }], 4185.9, "down", 4184.5, null, [{ t: 1, c: 4185.0 }, { t: 2, c: 4185.9 }])) bad++;
      if (candleBreakAgainst("gold", P11, 4184.4, "up", 4184.56, null, [{ t: 1, c: 4184.4 }])) bad++; } // 16c under the open = not falling yet
    // falling from the top third: channel 4181.27-4185.66, open 4184.56 (75%), falling to 4183.12 -> no long; bounced 40c off 4182.80 -> long ok; rising off the bottom third -> no short
    { const C11: Line[] = [{ name: "+1σ", price: 4181.27 }, { name: "+2σ", price: 4185.66 }];
      if (!awayVerdict("gold", C11, 4183.12, "up", none, { nowS, st: {}, open: 4184.56, trail: [{ t: 1, c: 4184.2 }, { t: 2, c: 4183.12 }] })) bad++;
      if (awayVerdict("gold", C11, 4183.2, "up", none, { nowS, st: {}, open: 4184.56, trail: [{ t: 1, c: 4182.8 }, { t: 2, c: 4183.2 }] })) bad++;
      if (!awayVerdict("gold", C11, 4183.0, "down", none, { nowS, st: {}, open: 4181.6, trail: [{ t: 1, c: 4181.5 }, { t: 2, c: 4183.0 }] })) bad++;
      if (awayVerdict("gold", C11, 4183.12, "up", none, { nowS, st: {}, open: 4183.4, trail: [{ t: 1, c: 4183.12 }] })) bad++; } // high only 49% up the channel -> not from the top third
    // session band broken this candle stays broken: opened 4180.90 under +1σ, broke it to 4181.80, dipped back to 4180.80, rising at 4181.10 -> long ok
    // (no break DOWN counted, +1σ not a wall); the pink keeps flipping on a re-cross
    { const SB: Line[] = [{ name: "session VWAP", price: 4176.9 }, { name: "+1σ", price: 4181.27 }, { name: "+2σ", price: 4185.66 }];
      const tSB = [{ t: 1, c: 4181.0 }, { t: 2, c: 4181.8 }, { t: 3, c: 4180.8 }, { t: 4, c: 4181.15 }];
      if (candleBreakAgainst("gold", SB, 4181.15, "up", 4180.9, null, tSB) || awayVerdict("gold", SB, 4181.15, "up", none, { nowS, st: {}, open: 4180.9, trail: tSB })) bad++; // turned up 35c off its low
      if (!awayVerdict("gold", SB, 4185.2, "up", none, { nowS, st: {}, open: 4184.9, trail: [{ t: 1, c: 4185.0 }, { t: 2, c: 4185.2 }] })) bad++; // never broke +2σ: top of the channel, no long
      if (!candleBreakAgainst("gold", SB, 4180.85, "up", 4180.9, null, [{ t: 1, c: 4181.0 }, { t: 2, c: 4181.8 }, { t: 3, c: 4180.8 }, { t: 4, c: 4180.85 }])) bad++; // back under +1σ, still at its low: wait
      const PK: Line[] = [{ name: "5m PP", price: 100 }], tPK = [{ t: 1, c: 100.5 }, { t: 2, c: 99.5 }];
      if (!candleBreakAgainst("gold", PK, 99.5, "up", 99.8, null, tPK)) bad++; } // the pink: up then back down 50c -> last break down, no long
    if (!isZoneLine({ name: "5m R1", price: 1 }) || !isZoneLine({ name: "15m S2", price: 1 }) || isZoneLine({ name: "5m PP", price: 1 }) || isZoneLine({ name: "+1σ", price: 1 })) bad++;
    if (!candleBreakAgainst("btc", BB2, 81990, "up", 82020, null, [{ t: 1, c: 82005 }, { t: 2, c: 81988 }]) || candleBreakAgainst("btc", BB2, 81990, "down", 82020, null, [{ t: 1, c: 82005 }, { t: 2, c: 81988 }])) bad++; // broke down: short open, long refused
    if (!isSessRej({ band: { name: "+2σ" }, kind: "red-reject", from: "rejection" }) || isSessRej({ band: { name: "5m R1" }, from: "rejection" }) || isSessRej({ band: { name: "+2σ" }, label: "Broke up through +2σ" })) bad++; } // 1:15 PM: broke up thru -2σ, now $127 below = closest -> long ok
  G.__bandLawBroken = bad > 0;
  try { writeFileSync(D("band-lock-selftest.json"), JSON.stringify({ at: new Date().toISOString(), scenarios: n, calls, intoUnbrokenBand: bad, ok: bad === 0, zoneGate: "into-vs-away v2 (12 cases), gold only; BTC walls = session + pink; 1.28x road; break-in-charge this candle $25, no tap exception (6 cases); break depth $8 btc / $1 gold (4 cases); broken wall until a close back (5m pivots / 1m session), only in front of the break (7 cases); no band between price and the target (7 cases); target = Kalshi strike + live Vantage-INDEX gap + $30 (3 cases); at the session band within $8 btc / $1 gold = wait (7 cases); session band ahead of the pink closer than behind = wait (4 cases); no trade against a pink/session-band rejection this candle (8 cases); a pink break needs $6 btc / $0.75 gold (6 cases); red/green zone rule on BTC too + red/green rejections (3 cases); carry-over session bands to 50% sigma + never blind (4 cases); 25% rule replaces closest band, room only on the 15%/30% twins (6 cases); a big fast candle is a push (off with the zones); session-ahead wait retired; closest band back; rejection holds until price returns (3 cases); red/green zones back on, off only for the session-only book; no rejection hold on the session-only book; no $6 pink wait on BTC; add-on = $3 tap rejection" }, null, 1)); } catch {}
  return bad;
}

/** PAPER DNA (Oct 16 ~1:12 PM PT, Love: "0 OF OUR BOOKS ARE TO NOT HAVE THAT INCLUDED IN THEIR DNA. NEVER AGAIN. STAPLE THAT
 * SHUT AND BURY IT."): every paper book's NEW trade (open, booked in the last 2 min, not yet checked on this side) on gold
 * (incl. micro gold) or BTC must be on the closest band's side right now, or it is not recorded - the book books again on a
 * later pass if it still wants to. Can't verify (no fresh price / band list) = not recorded. Drops -> data/band-lock.jsonl. */
export function paperBandFilter<T>(rows: T[], tag: string): T[] {
  const seen: Map<string, string> = (G.__bandSeen ||= new Map());
  const now = Date.now();
  const out: T[] = [];
  for (const r0 of rows as any[]) {
    const r = r0 as any;
    if (!r || typeof r !== "object") { out.push(r0); continue; }
    const id = String(r.id ?? ""), side = String(r.side ?? ""), at = Date.parse(String(r.at ?? ""));
    const open = r.result === undefined || r.result === null || r.result === "open";
    if (!id || !(side === "up" || side === "down") || !open || !(now - at < 120000) || seen.get(id) === side) { out.push(r0); continue; }
    if (RECON.has(String(r.lane ?? r.book ?? ""))) { // RECONSTRUCTED: the Oct 12 rules (recon.ts) + her 33% channel rule (Oct 19 ~6:33 PM PT), nothing else
      const a1 = String(r.asset ?? "").toLowerCase(); const lbR = G.__lawBands?.[a1]; const qR = quoteTick(a1);
      let whyR = "";
      if (!lbR || !Array.isArray(lbR.L) || !lbR.L.length || now - Number(lbR.at) > 15000) whyR = "can't verify the channel (band list not fresh)";
      else if (!qR || !(qR.c > 0) || now - qR.at > 3000) whyR = "can't verify (no fresh price)";
      else whyR = channelOnly(a1, lbR.L, qR.c, side, refreshBroken(a1, lbR.L, qR.c)) || candleDirOnly(a1, lbR.L, qR.c, side) || reconZoneGate(a1, qR.c, side) || reconThirdAgainst(a1, lbR.L, qR.c, side, refreshBroken(a1, lbR.L, qR.c)); // zones Oct 20 ~12:22 AM; third wall Oct 20 ~1:32 AM ("tighten that up")
      if (!whyR) { seen.set(id, side); out.push(r0); continue; }
      seen.set(id, side);
      try { appendFileSync(D("band-lock.jsonl"), JSON.stringify({ at: new Date().toISOString(), paper: "recon", id, book: String(r.lane ?? r.book ?? ""), asset: a1, side, reason: whyR, tick: qR?.c ?? null }) + "\n"); } catch {}
      continue;
    }
    const a0 = String(r.asset ?? "").toLowerCase();
    const asset = a0 === "mgold" ? "gold" : a0;
    // INVERSE TEST (Oct 16 ~4:19 PM PT): while live-switch.invTest4pm is set the inverse's paper row is kept too (it is the
    // twin's call mirrored, so the band rules always drop it) - otherwise the copier has nothing to send for her test.
    if (String(r.lane ?? r.book ?? "") === "ogp5-inv") { try { if (JSON.parse(readFileSync(D("live-switch.json"), "utf8"))?.invTest4pm) { seen.set(id, side); out.push(r0); continue; } } catch {} }
    if (!(asset === "gold" || asset === "btc")) { out.push(r0); continue; }
    const lb = G.__lawBands?.[asset];
    const q = quoteTick(asset);
    let why = "";
    if (G.__bandLawBroken) why = "band law failed its self-test";
    else if (!lb || !Array.isArray(lb.L) || !lb.L.length || now - Number(lb.at) > 15000) why = "can't verify (band list not fresh)";
    else if (!q || !(q.c > 0) || now - q.at > 3000) why = "can't verify (no fresh price)";
    else if (!lb.L.some((l: Line) => /σ$|^session VWAP$/.test(String(l.name)))) why = "can't verify (no session bands on her list)";
    else if (r.band && Number(r.band.price) > 0) { const zc = Number(r.goldLaw?.ceil), zf = Number(r.goldLaw?.floor); const bp = side === "down" && zc > 0 ? zc : side === "up" && zf > 0 ? zf : Number(r.band.price); if (!sideOfBandOk(bp, q.c, side)) why = `${side === "up" ? "long" : "short"} on the wrong side of ${r.band.name} (its setup band)`; }
    // ALL HER BREAKS GO THROUGH (Oct 19 ~3:19 PM PT, Love: "all the breaks are good bb all of them let em thru" + "the green zone was far away"):
    // the session + pink book's paper calls skip every band rule here - only a can't-verify (stale bands / no fresh price / self-test) holds one.
    // ONE RULEBOOK (Oct 19 ~5:25 PM PT, Love: "yes pls"): the break must be in this 5m candle, THEN every band rule below, same as SESSION ONLY.
    if (PASS_THRU.has(String(r.lane ?? r.book ?? "")) && !why) { const cdA = lb && Array.isArray(lb.L) && q && q.c > 0 ? candleDirAgainst(asset, wallLines(asset, lb.L), q.c, side) : ""; if (cdA) why = cdA; }
    // PINK THEORY twins (paper only): a pink broken within K candles is not a wall for a trade off the session band behind her
    const pkK = PINK_RECENT[String(r.lane ?? r.book ?? "")] || 0;
    const pkFree = !!(pkK && lb && Array.isArray(lb.L) && q && q.c > 0 && pinkRecentFree(asset, lb.L, q.c, side, refreshBroken(asset, lb.L, q.c), pkK));
    const WL = (L0: Line[]) => (pkFree ? noPink(L0) : L0);
    // CLOSEST BAND DECIDES on paper too (Oct 16 ~10:30 PM PT, Love) - the setup band no longer skips it.
    if (!why && lb && Array.isArray(lb.L) && lb.L.length && q && q.c > 0) { const BkP = refreshBroken(asset, lb.L, q.c); const ns = nearSide(wallFor(wallLines(asset, lb.L), BkP, q.c, side), q.c); if (!ns) why = "can't verify"; else why = awayVerdict(asset, lb.L, q.c, side, BkP, { pinkFree: pkFree, sessRej: isSessRej(r) }, BB_BOOKS.has(String(r.lane ?? r.book ?? "")) ? bbLines(asset) : []); } if (WALL_FREE.has(String(r.lane ?? r.book ?? "")) && /^would (long|short) INTO /.test(why)) why = "";
    if (!why && lb && Array.isArray(lb.L) && q && q.c > 0) why = candleBreakAgainst(asset, wallLines(asset, lb.L), q.c, side) || sessionBreakPinkHold(asset, lb.L, q.c, side) || (ROOM_TWIN[String(r.lane ?? r.book ?? "")] ? pinkInFront(asset, wallFor(wallLines(asset, lb.L), refreshBroken(asset, lb.L, q.c), q.c, side), q.c, side, fiveOpenNow(asset), ROOM_TWIN[String(r.lane ?? r.book ?? "")]) : "") || (ZONES_OFF.has(String(r.lane ?? r.book ?? "")) ? "" : zoneGate(asset, lb.L, q.c, side));
    if (!why && lb && Array.isArray(lb.L) && lb.L.length && q && q.c > 0) why = WALL_FREE.has(String(r.lane ?? r.book ?? "")) ? "" : crossToTarget(asset, wallFor(WL(wallLines(asset, lb.L)), refreshBroken(asset, lb.L, q.c), q.c, side), q.c, side, targetNow(asset)); // no band between price and the target (Oct 17 ~2:02 AM PT)
    if (!why && lb && Array.isArray(lb.L) && lb.L.length && q && q.c > 0) why = NO_AT_WAIT.has(String(r.lane ?? r.book ?? "")) ? "" : atSessionBand(asset, wallFor(wallLines(asset, lb.L), refreshBroken(asset, lb.L, q.c), q.c, side), q.c); // at the session band = wait (Oct 17 ~10:41 AM PT)
    if (!why && lb && Array.isArray(lb.L) && lb.L.length && q && q.c > 0) why = pinkRejectAgainst(asset, ZONES_OFF.has(String(r.lane ?? r.book ?? "")) ? noZ(lb.L) : lb.L, q.c, side); // no trade against a pink rejection this candle (Oct 17 ~1:03 PM PT)
    if (!why && lb && Array.isArray(lb.L) && lb.L.length && q && q.c > 0) why = ZONES_OFF.has(String(r.lane ?? r.book ?? "")) || NO_REJ_HOLD.has(String(r.lane ?? r.book ?? "")) ? "" : rejCarryAgainst(asset, lb.L, q.c, side); // a rejection holds until price comes back (Oct 17 ~4:54 PM PT)
    if (!why && lb && Array.isArray(lb.L) && lb.L.length && q && q.c > 0) why = pkFree || NO_AT_WAIT.has(String(r.lane ?? r.book ?? "")) ? "" : atPink(asset, wallFor(wallLines(asset, lb.L), refreshBroken(asset, lb.L, q.c), q.c, side), q.c); // a pink break needs $6 (Oct 17 ~1:30 PM PT)
    if (why) { const LA: Map<string, number> = (G.__bandLogAt ||= new Map()); const k = `${id}:${side}`; if (!LA.has(k) || now - (LA.get(k) as number) > 30000) { LA.set(k, now); if (LA.size > 5000) LA.clear(); } else continue; try { appendFileSync(D("band-lock.jsonl"), JSON.stringify({ at: new Date().toISOString(), paper: tag, id, book: r.lane ?? r.book ?? "", asset: a0, side, reason: why, tick: q?.c ?? null }) + "\n"); } catch {} continue; }
    seen.set(id, side);
    out.push(r0);
  }
  if (seen.size > 20000) { let i = 0; for (const k of seen.keys()) { if (i++ > 5000) break; seen.delete(k); } }
  return out;
}

/** The live book that holds this window (from live-book-done.json), for top-ups. */
export function ownerBook(ticker: string): string {
  try {
    const c = (G.__ownerDone ||= { at: 0, d: {} as Record<string, any> });
    if (Date.now() - c.at > 2000) { c.d = JSON.parse(readFileSync(D("live-book-done.json"), "utf8")); c.at = Date.now(); }
    for (const [k, v] of Object.entries(c.d)) if (k.startsWith(ticker + ":") && (v as any)?.status === "filled") return k.split(":").pop() || "";
  } catch {}
  return "";
}

/** The live 5m candle's open from the desk's own 1m bars (pivotbooks __pivBars). */
function fiveOpenNow(asset: string): number {
  try {
    const bars: any[] = G.__pivBars?.[asset]?.bars ?? [];
    const f0 = Math.floor(Date.now() / 300000) * 300;
    const inF = bars.filter((x) => Number(x.t) >= f0).sort((x, y) => x.t - y.t);
    if (inF.length) return Number(inF[0].o);
    // FIRST SECONDS OF THE CANDLE (Oct 19 ~12:57 AM PT, Love: "obviously fix both things"): until the chart has the new 5m candle, its open is her last
    // live tick before the candle started (within 10 s), else the first tick in it - the break rules are no longer blind for the first ~15 s.
    return trailOpen(asset);
  } catch { return 0; }
}
function trailNow(asset: string): { t: number; c: number }[] {
  if (G.__stDefaultReach) return [];
  const tk = Object.keys(G).filter((k) => /^__qtrail_\d+$/.test(k)).sort((a, b) => Number(b.slice(9)) - Number(a.slice(9)))[0];
  return ((tk && G[tk]?.[asset]) || []).filter((x: any) => x && x.c > 0);
}
function trailOpen(asset: string): number {
  const f0 = Math.floor(Date.now() / 300000) * 300000;
  const tr = trailNow(asset);
  const pre = tr.filter((x) => x.t < f0 && x.t >= f0 - 10000);
  if (pre.length) return Number(pre[pre.length - 1].c);
  const inn = tr.filter((x) => x.t >= f0);
  return inn.length ? Number(inn[0].c) : 0;
}
function fiveHLNow(asset: string): { h: number; l: number } | null {
  try {
    const bars: any[] = G.__pivBars?.[asset]?.bars ?? [];
    const f0 = Math.floor(Date.now() / 300000) * 300;
    const inF = bars.filter((x) => Number(x.t) >= f0);
    if (!inF.length) { const o = trailOpen(asset), tr = trailNow(asset).filter((x) => x.t >= f0 * 1000).map((x) => x.c); const all = [...(o > 0 ? [o] : []), ...tr]; return all.length ? { h: Math.max(...all), l: Math.min(...all) } : null; }
    return { h: Math.max(...inF.map((x) => Number(x.h))), l: Math.min(...inF.map((x) => Number(x.l))) };
  } catch { return null; }
}
/** A reason string if `side` trades against a band break made in the live 5m candle, else "". */
export const BREAK_DIST: Record<string, number> = { btc: 6, gold: 0.33 }; // BTC $8 -> $6 Oct 19 ~12:26 AM PT (Love: "let's lower btc's break to $6 from its original $8 tpls") // // gold 50c -> 33c Oct 18 ~9:04 PM PT (Love: "could you make the push thru a band 33 cents instead of 50 for now bb") // // Love, Oct 17 ~1:15 AM PT; gold $1 -> 50c Oct 18 ~3:51 PM PT ("$1 is waaay too wide rn bb... let's bring that down to 50 cents pls")
// LATEST BREAK DECIDES (Oct 18 ~7:45 PM PT, Love: "yes. the direction of the break... break = direction of the break / rejection = trade the direction
// of the rejection" - 7:30 PM gold: the candle opened under the pink, spiked $0.40 over it, then fell back $2 under it; the open-based check still read a
// rising candle and let a long through). Her live ticks in this 5m candle, in order: every time price goes BREAK_DIST through a band from the side it
// was on, that's a break; the LAST one decides - no long after a break down, no short after a break up.
// ANY BREAK IN THE CANDLE HOLDS FOR THE CANDLE (Oct 18 ~9:09 PM PT, Love: "i don't want her to long if it breaks a band down and then hovers above the pink.
// if it breaks the band down - she cannot long. band break = trade the direction of the break" + earlier "it ONLY applies to CURRENT CANDLE"): every break
// this 5m candle made, from her live ticks plus the candle's own high/low against its open. A break down anywhere in the candle = no long until the next
// candle; a break up = no short. A candle that broke both ways = neither.
// LAST BAND BROKEN APPLIES (Oct 18 ~9:12 PM PT, Love: "in the event price breaks a pink band, and then flips up, and breaks the band ABOVE, she can trade the
// break of THAT. band breaks = trade that direction. if she breaks two bands in one candle, the last break applies"): a break holds for the candle until a
// DIFFERENT band breaks the other way after it. Price coming back through the SAME band doesn't undo its break (9:09 PM: "if it breaks a band down and then
// hovers above the pink... she cannot long"). Active break down = no long; active break up = no short; both active = neither.
export function candleBreaks(asset: string, L: Line[], o: number, tick: number, trail?: { t: number; c: number }[], hl?: { h: number; l: number } | null): { down: { band: Line; t: number } | null; up: { band: Line; t: number } | null; last: { dir: "up" | "down"; band: Line; t: number } | null } {
  const out: { down: { band: Line; t: number } | null; up: { band: Line; t: number } | null; last: { dir: "up" | "down"; band: Line; t: number } | null } = { down: null, up: null, last: null };
  const dist = BREAK_DIST[asset] ?? 0;
  if (!(dist > 0) || !(o > 0)) return out;
  let tr = trail;
  if (!tr) {
    const tk = Object.keys(G).filter((k) => /^__qtrail_\d+$/.test(k)).sort((a, b) => Number(b.slice(9)) - Number(a.slice(9)))[0];
    const f0 = Math.floor(Date.now() / 300000) * 300000;
    tr = ((tk && G[tk]?.[asset]) || []).filter((x: any) => x && x.c > 0 && x.t >= f0);
    if (tick > 0) tr = [...(tr as any[]), { t: Date.now(), c: tick }];
  }
  const ev: { dir: "up" | "down"; band: Line; t: number }[] = [];
  for (const b of L) {
    const bp = Number(b.price); if (!(bp > 0)) continue;
    let st: "above" | "below" | null = o > bp ? "above" : o < bp ? "below" : null;
    let sawDn = false, sawUp = false;
    // SESSION BAND STAYS BROKEN FOR THE CANDLE (Love, Oct 18 ~11:21 PM PT: "for the session bands - current candle that broke the band can long if it reverses and flips and starts rising in the top ...): once this candle broke a session band, price coming back through it inside the same
    // candle doesn't break it the other way - it is only unbroken when a candle CLOSES back on the other side (the next candle starts fresh).
    // + THE PINK STAYS BROKEN TOO (Oct 19 ~12:38 PM PT, Love: "yes, that's the same fix we implemented on our other book" - 12:30:22 PM BTC long after the
    // pink broke down at 12:30:16 and a 2 s spike went back over it): once this candle broke the pink, price coming back through it in the same candle
    // doesn't break it the other way - like the session bands, it's unbroken only when a candle closes back on the other side.
    const sessB = isSessBand(b) || b.name === "5m PP";
    for (const x of tr || []) {
      if (st !== "below" && x.c <= bp - dist) { if (st === "above" && !(sessB && sawUp)) { ev.push({ dir: "down", band: b, t: x.t }); sawDn = true; } st = "below"; }
      else if (st !== "above" && x.c >= bp + dist) { if (st === "below" && !(sessB && sawDn)) { ev.push({ dir: "up", band: b, t: x.t }); sawUp = true; } st = "above"; }
    }
    if (hl) { // the candle's own wick, for a poke her ticks missed (earliest - any later tick break outranks it)
      const lo = Math.min(hl.l, tick || hl.l), hi = Math.max(hl.h, tick || hl.h);
      if (!sawDn && o > bp && lo <= bp - dist) ev.push({ dir: "down", band: b, t: 0 });
      if (!sawUp && o < bp && hi >= bp + dist) ev.push({ dir: "up", band: b, t: 0 });
    }
  }
  ev.sort((a, b) => a.t - b.t);
  // THE LAST WAY IT BREAKS (Oct 18 ~10:56 PM PT, Love: "i don't want her to trade neither if it breaks two ways. the last way that it breaks. that's it"):
  // the latest break in the candle - any band, the same band again included - is the only one that counts. A hover back under her break distance
  // isn't a break, so it never flips it.
  out.last = ev.length ? ev[ev.length - 1] : null;
  if (out.last) { if (out.last.dir === "down") out.down = { band: out.last.band, t: out.last.t }; else out.up = { band: out.last.band, t: out.last.t }; }
  return out;
}
// BREAK ONE, TAP THE NEXT = TRADE THE REJECTION (Love, Oct 18 ~9:34 PM PT: "she didn't short at the band though, after it broke one and tapped the next / can you make sure she still does those?" - 9:33 PM gold broke up through the VWAP and the pink, tapped +1σ (high 26c over, no 33c break) and fell back): after the candle's last break (session band or the pink), price reaches the NEXT band beyond it
// (within her tap distance, BTC $3 / gold 30c), doesn't break it, and comes back off it by the tap distance = a rejection off that band - short off a band
// above after a break up, long off a band below after a break down. That rejection is the newest thing price did, so the break rule lets it through.
export function nextBandReject(asset: string, L: Line[], tick: number, o0 = 0, hl0?: { h: number; l: number } | null, trail?: { t: number; c: number }[]): { side: "up" | "down"; band: Line; broke: Line } | null {
  const tap = PINK_TAP[asset] ?? 0, dist = BREAK_DIST[asset] ?? 0;
  const o = o0 > 0 ? o0 : fiveOpenNow(asset);
  if (!(o > 0) || !(tick > 0) || !(tap > 0) || !(dist > 0)) return null;
  const B = L.filter((l) => Number(l.price) > 0 && (isSessBand(l) || l.name === "5m PP"));
  let tr = trail;
  if (!tr) {
    const tk = Object.keys(G).filter((k) => /^__qtrail_\d+$/.test(k)).sort((a, b) => Number(b.slice(9)) - Number(a.slice(9)))[0];
    const f0 = Math.floor(Date.now() / 300000) * 300000;
    tr = ((tk && G[tk]?.[asset]) || []).filter((x: any) => x && x.c > 0 && x.t >= f0);
    tr = [...(tr as any[]), { t: Date.now(), c: tick }];
  }
  const hl = hl0 !== undefined ? hl0 : (trail ? null : fiveHLNow(asset));
  const cb = candleBreaks(asset, B, o, tick, tr, hl);
  const e = cb.last; if (!e) return null;
  const after = (tr || []).filter((x) => x.t >= e.t).map((x) => x.c);
  if (e.dir === "up") {
    const nb = B.filter((l) => l.price > Number(e.band.price) && l.name !== e.band.name).sort((a, b) => a.price - b.price)[0]; if (!nb) return null;
    const hi = Math.max(...after, e.t === 0 && hl ? hl.h : -Infinity);
    if (hi >= nb.price - tap && hi < nb.price + dist && tick <= nb.price - tap) return { side: "down", band: nb, broke: e.band };
  } else {
    const nb = B.filter((l) => l.price < Number(e.band.price) && l.name !== e.band.name).sort((a, b) => b.price - a.price)[0]; if (!nb) return null;
    const lo = Math.min(...after, e.t === 0 && hl ? hl.l : Infinity);
    if (lo <= nb.price + tap && lo > nb.price - dist && tick >= nb.price + tap) return { side: "up", band: nb, broke: e.band };
  }
  return null;
}
// BROKE DOWN, TAPPED THE PINK, REJECTED = SHORT (Oct 19 ~12:56 AM PT, Love: "gold came up and tapped the pink band and she didn't short... if the band in the
// current candle broke the one below she can short. next time gold does that and taps the pink and rejects, have her enter" / "current candle + broken
// band = no barrier / short"): this 5m candle's last break was DOWN through the pink or a band under it, since then price came up to the pink (within her
// tap distance), didn't break it, and is back the tap distance under it = the short. The band it broke is behind her - no barrier.
// + THE MIRROR AND BTC (Oct 19 ~1:05 AM PT, Love: "yes."): last break UP through the pink or a band over it, price dipped to the pink, didn't break it,
// and is back the tap distance over it = the long. Gold 30c tap / 33c break, BTC $3 tap / $6 break.
export function pinkRetest(asset: string, L: Line[], tick: number, o0 = 0, hl0?: { h: number; l: number } | null, trail?: { t: number; c: number }[]): { side: "up" | "down"; band: Line; broke: Line } | null {
  if (asset !== "gold" && asset !== "btc") return null;
  const tap = PINK_TAP[asset] ?? 0, dist = BREAK_DIST[asset] ?? 0;
  const o = o0 > 0 ? o0 : fiveOpenNow(asset);
  if (!(o > 0) || !(tick > 0) || !(tap > 0) || !(dist > 0)) return null;
  const B = L.filter((l) => Number(l.price) > 0 && (isSessBand(l) || l.name === "5m PP"));
  const pk = B.find((l) => l.name === "5m PP"); if (!pk) return null;
  let tr = trail;
  if (!tr) { const f0 = Math.floor(Date.now() / 300000) * 300000; tr = [...trailNow(asset).filter((x) => x.t >= f0), { t: Date.now(), c: tick }]; }
  const hl = hl0 !== undefined ? hl0 : (trail ? null : fiveHLNow(asset));
  const cb = candleBreaks(asset, B, o, tick, tr, hl);
  const e = cb.last; if (!e || !(e.t > 0)) return null;
  const after = (tr || []).filter((x) => x.t >= e.t).map((x) => x.c);
  if (!after.length) return null;
  if (e.dir === "down" && Number(e.band.price) <= Number(pk.price)) {
    const hi = Math.max(...after);
    if (hi >= pk.price - tap && hi < pk.price + dist && tick <= pk.price - tap) return { side: "down", band: pk, broke: e.band };
  }
  if (e.dir === "up" && Number(e.band.price) >= Number(pk.price)) {
    const lo = Math.min(...after);
    if (lo <= pk.price + tap && lo > pk.price - dist && tick >= pk.price + tap) return { side: "up", band: pk, broke: e.band };
  }
  return null;
}
// PINK REJECTION ENTRY (Oct 19 ~1:31 PM PT, Love: "let's make another twin that trades rejections that way. we will see how it compares" - the break
// book trades breaks only): this 5m candle opened under the pink, price came up to it (within her tap distance, BTC $3 / gold 30c), didn't break it
// (BTC $6 / gold 33c through) and is back the tap distance under it = short; mirror from above = long. Paper twin only (brk-sessrj).
export function pinkRejectEntry(asset: string, L: Line[], tick: number, o0 = 0, trail?: { t: number; c: number }[]): { side: "up" | "down"; label: string } | null {
  const tap = PINK_TAP[asset] ?? 0, dist = BREAK_DIST[asset] ?? 0;
  const pk = L.find((l) => l.name === "5m PP" && Number(l.price) > 0);
  if (!pk || !(tap > 0) || !(dist > 0) || !(tick > 0)) return null;
  const o = o0 > 0 ? o0 : fiveOpenNow(asset);
  if (!(o > 0)) return null;
  let tr = trail;
  if (!tr) { const f0 = Math.floor(Date.now() / 300000) * 300000; tr = [...trailNow(asset).filter((x) => x.t >= f0), { t: Date.now(), c: tick }]; }
  const xs = [o, ...tr.map((x) => x.c)];
  const hi = Math.max(...xs), lo = Math.min(...xs), P = Number(pk.price);
  if (o < P && hi >= P - tap && hi < P + dist && tick <= P - tap) return { side: "down", label: "Rejected down off 5m PP" };
  if (o > P && lo <= P + tap && lo > P - dist && tick >= P + tap) return { side: "up", label: "Bounced up off 5m PP" };
  return null;
}
export function pinkRetestShort(asset: string, L: Line[], tick: number, o0 = 0, hl0?: { h: number; l: number } | null, trail?: { t: number; c: number }[]) {
  const r = pinkRetest(asset, L, tick, o0, hl0, trail); return r && r.side === "down" ? r : null;
}
export function latestBreak(asset: string, L: Line[], o: number, tick: number, trail?: { t: number; c: number }[]): { dir: "up" | "down"; band: Line; t: number } | null {
  const dist = BREAK_DIST[asset] ?? 0;
  if (!(dist > 0) || !(o > 0)) return null;
  let tr = trail;
  if (!tr) {
    const tk = Object.keys(G).filter((k) => /^__qtrail_\d+$/.test(k)).sort((a, b) => Number(b.slice(9)) - Number(a.slice(9)))[0];
    const f0 = Math.floor(Date.now() / 300000) * 300000;
    tr = ((tk && G[tk]?.[asset]) || []).filter((x: any) => x && x.c > 0 && x.t >= f0);
    if (tick > 0) tr = [...(tr as any[]), { t: Date.now(), c: tick }];
  }
  if (!tr || !tr.length) return null;
  let last: { dir: "up" | "down"; band: Line; t: number } | null = null;
  for (const b of L) {
    const bp = Number(b.price); if (!(bp > 0)) continue;
    let st: "above" | "below" | null = o > bp ? "above" : o < bp ? "below" : null;
    for (const x of tr) {
      if (st !== "below" && x.c <= bp - dist) { if (st === "above") { if (!last || x.t >= last.t) last = { dir: "down", band: b, t: x.t }; } st = "below"; }
      else if (st !== "above" && x.c >= bp + dist) { if (st === "below") { if (!last || x.t >= last.t) last = { dir: "up", band: b, t: x.t }; } st = "above"; }
    }
  }
  return last;
}
// BREAK ENTRY (Oct 18 ~8:39 PM PT, Love: "if price breaks thru the band by over 50 cents on gold have her get in as long as she is closer to the band
// above her than below her and is not in the (top/bottom 20%)" + "it ONLY applies to CURRENT CANDLE"): in the live 5m candle, a break of one of her bands
// (session bands + the pink) by BREAK_DIST is an entry in the break's direction - short after a break down while price is closer to the band above than
// the band below, long after a break up while closer to the band below. The 20% channel rule and every other gate still judge it after this.
export function breakEntry(asset: string, L: Line[], tick: number, o0 = 0, hl0?: { h: number; l: number } | null, trail?: { t: number; c: number }[]): { side: "up" | "down"; band: Line; by: number } | null {
  const dist = BREAK_DIST[asset] ?? 0;
  const o = o0 > 0 ? o0 : fiveOpenNow(asset);
  if (!(dist > 0) || !(o > 0) || !(tick > 0)) return null;
  const B = L.filter((l) => Number(l.price) > 0 && (isSessBand(l) || l.name === "5m PP"));
  if (!B.length) return null;
  let br: { side: "up" | "down"; band: Line; by: number } | null = null;
  const cbE = candleBreaks(asset, B, o, tick, trail, hl0 !== undefined ? hl0 : (trail ? null : fiveHLNow(asset)));
  // the last band broken decides the entry - only if no active break the other way still blocks that side
  const lk = cbE.last && !(cbE.last.dir === "down" ? cbE.up : cbE.down) ? { dir: cbE.last.dir, band: cbE.last.band } : null;
  if (cbE.last && !lk) return null;
  if (lk) br = { side: lk.dir, band: lk.band, by: Math.abs(tick - Number(lk.band.price)) };
  else {
    const hl = hl0 !== undefined ? hl0 : fiveHLNow(asset);
    if (!hl) return null;
    const lo = Math.min(hl.l, tick), hi = Math.max(hl.h, tick);
    const dn = B.filter((l) => o > l.price && lo <= l.price - dist), up = B.filter((l) => o < l.price && hi >= l.price + dist);
    if (dn.length && !up.length) { const b = dn.sort((x, y) => y.price - x.price)[dn.length - 1]; br = { side: "down", band: b, by: b.price - lo }; }
    else if (up.length && !dn.length) { const b = up.sort((x, y) => x.price - y.price)[up.length - 1]; br = { side: "up", band: b, by: hi - b.price }; }
  }
  if (!br) return null;
  const above = B.filter((l) => l.price > tick).sort((a, b) => a.price - b.price)[0], below = B.filter((l) => l.price < tick).sort((a, b) => b.price - a.price)[0];
  const dA = above ? above.price - tick : Infinity, dB = below ? tick - below.price : Infinity;
  if (br.side === "down" && !(dA < dB)) return null;
  if (br.side === "up" && !(dB < dA)) return null;
  return br;
}
export function candleBreakAgainst(asset: string, L: Line[], tick: number, side: string, openOverride = 0, hlOverride?: { h: number; l: number } | null, trail?: { t: number; c: number }[]): string {
  const o = openOverride > 0 ? openOverride : fiveOpenNow(asset);
  if (!(o > 0) || !(tick > 0)) return "";
  { const rt0 = pinkRetest(asset, L, tick, o, hlOverride, trail); if (rt0 && rt0.side === side) return ""; } // broke, tapped the pink, rejected = trade the rejection
  // NO LONG WHILE IT'S FALLING (Oct 18 ~11:01 PM PT, Love: "she just longed on gold while it was falling down again hun / can you fix that? once and for
  // all pls" - 11:00 PM gold long "On 5m PP" at 4,183.12, the candle down $1.44 from its open and printing new lows): a 5m candle down at least half her
  // break distance from its open that hasn't bounced her break distance (BTC $8 / gold 33c) off its low = still falling -> no long. Mirror: no short
  // while it's rising. A real bounce (rejection) clears it.
  {
    const dist = BREAK_DIST[asset] ?? 0;
    if (dist > 0) {
      let lo = tick, hi = tick;
      const tr0 = trail ?? (G.__stDefaultReach ? [] : (() => { const tk = Object.keys(G).filter((k) => /^__qtrail_\d+$/.test(k)).sort((a, b) => Number(b.slice(9)) - Number(a.slice(9)))[0]; const f0 = Math.floor(Date.now() / 300000) * 300000; return ((tk && G[tk]?.[asset]) || []).filter((x: any) => x && x.c > 0 && x.t >= f0); })());
      for (const x of tr0 || []) { if (x.c < lo) lo = x.c; if (x.c > hi) hi = x.c; }
      const hlF = hlOverride !== undefined ? hlOverride : (openOverride > 0 || G.__stDefaultReach ? null : fiveHLNow(asset));
      if (hlF) { lo = Math.min(lo, Number(hlF.l)); hi = Math.max(hi, Number(hlF.h)); }
      if (side === "up" && o - tick >= dist / 2 && tick - lo < dist) return `price is falling: this 5m candle is $${(o - tick).toFixed(2)} under its open and only $${(tick - lo).toFixed(2)} off its low - no long while it's falling`;
      if (side === "down" && tick - o >= dist / 2 && hi - tick < dist) return `price is rising: this 5m candle is $${(tick - o).toFixed(2)} over its open and only $${(hi - tick).toFixed(2)} off its high - no short while it's rising`;
    }
  }
  if (!(openOverride > 0) || trail) {
    const cb = candleBreaks(asset, L, o, tick, trail, hlOverride !== undefined ? hlOverride : (openOverride > 0 ? null : fiveHLNow(asset)));
    const nr = (side === "up" && cb.down) || (side === "down" && cb.up) ? nextBandReject(asset, L, tick, o, hlOverride !== undefined ? hlOverride : (openOverride > 0 ? null : fiveHLNow(asset)), trail) : null;
    if (side === "up" && cb.down && !(nr && nr.side === "up")) return `this 5m candle broke DOWN through ${cb.down.band.name} (${Number(cb.down.band.price).toFixed(2)}) - a break down is never a long this candle`;
    if (side === "down" && cb.up && !(nr && nr.side === "down")) return `this 5m candle broke UP through ${cb.up.band.name} (${Number(cb.up.band.price).toFixed(2)}) - a break up is never a short this candle`;
    if (nr && nr.side === side) return "";
    // back under a session band this candle broke UP: long only once price "reverses and flips and starts rising" - her break distance off the low since
    // the high. Mirror for shorts back over a session band this candle broke DOWN.
    {
      const dR = BREAK_DIST[asset] ?? 0;
      const trR = trail ?? (G.__stDefaultReach ? [] : (() => { const tk = Object.keys(G).filter((k) => /^__qtrail_\d+$/.test(k)).sort((a, b) => Number(b.slice(9)) - Number(a.slice(9)))[0]; const f0 = Math.floor(Date.now() / 300000) * 300000; return ((tk && G[tk]?.[asset]) || []).filter((x: any) => x && x.c > 0 && x.t >= f0); })());
      const ptsR = [...(trR || []), { t: Number.MAX_SAFE_INTEGER, c: tick }];
      if (dR > 0 && ptsR.length > 1) {
        for (const b of L.filter((l) => (isSessBand(l) || l.name === "5m PP") && Number(l.price) > 0)) {
          const bp = Number(b.price);
          if (side === "up" && o < bp && tick < bp) {
            let iH = -1, hi = -Infinity; ptsR.forEach((p, i) => { if (p.c > hi) { hi = p.c; iH = i; } });
            if (hi >= bp + dR) { const lo = Math.min(...ptsR.slice(iH).map((p) => p.c)); if (tick - lo < dR) return `price fell back under ${b.name} (${bp.toFixed(2)}) after breaking it up this candle - no long until it turns back up ($${dR} off its low)`; }
          }
          if (side === "down" && o > bp && tick > bp) {
            let iL = -1, lo = Infinity; ptsR.forEach((p, i) => { if (p.c < lo) { lo = p.c; iL = i; } });
            if (lo <= bp - dR) { const hi = Math.max(...ptsR.slice(iL).map((p) => p.c)); if (hi - tick < dR) return `price came back over ${b.name} (${bp.toFixed(2)}) after breaking it down this candle - no short until it turns back down ($${dR} off its high)`; }
          }
        }
      }
    }
    if (cb.last) return ""; // the last break decides - the older open-of-candle checks below only run when no break was seen this candle
  }
  // TAP AFTER A BREAK (Oct 16 ~4:55 PM PT, Love: "trade the rejection off of a band if it does reject, and ... the break if it
  // does break"): the candle broke a band, then reached the NEXT band beyond it and price is back under/over that band - that
  // rejection is the trade, so it isn't refused as "against the break".
  const hl = hlOverride ?? (openOverride > 0 ? null : fiveHLNow(asset));
  const tapped = (dn: boolean) => !!hl && L.some((l) => (dn ? l.price > tick && hl.h >= l.price : l.price < tick && hl.l <= l.price));
  // BAND BREAK = TRADE THE BREAK, NO TAP EXCEPTION (Oct 17 ~12:49-12:51 AM PT, Love: "a falling candle that just broke a band is not a long" /
  // "band breaks = trade the direction of the break" / "JUST the candle that broke the band"): the Oct 16 4:55 PM tap-the-next-band exception is
  // off - inside the candle that broke a band, nothing trades against the break.
  void tapped;
  if (side === "down" && tick > o) { const b = L.find((l) => o < l.price && tick > l.price); if (b) return `would short a rising 5m candle that broke up through ${b.name} (${b.price})`; }
  if (side === "up" && tick < o) { const b = L.find((l) => o > l.price && tick < l.price); if (b) return `would long a falling 5m candle that broke down through ${b.name} (${b.price})`; }
  // A BREAK IS A BREAK (Oct 17 ~1:14-1:15 AM PT, Love: "it didn't reject off of the pink love, it broke thru it... a clear break through and a bounce
  // off is not the same as a rejection. a break, is a break. a rejection, doesn't puncture the band violently and have a clear wick coming out the
  // bottom of it" + "$8 for btc" / "$1 for gold"): if this 5m candle pushed BREAK_DIST or more through a band it opened on the other side of, that
  // candle only trades the break - price snapping back doesn't make it a rejection. A touch that doesn't get BREAK_DIST through is a rejection.
  const dist = BREAK_DIST[asset] ?? 0;
  const ex = hlOverride ?? (openOverride > 0 ? null : fiveHLNow(asset));
  if (dist > 0 && ex) {
    const lo = Math.min(ex.l, tick), hi = Math.max(ex.h, tick);
    if (side === "up") { const b = L.find((l) => o > l.price && lo <= l.price - dist); if (b) return `this 5m candle broke DOWN through ${b.name} (${b.price}) by $${(b.price - lo).toFixed(2)} - a break is a break: no long this candle`; }
    if (side === "down") { const b = L.find((l) => o < l.price && hi >= l.price + dist); if (b) return `this 5m candle broke UP through ${b.name} (${b.price}) by $${(hi - b.price).toFixed(2)} - a break is a break: no short this candle`; }
  }
  return "";
}

// PINK ROOM (Oct 16 ~2:55 PM PT, Love: "$25 for btc on the pink pivot band. $1 for gold. no long into it. no short into it.
// price breaks = get in. price rejects = GET IN."): no long while the unbroken pink (5m PP) sits above price within $25 BTC /
// $1 gold, no short while it sits below price within that. Broke it or rejected off it = it's behind her, she gets in.
export const PINK_ROOM: Record<string, number> = { btc: 25, gold: 1.5 }; // fallback only, when the session bands are missing
// ROOM = 15% OF THE SESSION BAND SPACING (Oct 16 ~3:36 PM PT, Love: "keep it 15% of the bands distance. the distance between
// each band right now = band tolerance ===== 15%. if it's $100 between SESSION bands, $15 block on any LONG WITH A BAND IN
// FRONT OF IT IN THAT $$$ DISTANCE / same for a SHORT"). Session bands sit one sigma apart, so room = 0.15 x sigma.
export function roomFor(asset: string, L: Line[], x = 0.15): number {
  const u = L.find((l) => l.unit && l.unit > 0)?.unit || 0;
  return u > 0 ? x * u : (PINK_ROOM[asset] || 0) * (x / 0.15);
}
// EVERY BAND, NOT JUST PINK (Oct 16 ~3:33 PM PT, Love: "price was stilllllll under the band when she fired that... what is making
// it impossible for you to not have her long into an unbroken band?" - the 3:30 PM BTC long had R1 $23 overhead). No long with
// ANY unbroken band (pivot or session) above price within the room; no short with any band that close below.
export function pinkInFront(asset: string, L: Line[], tick: number, side: string, open = 0, x = 0.15): string {
  const room = roomFor(asset, L, x);
  if (!(room > 0) || !(tick > 0)) return "";
  let hit: Line | null = null;
  for (const l of L) {
    if (!(l.price > 0)) continue;
    // A band this 5m candle just BROKE isn't an unbroken band in front (Love: "never long or short INTO an unbroken band") - after
    // a tap of the next band, the short back toward the band it broke up through is allowed (mirror for longs). open = live 5m open.
    if (open > 0 && (side === "down" ? open < l.price && tick > l.price : open > l.price && tick < l.price)) continue;
    if (side === "up" && l.price > tick && l.price - tick <= room && (!hit || l.price < hit.price)) hit = l;
    if (side === "down" && l.price < tick && tick - l.price <= room && (!hit || l.price > hit.price)) hit = l;
  }
  if (!hit) return "";
  return side === "up" ? `would long into ${hit.name} ${(hit.price - tick).toFixed(2)} above (needs more than ${room.toFixed(2)})` : `would short into ${hit.name} ${(tick - hit.price).toFixed(2)} below (needs more than ${room.toFixed(2)})`;
}

// RED / GREEN ZONES (Oct 16 ~10:55 PM PT, Love: "if price is currently in the red, or currently in the green, she is not to long or
// to short under any circumstances. UNLESS. A session band lies within them, and that band has been broken" + "she cannnn trade
// into a red or green, if price breaks the band within it, or on trades with very strong volume. weak volume trades into red or
// green without a band break are not allowed" + "when the line is closest to price. absolutely not while it is IN the red, or IN
// the green" + yes to: very strong volume = the live 5m candle's volume at least 2x the average of the last 20 five-minute candles).
// Zones = CM Pivot Bands on 5m bars, forming candle included like her chart: red R1..R2, green S2..S1. Own math (no import).
type Zones = { pp: number; r1: number; r2: number; s1: number; s2: number };
function fiveBars(asset: string): { t: number; o: number; h: number; l: number; c: number; v: number }[] {
  const bars: any[] = G.__pivBars?.[asset]?.bars ?? [];
  const m = new Map<number, { t: number; o: number; h: number; l: number; c: number; v: number }>();
  for (const x of [...bars].sort((a, b) => Number(a.t) - Number(b.t))) {
    const k = Math.floor(Number(x.t) / 300) * 300;
    const y = m.get(k);
    if (!y) m.set(k, { t: k, o: Number(x.o), h: Number(x.h), l: Number(x.l), c: Number(x.c), v: Number(x.v) || 0 });
    else { y.h = Math.max(y.h, Number(x.h)); y.l = Math.min(y.l, Number(x.l)); y.c = Number(x.c); y.v += Number(x.v) || 0; }
  }
  return [...m.values()];
}
export function zonesNow(asset: string): Zones | null {
  const b = fiveBars(asset);
  if (b.length < 10) return null;
  const k = 2 / 8;
  let ema = 0;
  const rng: number[] = [];
  b.forEach((x, i) => { const pp = (x.h + x.l + x.c) / 3; ema = i === 0 ? pp : pp * k + ema * (1 - k); rng.push(x.h - x.l); });
  const a = rng.slice(-7).reduce((q, v) => q + v, 0) / 7;
  return { pp: ema, r1: ema + a, s1: ema - a, r2: ema + 2 * a, s2: ema - 2 * a };
}
export function volNow(asset: string): { cur: number; avg: number; frac: number } | null {
  const b = fiveBars(asset);
  if (b.length < 21) return null;
  const cur = b[b.length - 1];
  const now = Date.now() / 1000;
  if (cur.t !== Math.floor(now / 300) * 300) return null; // the live 5m candle must be this one
  const prev = b.slice(-21, -1);
  return { cur: cur.v, avg: prev.reduce((q, x) => q + x.v, 0) / prev.length, frac: Math.min(1, (now - cur.t) / 300) };
}
// STRONG VOLUME (Love ~10:58 PM PT: "ill let you be the judge... it just needs to be enough to push through"): the live 5m candle on
// pace for 2x the last 20 candles' average (pace = volume so far / share of the candle gone, judged after its first minute).
// Study (Claude outputs/zone_volume_study.py, Pepperstone Oct 11-14 + Oct 16): no volume level told a push-through from a reversal
// (into-zone entries 44-45% at every level, 1.5-2x worse), and Pepperstone's 5m volume almost never reaches 2x - so in practice
// a band break is what lets her trade into a zone. Her call to change it.
export const ZONE_VOL_X = 2;
function strongVol(v: { cur: number; avg: number; frac?: number } | null | undefined): boolean {
  if (!v || !(v.avg > 0)) return false;
  const f = v.frac ?? 1;
  if (f < 0.2) return false;
  return v.cur / f >= ZONE_VOL_X * v.avg;
}
// INTO vs AWAY (Love ~10:58 PM PT: "not NO TRADE at all? she jhust cant short into green without the other criteria, and cant long
// into red without the other requirements either. if price rejects off of the red zone, the trade is SHORT. if price rejects off of
// the green, the trade is LONG... away from them is more than allowed it is requested"). Into the red = a long while price is IN the
// red or R1 is the closest line above; into the green = a short while price is IN the green or S1 is the closest line below.
// Allowed into a zone only if a session band inside it broke this 5m candle in the trade's direction, or strong volume.
export function zoneGate(asset: string, L: Line[], tick: number, side: string, o: { zones?: Zones; open?: number; vol?: { cur: number; avg: number; frac?: number } | null } = {}): string {
  // GOLD ONLY (Oct 17 ~12:16 AM PT, Love: "the long / short into red /green it doesn't count for btc the same way it does for gold... she's clear to
  // long/short into them on btc... just not gold without the exceptions i stated pls - gold only for those")
  // BTC TOO, WITH THE PUSH (Oct 17 ~1:44 PM PT, Love: "the volume still needs to stand on btc hun... it's not a wall IF there is a push, candle was
  // not pushing through. it tapped and rejected, = short" - the 1:34 PM long $7.45 under R1 at 0.9x volume melted). Same rule as gold now.
  if (!(tick > 0) || !(side === "up" || side === "down")) return "";
  const Z = o.zones ?? zonesNow(asset);
  if (!Z) return "can't verify the red/green zones right now";
  const inRed = tick >= Z.r1 && tick <= Z.r2;
  const inGreen = tick <= Z.s1 && tick >= Z.s2;
  const lines = [...L.map((l) => Number(l.price)), Z.r1, Z.r2, Z.s1, Z.s2].filter((p) => p > 0);
  let nearest = lines[0];
  for (const p of lines) if (Math.abs(p - tick) < Math.abs(nearest - tick)) nearest = p;
  // $50 OF CLEARANCE = CLEAR (Oct 19 ~9:31 PM PT, Love, after the 9:19 PM BTC long was refused with the red $100+ away: "the red zone was $100 away
  // from the band at the time. if she has over $50 of clearance to the red / green zones she is good"): on BTC the into-zone rule only bites when the
  // zone's near edge is within $50 of price (IN the zone = no clearance, rule applies). Gold unchanged - say the number and it gets one too.
  const zReach = asset === "btc" ? 50 : Infinity;
  const intoRed = side === "up" && (inRed || (tick < Z.r1 && nearest === Z.r1 && Z.r1 - tick <= zReach));
  const intoGreen = side === "down" && (inGreen || (tick > Z.s1 && nearest === Z.s1 && tick - Z.s1 <= zReach));
  if (!intoRed && !intoGreen) return ""; // away from a zone: always allowed
  const open = o.open ?? fiveOpenNow(asset);
  const sess = L.filter((l) => /σ|VWAP/i.test(l.name) && Number(l.price) > 0);
  const lo = intoRed ? Z.r1 : Z.s2, hi = intoRed ? Z.r2 : Z.s1;
  const broke = open > 0 && sess.some((l) => l.price >= lo && l.price <= hi && (side === "up" ? open < l.price && tick > l.price : open > l.price && tick < l.price));
  if (broke) return "";
  const v = o.vol !== undefined ? o.vol : volNow(asset);
  if (strongVol(v)) return "";
  // A BIG FAST CANDLE IS A PUSH TOO (Oct 17 ~3:50 PM PT, Love: "A & B" - the 3:40 PM breakout ran $124 in 90 s while volume read 0.0x early in the
  // candle): the live 5m candle has already moved a normal candle's size (the 7-bar average range, the red/green zone spacing) in her direction.
  const avgR = Z.r1 - Z.pp;
  if (avgR > 0 && open > 0 && (side === "up" ? tick - open : open - tick) >= avgR) return "";
  const x = v && v.avg > 0 ? `${(v.cur / Math.max(v.frac ?? 1, 0.2) / v.avg).toFixed(1)}x` : "unknown";
  const where = intoRed ? (inRed ? "IN the red zone" : `R1 ${Z.r1.toFixed(2)} the closest line above`) : (inGreen ? "IN the green zone" : `S1 ${Z.s1.toFixed(2)} the closest line below`);
  return `would ${side === "up" ? "long into the red" : "short into the green"} (${where}) - no session band broke inside it and volume ${x} (needs ${ZONE_VOL_X}x)`;
}

// THE OTHER SIDE (Oct 16 ~11:12 PM PT, Love: "if a trade is rejected for being against the rules, i dont want her to ignore it. i want
// her to take the short if a long is rejected. long if a short is rejected" + "yes, if the other side fits the criteria. just not to
// completely ignore the other direction entirely"). Her band rules only - closest band, into a band (15% room), into the red/green,
// against a 5m candle break - on the live tick and band list. cantVerify (no fresh price / bands / zones, feed not healthy, self-test
// failed) = wait, never flip.
// NO BAND BETWEEN PRICE AND THE TARGET (Oct 17 ~2:02 AM PT, Love: "if it's not there definitely add it in... that's literally the first thing i
// asked her to do when i came to her to fix groks mess" + "yesssss maam, precisely" to: she never takes a trade that has to cross an unbroken band
// to reach the target). Target = her chart's price at the window's open (Vantage for BTC - the same scale as her bands; Kalshi's strike is the
// index at that moment). Bands = her walls (BTC: session bands + the pink; gold: every line); a band broken in the trade's direction is not a wall
// (wallFor). Already past the target = nothing left to cross. No window-open price yet = can't verify = she waits a tick.
// KALSHI'S LINE ON HER CHART (Oct 17 ~2:19 AM PT, Love: "the price on vantage is about $100 higher than the price on kalshi. can you have her
// deduct the price difference into her decision to skip?" + "yessss that's perfect" to: Kalshi's real strike for the window, moved onto her chart by
// the LIVE gap). 197 windows since Oct 13: Vantage ran +$92 over the strike on average but -$9 to +$161 window to window, so "Vantage at the open"
// could sit $20-30 off Kalshi's line. INDEX:BTCUSD (btc_v) runs a steady ~$30 over Kalshi's strike (sd ~$10 vs Vantage's ~$15-23). So:
// Kalshi now ~= INDEX - $30; target on her chart = strike + (Vantage - INDEX) + $30. The Vantage-INDEX gap is sampled only when both feeds ticked
// within 1 s of each other (INDEX ticks slower), paired via her quote trail (Vantage tick nearest the INDEX tick, within 2 s), smoothed. No strike for this window / no gap sample in 2 min = can't verify.
// Gold: unchanged (her chart's price at the window open) - this was asked for BTC.
export const INDEX_BIAS: Record<string, number> = { btc: 30 };
G.__indexBias = INDEX_BIAS; // kalshi.ts chartStrike reads the same bias
export function chartTarget(strike: number, gap: number, bias: number): number { return strike + gap + bias; }
function sampleGap(): void {
  try {
    // BTC ON INDEX (Oct 18 ~4:36 PM PT, Love: "INDEX PLS"): her chart is the index itself, so chart-minus-index = 0 -> target = strike + $30.
    if (G.__symBtc === "INDEX:BTCUSD") { const K0 = (G.__kGap ||= { at: 0, gap: 0, vAt: 0 }); const q0 = quoteTick("btc"); if (q0 && q0.c > 0 && Date.now() - q0.at < 120000) { K0.gap = 0; K0.at = Date.now(); K0.vAt = q0.at; } return; }
    const v = quoteTick("btc_v"), K = (G.__kGap ||= { at: 0, gap: 0, vAt: 0 });
    if (!v || !(v.c > 0) || v.at === K.vAt || Date.now() - v.at > 5000) return;
    // Pair the index tick with the Vantage tick nearest the same moment (her quote trail), so BTC's move in between doesn't leak in.
    const tk = Object.keys(G).filter((k) => /^__qtrail_\d+$/.test(k)).sort((a, b) => Number(b.slice(9)) - Number(a.slice(9)))[0];
    const tr: { t: number; c: number }[] = (tk && G[tk]?.btc) || [];
    let best: { t: number; c: number } | null = null;
    for (const x of tr) if (x && x.c > 0 && (!best || Math.abs(x.t - v.at) < Math.abs(best.t - v.at))) best = x;
    if (!best || Math.abs(best.t - v.at) > 2000) { const q = quoteTick("btc"); best = q && q.c > 0 && Math.abs(q.at - v.at) <= 2000 ? { t: q.at, c: q.c } : null; }
    if (!best) return;
    const gp = best.c - v.c;
    K.gap = K.at && Date.now() - K.at < 120000 ? K.gap * 0.8 + gp * 0.2 : gp; K.at = Date.now(); K.vAt = v.at;
  } catch {}
}
if (G.__kGapTimer) clearInterval(G.__kGapTimer);
G.__kGapTimer = setInterval(() => {
  sampleGap();
  try { for (const a of ["btc", "gold"]) { const lb = G.__lawBands?.[a], q = quoteTick(a); if (lb && Array.isArray(lb.L) && q && q.c > 0 && Date.now() - q.at < 3000) rejUpdate(a, lb.L, q.c, fiveHLNow(a), ((G.__rejMem ||= {})[a] ||= {})); } } catch {}
  try { // read-out only (data/kalshi-target.json): what the last gate sees as Kalshi's line on her chart
    const n = Date.now(); if (n - (G.__kGapOut || 0) < 3000) return; G.__kGapOut = n;
    const v = quoteTick("btc_v"), q = quoteTick("btc");
    writeFileSync(D("kalshi-target.json"), JSON.stringify({ at: new Date(n).toISOString(), strike: G.__kStrike?.btc ?? null, gap: G.__kGap ?? null, gapAgeS: G.__kGap?.at ? Math.round((n - G.__kGap.at) / 1000) : null, index: v ? { c: v.c, ageMs: n - v.at } : null, vantage: q ? { c: q.c, ageMs: n - q.at } : null, target: targetNow("btc", n) }));
  } catch {}
}, 250);
export function targetNow(asset: string, now = Date.now()): number {
  try {
    if (asset === "btc") {
      sampleGap();
      const s = G.__kStrike?.btc, K = G.__kGap;
      if (!s || !(s.strike > 0) || s.ws !== Math.floor(now / 900000) || now - s.at > 15000) return 0;
      if (!K || !K.at || now - K.at > 120000) return 0;
      return chartTarget(Number(s.strike), Number(K.gap), INDEX_BIAS.btc);
    }
    const ws = Math.floor(now / 900000) * 900;
    const ob = (G.__pivBars?.[asset]?.bars || []).find((x: any) => Number(x.t) === ws);
    return ob && Number(ob.o) > 0 ? Number(ob.o) : 0;
  } catch { return 0; }
}
export function crossToTarget(asset: string, W: Line[], tick: number, side: string, target: number): string {
  void asset;
  if (!(side === "up" || side === "down")) return "";
  if (!(target > 0) || !(tick > 0)) return "can't verify the target right now (no Kalshi strike / live gap yet)";
  if (side === "up" ? tick >= target : tick <= target) return "";
  const lo = Math.min(tick, target), hi = Math.max(tick, target);
  const hit = W.filter((l) => Number(l.price) > lo && Number(l.price) < hi).sort((a, b) => Math.abs(a.price - tick) - Math.abs(b.price - tick))[0];
  if (!hit) return "";
  return `would have to cross ${hit.name} (${Number(hit.price).toFixed(2)}, unbroken) to reach the target ${target.toFixed(2)} - no ${side === "up" ? "long" : "short"}`;
}
// AT THE SESSION BAND = WAIT (Oct 17 ~10:41 AM PT, Love: "if there is a band above / below her (closer than the other) ... have her wait, and see
// if it pushes past the session band above/below or rejects there" + "yessss that's exactly right" to: the closest band is a session band and price
// is within $8 of it on either side (gold $1 - her break depth) = at the band, both sides wait. A push $8+ through it = the break (trade it); a pull
// $8+ back away from it = the rejection (trade away). The 10:31 AM long: pink broke up, price sat a dollar or two around -2 sigma -> she'd have waited.
export function atSessionBand(asset: string, W: Line[], tick: number): string {
  const d = BREAK_DIST[asset] ?? 0;
  if (!(d > 0) || !(tick > 0) || !W.length) return "";
  const near = W.slice().sort((a, b) => Math.abs(a.price - tick) - Math.abs(b.price - tick))[0];
  if (!near || !/σ$|^session VWAP$/.test(String(near.name))) return "";
  const gap = Math.abs(near.price - tick);
  if (gap >= d) return "";
  return `at ${near.name} (${Number(near.price).toFixed(2)}, ${gap.toFixed(2)} ${tick >= near.price ? "over" : "under"} it): waiting for a break or a rejection ($${d} either way)`;
}
// SESSION BAND AHEAD OF THE PINK = WAIT (Oct 17 ~12:10 PM PT, Love: "in the event price passes a pink band and there is an unbroken session band
// above her, still need her to either wait for a break or a rejection there / going into an unbroken band is a losing recipe" + "yesss, same wait"
// for pink rejections). When the closest wall is the pink (just broke it, or bouncing off it), she looks at the session bands: if the unbroken one in
// front is closer than the one behind, she waits for it - a break ($8 through) or a rejection ($8 back). The 12:03 PM long: pink 81,526 $2.50 under,
// VWAP 81,558 $29 ahead vs -0.5 sigma $36 behind -> wait.
export function sessionAheadWait(asset: string, W: Line[], tick: number, side: string): string {
  if (!(side === "up" || side === "down") || !(tick > 0) || !W.length) return "";
  const near = W.slice().sort((a, b) => Math.abs(a.price - tick) - Math.abs(b.price - tick))[0];
  if (!near || String(near.name) !== "5m PP") return "";
  const S = W.filter((l) => /σ$|^session VWAP$/.test(String(l.name)));
  const above = S.filter((l) => l.price > tick).sort((a, b) => a.price - b.price)[0];
  const below = S.filter((l) => l.price < tick).sort((a, b) => b.price - a.price)[0];
  const ahead = side === "up" ? above : below, behind = side === "up" ? below : above;
  if (!ahead) return "";
  const da = Math.abs(ahead.price - tick), db = behind ? Math.abs(behind.price - tick) : Infinity;
  if (!(da < db)) return "";
  return `${ahead.name} (${Number(ahead.price).toFixed(2)}) unbroken ${da.toFixed(2)} ${side === "up" ? "above" : "below"}, closer than ${behind ? `${behind.name} ${db.toFixed(2)} behind` : "anything behind"}: waiting for a break or a rejection there`;
}
// NO TRADE AGAINST A REJECTION THIS CANDLE (Oct 17 ~1:03 PM PT, Love: "price didn't break through the pink band and it rejected off of it. not
// sure how that's a short" + "yeah that's fine" + ~1:04 PM "not just for pink love for session bands too"): in the live 5m candle, price tapped the
// pink or a session band (within $3 btc / $0.30 gold - the 1:00 PM candle's low sat $2.03 over the pink) without breaking it ($8 / $1) and has
// since moved $8 / $1+ away = a rejection -> no trade against it for the rest of the candle. The 1:01 PM short: low 81,594.40 on the pink 81,592.37,
// price bounced to 81,612 -> rejection up, no short.
export const PINK_TAP: Record<string, number> = { btc: 3, gold: 0.3 };
// ADD-ON TRIGGER = HER $3 TAP REJECTION (Oct 17 ~10:57 PM PT, Love: "yesss let's make it a $3 tap rejection bb"): the $2 band add-on now fires on
// the same rejection her gate uses - price tapped the pink or a session band (within $3 btc / $0.30 gold) without breaking it ($8 / $1) and moved
// $8 / $1+ away in this 5m candle - in HER direction, on her session + pink bands (no red/green). Was the old 15%-of-sigma "snap" (tap.ts), which
// needed a ~$20+ move and so almost never met the 2.8x price. Fresh price only (3 s).
// NEAR TAP FOR ADD-ONS (Love, Oct 18 ~9:43 PM PT: "it doesn't need to get that close to be considered a tap hun / if it gets near it and pushes away she can add on" + "$2 gold, $30 btc" "for the add on positions i requested. and for the delayed entry model"): price came within $30 (BTC) / $2 (gold) of the pink or a session band without breaking it, then pushed away from
// it - by her break distance from the band and her tap distance ($3 / 30c) off the candle's extreme - in HER direction = add on. Gate rules unchanged.
export const NEAR_TAP: Record<string, number> = { btc: 30, gold: 2 };
export function nearReject(asset: string, L: Line[], tick: number, mySide: "up" | "down", hl: { h: number; l: number } | null): string {
  const d = BREAK_DIST[asset] ?? 0, push = PINK_TAP[asset] ?? 0, near = NEAR_TAP[asset] ?? 0;
  if (!(d > 0) || !(near > 0) || !(tick > 0) || !hl) return "";
  const lo = Math.min(Number(hl.l), tick), hi = Math.max(Number(hl.h), tick);
  for (const l of L.filter((x) => (isSessBand(x) || x.name === "5m PP") && Number(x.price) > 0)) {
    const P = Number(l.price);
    if (mySide === "up" && lo <= P + near && lo > P - d && tick >= P + d && tick >= lo + push) return `came within $${near} of ${l.name} (${P.toFixed(2)}, low ${lo.toFixed(2)}) and pushed up away from it`;
    if (mySide === "down" && hi >= P - near && hi < P + d && tick <= P - d && tick <= hi - push) return `came within $${near} of ${l.name} (${P.toFixed(2)}, high ${hi.toFixed(2)}) and pushed down away from it`;
  }
  return "";
}
export function addOnTapNow(asset: string, mySide: "up" | "down"): string {
  const lb = G.__lawBands?.[asset];
  const q = quoteTick(asset);
  if (!lb || !Array.isArray(lb.L) || !lb.L.length || !q || !(q.c > 0) || Date.now() - q.at > 3000) return "";
  return nearReject(asset, lb.L, q.c, mySide, fiveHLNow(asset)); // + red/green zone rejections (Oct 19 ~9:56 PM PT, Love: "a rejection of a red or green zone, or any band")
}
export function pinkRejectAgainst(asset: string, L: Line[], tick: number, side: string, hlOverride?: { h: number; l: number } | null): string {
  const d = BREAK_DIST[asset] ?? 0, tap = PINK_TAP[asset] ?? 0;
  if (!(d > 0) || !(tap > 0) || !(tick > 0) || !(side === "up" || side === "down")) return "";
  const lines = L.filter((l) => /^5m (PP|R1|R2|S1|S2)$|σ$|^session VWAP$/.test(String(l.name)) && Number(l.price) > 0); // + red/green lines (Oct 17 ~1:44 PM PT)
  if (!lines.length) return "";
  const hl = hlOverride !== undefined ? hlOverride : fiveHLNow(asset);
  if (!hl) return "";
  const lo = Math.min(Number(hl.l), tick), hi = Math.max(Number(hl.h), tick);
  for (const l of lines) {
    const P = Number(l.price), nm = l.name === "5m PP" ? "the pink" : /^5m (R1|R2)$/.test(String(l.name)) ? `the red (${l.name})` : /^5m (S1|S2)$/.test(String(l.name)) ? `the green (${l.name})` : String(l.name);
    if (side === "down" && lo <= P + tap && lo > P - d && tick >= P + d) return `price rejected UP off ${nm} (${P.toFixed(2)}, low ${lo.toFixed(2)}) this 5m candle and is ${(tick - P).toFixed(2)} above it - no short against the rejection`;
    if (side === "up" && hi >= P - tap && hi < P + d && tick <= P - d) return `price rejected DOWN off ${nm} (${P.toFixed(2)}, high ${hi.toFixed(2)}) this 5m candle and is ${(P - tick).toFixed(2)} below it - no long against the rejection`;
  }
  return "";
}
// A PINK BREAK NEEDS $6 (Oct 17 ~1:30 PM PT, Love: "yeah let's make it $6 hun. that's a perfect medium between the two" - after the 12:15 PM long
// ($7.70 over the pink) and the 1:15 PM short ($3.84 under it) snapped back). When the closest wall is the pink and price is within $6 of it (gold
// $0.75) on either side, she waits: $6+ through = the break, she trades it.
// $6 PINK WAIT GONE ON BTC (Oct 17 ~8:15 PM PT, Love: "lose the $6 band wait if it's blocking winners... LOSE IT" - this week it blocked 14 trades
// that went 11-3, +$79). The same-candle break/rejection rules still stop a wick through that snaps back. Gold's $0.75 stays.
// PINK WAIT BACK ON BTC (Oct 18 ~3:31 PM PT, Love: "Yes, wait at the pink" - 3:30:23 PM she longed "On 5m PP" $5 above a falling pink that broke down 2 s
// later): within $8 of the pink (the closest wall) she waits - $8 through it = the break, $8 off it = the rejection. Gold unchanged ($0.75).
export const PINK_BREAK: Record<string, number> = { btc: 6, gold: 0.33 }; // BTC $8 -> $6 Oct 19 ~12:26 AM PT (Love: "let's lower btc's break to $6 from its original $8 tpls") // // gold 50c -> 33c Oct 18 ~9:04 PM PT (Love: "could you make the push thru a band 33 cents instead of 50 for now bb") // // gold 75c -> 50c Oct 18 ~4:00 PM PT (Love: "Yes, 50c for the pink too")
export function atPink(asset: string, W: Line[], tick: number): string {
  const d = PINK_BREAK[asset] ?? 0;
  if (!(d > 0) || !(tick > 0) || !W.length) return "";
  const near = W.slice().sort((a, b) => Math.abs(a.price - tick) - Math.abs(b.price - tick))[0];
  if (!near || String(near.name) !== "5m PP") return "";
  const gap = Math.abs(near.price - tick);
  if (gap >= d) return "";
  return `at the pink (${Number(near.price).toFixed(2)}, ${gap.toFixed(2)} ${tick >= near.price ? "over" : "under"} it): waiting for a break or a rejection ($${d} through)`;
}
// CARRY-OVER SESSION BANDS (Oct 17 ~2:42 PM PT, Love: "i'd like her to trade off of the continuation bands that match the last ones and carry off where
// they ended before the session started until the bands widen out enough for her to trade them" + "New sigma reaches 50% of old"). The session resets
// at 5 PM ET (2 PM PT) and the desk can't draw its bands until 8 five-minute candles exist - 2:15-2:35 PM today her gate had NO session bands and
// traded half-blind. Now: the last session's final VWAP/sigma carry over until the new session's sigma is at least half of it.
export function sessStartMs(now = Date.now(), asset = ""): number {
  // INDEX SESSION (Oct 18 ~4:50 PM PT): her INDEX:BTCUSD chart's VWAP session starts 00:00 UTC (5 PM PT), not 5 PM ET, so on INDEX
  // the BTC carry-over (keep the old session's bands until the new ones widen) turns over at 00:00 UTC with her chart.
  if (asset === "btc" && /^(INDEX|COINBASE):BTCUSD$/.test(String((globalThis as any).__symBtc))) return Math.floor(now / 86400000) * 86400000; // Coinbase too (00:00 UTC session)
  const p: Record<string, string> = {};
  for (const x of new Intl.DateTimeFormat("en-US", { timeZone: "America/New_York", hourCycle: "h23", hour: "2-digit", minute: "2-digit", second: "2-digit" }).formatToParts(new Date(now))) p[x.type] = x.value;
  const secs = ((Number(p.hour) - 17 + 24) % 24) * 3600 + Number(p.minute) * 60 + Number(p.second);
  return Math.floor((now - secs * 1000) / 60000) * 60000;
}
// 4 PM HANDOVER (Oct 19 ~5:36 PM PT, Love: "bands widened out on btc now she can go ahead and use the current session bands again pls / gold will widen
// out now too she can trade those as well"; her rule: keep the carried bands "until the new ones widen out enough, roughly 3:00-4:00 PM"): the carried
// bands hand over to the live session's bands 2 hours after the session start (2 PM -> 4 PM PT) at the latest, or sooner once the new sigma reaches 50%
// of the old. 5:30:20 PM gold: the desk still carried yesterday's VWAP 4164.83 / sigma 14.94 (new sigma 2.73 never reached 50%), saw -1σ $14.50 above
// and longed; her chart's live session VWAP sat 50c over her head. `now` is passed by the live caller only; the self-test cases run without it.
export function sessCarryPick(c: any, ss: number, v: number, sd: number, now = 0): { v: number; sd: number; carried: boolean } {
  if (c.cur && c.cur.sess !== ss) { c.prev = c.cur; c.cur = null; }
  const fresh = v > 0 && sd > 0;
  if (fresh) c.cur = { sess: ss, v, sd, at: Date.now() };
  const prev = c.prev && Number(c.prev.sess) < ss && Number(c.prev.sd) > 0 ? c.prev : null;
  const late = now > 0 && now - ss >= 7200000 && fresh;
  if (prev && !late && (!fresh || sd < 0.5 * Number(prev.sd))) return { v: Number(prev.v), sd: Number(prev.sd), carried: true };
  return { v: fresh ? v : 0, sd: fresh ? sd : 0, carried: false };
}
// THE 25% RULE (Oct 17 ~3:19 PM PT, Love: "she CANNT enter a trade long if she's 25% closer to the band above her than below her pls. vis versa
// applies" + "Replace closest-band with 25%"): between the band below and the band above, no long in the top 25% of the gap (no short in the bottom
// 25%). Replaces "closest band decides" (which refused everything past the middle) and the 15%-of-sigma room rule (Vantage's bands are wide).
export function quarterAllows(W: Line[], tick: number, side: string): { ok: boolean; why: string } {
  if (!(tick > 0) || !(side === "up" || side === "down")) return { ok: true, why: "" };
  const above = W.filter((l) => l.price > tick).sort((a, b) => a.price - b.price)[0];
  const below = W.filter((l) => l.price < tick).sort((a, b) => b.price - a.price)[0];
  if (!above || !below) return { ok: true, why: "" };
  const gap = above.price - below.price;
  if (!(gap > 0)) return { ok: true, why: "" };
  if (side === "up" && above.price - tick < 0.25 * gap) return { ok: false, why: `long in the top 25% between ${below.name} (${below.price.toFixed(2)}) and ${above.name} (${above.price.toFixed(2)}) - ${(above.price - tick).toFixed(2)} under ${above.name}` };
  if (side === "down" && tick - below.price < 0.25 * gap) return { ok: false, why: `short in the bottom 25% between ${below.name} (${below.price.toFixed(2)}) and ${above.name} (${above.price.toFixed(2)}) - ${(tick - below.price).toFixed(2)} over ${below.name}` };
  return { ok: true, why: "" };
}
// SESSION + PINK ONLY BOOKS (Oct 17 ~6:01 PM PT, Love: "run her on live without them, just on a new ledger - session only with all of our other
// rules. don't throw away this one"): these books never see the red/green pivot zones (no zone rule, no rejections off R1/R2/S1/S2).
export const ZONES_OFF = new Set<string>(["ogp5-sess", "ogp5-c1", "ogp5-c5", "ogp5-hrs", "ogp5-bbsr", "ogp5-dly", "brk-sesspk"]); // + the close twins (Oct 17 ~10:50 PM PT, paper)
const noZ = (L: Line[]) => L.filter((l) => !/^5m (R1|R2|S1|S2)$/.test(String(l.name)));
export const ROOM_TWIN: Record<string, number> = { "ogp5-r15": 0.15, "ogp5-r30": 0.30 }; // paper twins that keep the sigma room rule
// CLOSEST-BAND TWIN (Oct 17 ~4:29 PM PT, Love: "yes pls"): her book exactly + the old "closest band decides" rule, to compare with the 25% rule.
export const CB_TWIN = new Set<string>(["ogp5-cb"]);
// A REJECTION HOLDS UNTIL PRICE COMES BACK (Oct 17 ~4:54 PM PT, Love: yes to "(a) a rejection carries over until price comes back to that band" after
// the 4:45 PM short: price rose off the pink in the 4:40 candle and the new candle forgot it). Watched every 250 ms: a tap ($3) and pull-away ($8,
// no break) off the pink / a session band / red-green line is remembered; no trade back INTO that band until price touches it again (or 60 min).
type RejMem = Record<string, { dir: "up" | "down"; at: number; price: number }>;
export function rejUpdate(asset: string, L: Line[], tick: number, hl: { h: number; l: number } | null, mem: RejMem, now = Date.now()): void {
  const d = BREAK_DIST[asset] ?? 0, tap = PINK_TAP[asset] ?? 0;
  if (!(d > 0) || !(tick > 0)) return;
  for (const l of L) {
    if (!/^5m (PP|R1|R2|S1|S2)$|σ$|^session VWAP$/.test(String(l.name)) || !(Number(l.price) > 0)) continue;
    const P = Number(l.price), m = mem[l.name];
    if (m && (Math.abs(tick - P) <= tap || now - m.at > 3600000)) { delete mem[l.name]; continue; }
    if (!hl) continue;
    const lo = Math.min(hl.l, tick), hi = Math.max(hl.h, tick);
    if (lo <= P + tap && lo > P - d && tick >= P + d) mem[l.name] = { dir: "up", at: now, price: P };
    else if (hi >= P - tap && hi < P + d && tick <= P - d) mem[l.name] = { dir: "down", at: now, price: P };
  }
}
export function rejCarryAgainst(asset: string, L: Line[], tick: number, side: string, mem?: RejMem): string {
  const M: RejMem = mem ?? (((G.__rejMem ||= {})[asset]) || {});
  for (const l of L) {
    const m = M[l.name]; if (!m) continue;
    const P = Number(l.price), nm = l.name === "5m PP" ? "the pink" : String(l.name);
    if (!inReachL(asset, l, tick)) continue; // too far away to be an obstacle (BLOCK RANGE; red/green pivots use zoneReach)
    if (side === "down" && m.dir === "up" && tick > P) return `price rejected UP off ${nm} (${P.toFixed(2)}) and hasn't come back to it - no short into it`;
    if (side === "up" && m.dir === "down" && tick < P) return `price rejected DOWN off ${nm} (${P.toFixed(2)}) and hasn't come back to it - no long into it`;
  }
  return "";
}
export function bandRulesVerdict(asset: string, side: string, roomX = 0, cb = false, zonesOff = false, noHold = false, bb = false, pinkK = 0, noAtWait = false, sessRej = false): { rule: string; cantVerify: boolean } {
  if (!(asset === "gold" || asset === "btc") || !(side === "up" || side === "down")) return { rule: "", cantVerify: true };
  const lb = G.__lawBands?.[asset];
  const q = quoteTick(asset);
  if (G.__bandLawBroken || !lb || !Array.isArray(lb.L) || !lb.L.length || Date.now() - Number(lb.at) > 15000 || !q || !(q.c > 0) || Date.now() - q.at > 3000) return { rule: "", cantVerify: true };
  if (!feedHealth(asset).ok) return { rule: "", cantVerify: true };
  if (!lb.L.some((l: Line) => /σ$|^session VWAP$/.test(String(l.name)))) return { rule: "", cantVerify: true };
  const W = wallLines(asset, lb.L);
  const BkV = refreshBroken(asset, lb.L, q.c);
  const pkFreeV = pinkK > 0 && pinkRecentFree(asset, lb.L, q.c, side, BkV, pinkK); // paper pink-theory twins only
  const rgOff = rgOffFor(side);
  const WallV = wallFor(rgOff(pkFreeV ? noPink(W) : W), BkV, q.c, side);
  const LZv: Line[] = rgOff(zonesOff ? noZ(lb.L) : lb.L);
  const rtV0 = pinkRetest(asset, lb.L, q.c); const rtV = rtV0 && rtV0.side === side ? rtV0 : null; // "current candle + broken band = no barrier / short"
  const r = rtV ? "" : candleBreakAgainst(asset, W, q.c, side) || sessionBreakPinkHold(asset, lb.L, q.c, side) || pinkRejectAgainst(asset, LZv, q.c, side) || (zonesOff || noHold ? "" : rejCarryAgainst(asset, LZv, q.c, side)) || (roomX > 0 ? pinkInFront(asset, WallV, q.c, side, fiveOpenNow(asset), roomX) : "") || (zonesOff ? "" : zoneGate(asset, lb.L, q.c, side)) || crossToTarget(asset, WallV, q.c, side, targetNow(asset)) || (noAtWait ? "" : atSessionBand(asset, WallV, q.c)) || (noAtWait ? "" : atPink(asset, WallV, q.c));
  if (r) return { rule: r, cantVerify: /can't verify/.test(r) };
  const ns = nearSide(WallV, q.c);
  if (!ns) return { rule: "", cantVerify: true };
  void cb;
  { const aw = awayVerdict(asset, rgOff(lb.L), q.c, side, BkV, { pinkFree: pkFreeV, sessRej }, bb ? bbLines(asset) : []); if (aw) return { rule: aw, cantVerify: false }; } // HER RULE: away from the closest band, break = trade the break
  return { rule: "", cantVerify: false };
}

// WALLS (Oct 17 ~12:16 AM PT, Love: "treat the closest line like a band for red, and for green" + "a rejection off of red or green is still an entry for
// btc / but it's not the same wall as it is for gold"): gold's walls are every line incl. 5m R1/R2/S1/S2; BTC's walls are the session bands + the
// pink only - the red/green lines are entries on BTC, never a block.
export function wallLines(asset: string, L: Line[]): Line[] {
  return asset === "btc" ? L.filter((l) => !/^5m (R1|R2|S1|S2)$/.test(String(l.name))) : L;
}
// 1.28x ROAD (Oct 17 ~12:19 AM PT, Love: "no i want her floor at 1.38 hun its not worth the risk otherwise / she can take a 1.28x if btc is over $125
// from the target and there is a clear road with no band in sight for a rejection"). Target on her chart's scale = her chart's price at the window's
// open (Kalshi's strike is the index at that moment; Vantage runs ~$87 over it). Clear road = no line (session, pink, red/green) within 1 sigma in
// front of the trade. Anything else, or anything unverifiable = 1.38x.
// 75c CEILING FOR HER BREAKS (Oct 19 ~4:23 PM PT, Love: "75 is fine" - the 4:01 PM gold short met 78c on Kalshi a second after the break, over her
// 72c ceiling): the session + pink book may pay up to 75c (1.33x); everything else unchanged (the BTC 1.28x road still applies where it's lower).
export function floorFor(asset: string, side: string, book = ""): number {
  const f = floorBase(asset, side);
  return PASS_THRU.has(book) ? Math.min(f, 1.33) : f;
}
function floorBase(asset: string, side: string): number {
  if (asset !== "btc" || !(side === "up" || side === "down")) return 1.38;
  try {
    const lb = G.__lawBands?.[asset];
    const q = quoteTick(asset);
    if (!lb || !Array.isArray(lb.L) || !q || !(q.c > 0) || Date.now() - q.at > 3000) return 1.38;
    const ws = Math.floor(Date.now() / 900000) * 900;
    const ob = (G.__pivBars?.[asset]?.bars || []).find((x: any) => Number(x.t) === ws);
    const unit = (lb.L as Line[]).find((l) => l.unit && l.unit > 0)?.unit || 0;
    if (!ob || !(Number(ob.o) > 0) || !(unit > 0)) return 1.38;
    const dist = side === "up" ? q.c - Number(ob.o) : Number(ob.o) - q.c;
    const ahead = (lb.L as Line[]).some((l) => (side === "up" ? l.price > q.c && l.price - q.c <= unit : l.price < q.c && q.c - l.price <= unit));
    return dist >= 125 && !ahead ? 1.28 : 1.38;
  } catch { return 1.38; }
}

// SESSION BREAK BEATS THE PINK (Oct 17 ~12:23-12:26 AM PT, Love: "if price breaks a session band right under/over the pink, the session band takes
// precedence over the pink band. in the event price breaks up like that and stalls under a pink, wait for a break, or for a rejection. don't short
// without confirmation if price breaks through a session band underneath / over like that" + yes to: rejection = price taps the pink and a 1m candle
// closes back under it; break = the pink breaks; "just under/over" = the pink within $25 of the session band that broke on BTC). While that holds,
// both sides wait - except the confirmed rejection side. Gold: no number yet (Love to set before Sunday's open).
export const PINK_HOLD_GAP: Record<string, number> = { btc: 25 };
// THE BREAK STAYS IN CHARGE (Oct 17 ~12:47 AM PT, Love: "yessss do both of those" to: after a session band breaks down, no long off a pink
// rejection below it - she only shorts once the pink breaks - until price closes back above the session band (mirror for up); replaces the 1m
// rejection exception that let the 12:46 AM long through). While price sits between the broken session band and the pink within $25 beyond it,
// both sides wait: the pink breaking (or a 5m close back through the session band) ends it.
function fiveClosed(asset: string, now: number, bars0?: any[]): { o: number; h: number; l: number; c: number; t: number } | null {
  const f0 = Math.floor(now / 300) * 300;
  const bs = ((bars0 ?? G.__pivBars?.[asset]?.bars ?? []) as any[]).filter((x) => Number(x.t) >= f0 - 300 && Number(x.t) < f0).sort((a, b) => Number(a.t) - Number(b.t));
  if (!bs.length) return null;
  return { t: f0 - 300, o: Number(bs[0].o), h: Math.max(...bs.map((x) => Number(x.h))), l: Math.min(...bs.map((x) => Number(x.l))), c: Number(bs[bs.length - 1].c) };
}
export function sessionBreakPinkHold(asset: string, L: Line[], tick: number, side: string, o: { open?: number; bars?: any[]; now?: number } = {}): string {
  const gap = PINK_HOLD_GAP[asset];
  if (!(gap > 0) || !(tick > 0) || !(side === "up" || side === "down")) return "";
  const P = Number(L.find((l) => l.name === "5m PP")?.price) || 0;
  if (!(P > 0)) return "";
  const now = o.now ?? Date.now() / 1000;
  const open = o.open ?? fiveOpenNow(asset);
  const k = fiveClosed(asset, now, o.bars);
  const sess = L.filter((l) => /σ|VWAP/i.test(String(l.name)) && Number(l.price) > 0);
  // UP: price over a session band it broke (this candle, or the last 5m closed over it), unbroken pink within $25 above
  // ONLY THE CANDLE THAT BROKE THE BAND (Oct 17 ~12:51 AM PT, Love: "no, JUST the candle that broke the band hun. if a new candle starts, and
  // rejects off of pink, she can take that trade")
  void k;
  const sUp = P > tick ? sess.find((s) => s.price < tick && P - s.price <= gap && open > 0 && open < s.price) : undefined;
  const sDn = !sUp && P < tick ? sess.find((s) => s.price > tick && s.price - P <= gap && open > 0 && open > s.price) : undefined;
  if (sUp) return `${sUp.name} broke UP right under the pink (${P.toFixed(2)}) - the break is in charge this candle: no short off the pink; long once the pink breaks`;
  if (sDn) return `${sDn.name} broke DOWN right over the pink (${P.toFixed(2)}) - the break is in charge this candle: no long off the pink; short once the pink breaks`;
  return "";
}
// PINK REJECTION NEEDS A 5m CLOSE (Oct 17 ~12:47 AM PT, Love: "yessss do both of those"): a trade booked as a rejection off the pink (5m PP)
// only counts if the last closed 5m candle tapped the pink and closed back on the rejection side (long: low at/under it, close over it).
export function pinkRejectNeeds5m(asset: string, L: Line[], side: string, o: { bars?: any[]; now?: number } = {}): string {
  const P = Number(L.find((l) => l.name === "5m PP")?.price) || 0;
  if (!(P > 0) || !(side === "up" || side === "down")) return "";
  const k = fiveClosed(asset, o.now ?? Date.now() / 1000, o.bars);
  if (k && (side === "up" ? k.l <= P && k.c > P : k.h >= P && k.c < P)) return "";
  return `pink rejection needs a 5m candle that tapped the pink (${P.toFixed(2)}) and closed back ${side === "up" ? "over" : "under"} it`;
}
function isPinkReject(r: any): boolean {
  return !!r && /^5m PP/.test(String(r.band?.name || "")) && /reject/i.test(String(r.goldLaw?.kind || "") + " " + String(r.label || ""));
}
function setupRow(ticker: string, book: string, side: string): any {
  try {
    const c = (G.__setupRows ||= { at: 0, rows: [] as any[] });
    if (Date.now() - c.at > 2000) { const rs = JSON.parse(readFileSync(D("grok-og.json"), "utf8")); c.rows = Array.isArray(rs) ? rs.slice(0, 400) : []; c.at = Date.now(); }
    return c.rows.find((x: any) => x && x.ticker === ticker && x.lane === book && x.side === side) || null;
  } catch { return null; }
}

// A BROKEN BAND IS A BROKEN WALL (Oct 17 ~1:19 AM PT, Love: "yes. a broken band is not a wall. it is a broken wall / if price pushes and breaks a
// band, it pushes back up, it's not a wall until price closes above it, a 5M close for the pivot band, because the 1m bands are not the same").
// A line a 5m candle pushed BREAK_DIST+ through (from the side it opened on) stops counting as a wall for the closest-band and room checks until a
// candle CLOSES back across it: a 5m close for pivot lines (pink, R/S), a 1m close for session bands (VWAP, sigma). The candle-break rule still sees it.
type Broke = Record<string, { side: "up" | "down"; at: number }>;
export function refreshBroken(asset: string, L: Line[], tick: number, o: { bars?: any[]; now?: number; open?: number; hl?: { h: number; l: number } | null; state?: Broke } = {}): Map<string, "up" | "down"> {
  const out = new Map<string, "up" | "down">();
  try {
    const dist = BREAK_DIST[asset] ?? 0;
    if (!(dist > 0) || !(tick > 0)) return out;
    const st: Broke = o.state ?? (((G.__brokenWalls ||= {})[asset] ||= {}) as Broke);
    const now = o.now ?? Date.now() / 1000;
    const open = o.open ?? fiveOpenNow(asset);
    const ex = o.hl !== undefined ? o.hl : fiveHLNow(asset);
    const bars = ((o.bars ?? G.__pivBars?.[asset]?.bars ?? []) as any[]).slice().sort((a, b) => Number(a.t) - Number(b.t));
    const f0 = Math.floor(now / 300) * 300, m0 = Math.floor(now / 60) * 60;
    const in5 = bars.filter((x) => Number(x.t) >= f0 - 300 && Number(x.t) < f0);
    const k5 = in5.length ? { t: f0 - 300, c: Number(in5[in5.length - 1].c) } : null;
    const b1 = bars.find((x) => Number(x.t) === m0 - 60);
    const k1 = b1 ? { t: m0 - 60, c: Number(b1.c) } : null;
    for (const l of L) {
      if (!(Number(l.price) > 0)) continue;
      if (open > 0 && ex) {
        const lo = Math.min(Number(ex.l), tick), hi = Math.max(Number(ex.h), tick);
        if (open > l.price && lo <= l.price - dist) st[l.name] = { side: "down", at: st[l.name]?.side === "down" ? st[l.name].at : now };
        else if (open < l.price && hi >= l.price + dist) st[l.name] = { side: "up", at: st[l.name]?.side === "up" ? st[l.name].at : now };
      }
      const b = st[l.name];
      if (!b) continue;
      const sess = /σ|VWAP/i.test(String(l.name));
      const kc = sess ? k1 : k5;
      const fromT = sess ? Math.floor(b.at / 60) * 60 : Math.floor(b.at / 300) * 300;
      if (kc && kc.t >= fromT && (b.side === "down" ? kc.c > l.price : kc.c < l.price)) { delete st[l.name]; continue; }
      out.set(l.name, b.side);
    }
  } catch {}
  return out;
}
// DIRECTIONAL (Oct 17 ~1:38 AM PT - the 1:36:32 AM backwards long): a broken wall is only ignored IN FRONT of the break direction - a band broken
// DOWN that price snapped back above can't block a SHORT; a band broken UP that price fell back under can't block a LONG. Everywhere else it stays a
// line: a band broken down and still above price is a wall over a long and the band that points the short (it was dropped entirely before, so the
// short read the +0.5 sigma $34 below as closest, got refused, and flipped long under the +1 sigma).
export function wallFor(W: Line[], Bk: Map<string, "up" | "down">, tick: number, side: string): Line[] {
  return W.filter((l) => {
    const b = Bk.get(l.name);
    if (!b) return true;
    if (side === "down" && b === "down" && l.price < tick) return false;
    if (side === "up" && b === "up" && l.price > tick) return false;
    return true;
  });
}
