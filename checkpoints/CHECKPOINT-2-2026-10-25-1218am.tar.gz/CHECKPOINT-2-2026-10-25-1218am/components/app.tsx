import { Component, memo, startTransition, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { Toaster, toast } from "sonner";
import { RollDigits, useLiveCountdown, useRollingNumber, useRollingPrice } from "@/components/desk/rolling-price";
import { AssetCard, AltCard } from "@/components/desk/asset-card";
import { CashBook, type CashVenue } from "@/components/desk/cash";
import { Audit } from "@/components/desk/audit";
import { FillLog } from "@/components/desk/fill-log";
import { Journal, Analytics, DayBook, Notes } from "@/components/desk/journal";
import { DayBoardTab } from "@/components/desk/dayboard";
import { BookWatchTab, useBookWatch } from "@/components/desk/bookwatch";
import { ScopeTab } from "@/components/desk/scope";
import { HandGuard } from "@/components/desk/hand-guard";
import { SchedulePill } from "@/components/desk/schedule-pill";
import { ScannerTab } from "@/components/desk/scanner";
import { BenchCard } from "@/components/desk/bench";
import { PositionsTab } from "@/components/desk/kalshi-positions";
import { pointsFromFills, pointsFromPrime, TapeBook } from "@/components/desk/kalshi-tape";
import { HedgeBook } from "@/components/desk/hedge-book";
import { LookPanel } from "@/components/desk/look-panel";
import { Positions } from "@/components/desk/positions";
import { ScaleBook } from "@/components/desk/scale";
import { SitRep, explainExit, explainTake, whyTrade } from "@/components/desk/sitrep";
import { SettingsDrawer } from "@/components/desk/settings-drawer";
import { autoDecision } from "@/lib/desk/auto";
import { lateWindow } from "@/lib/desk/setup";
import { askDeskGrok, armLiveNow, askHelp, closeNow, exitLiveOrder, getAltBoards, getAudit, getBookMode, getComboRows, getDecidedRows, getDeskSnapshot, getExitLog, getFillLog, getFuelRows, getHalfRows, getHeldOrders, getKalshiCash, getLeanRows, getLiveSize, getLiveSpots, getLiveSwitch, setLiveSwitch, getRunBooks, getSchedule, getArchived, setArchived, setRunBook, saveRunPreset, applyRunPreset, stepOut, getNightHist, getShiftSummary, getShiftRows, setAutoRoll, getLiveByBook,
  getLiveCopyMap,
  getBookHistory, getShadow, getLotto, getTruth, getNight, getTrajectory, getPathExits, getPaperTp, setPaperTp, getClaudeBacktest, getMonitor, getPrimeRecords, setFortyRule, getRules, setRule, getMirrorSheet, getOutside, getPolyLedger, getPrimeBook, getPrimeRows, getPrimeScore, getPrimeWatch, getScale75, getSetupBoard, getSymbolLab, getTrail, getWatch, halfLiveOrder, halfNow, partNow, pullBook, pushBook, resizeLiveOrder, setBookMode, setEntries, setLiveSize, getLineupMode, setLineupMode, getBench, setBench, setPinSale, setScale75, setTrailFloor, trimNow, type HeldOrder } from "@/lib/desk/fns";
import { trailScale, exitForMultiple, firedBackwards, heldSide, markTrade, outcomeProfit, settleSide, sized, bugExit, smallExit, windowCloseMs, windowStillOpen } from "@/lib/desk/paper";
import { countdown, money, multiple, pct, reachText, usd } from "@/lib/desk/format";
import { goldHaltFill, goldHalted } from "@/lib/desk/hours";
import { farBandProbe } from "@/lib/desk/probe";
import { sessionStats, useDesk } from "@/lib/desk/store";
import { LOOK_DEFAULT, loadLook, saveLook, type Look } from "@/lib/desk/look";
import { Sparkline } from "@/components/desk/sparkline";
import { TrajectoryPanel } from "@/components/desk/trajectory";
import { overlayDesk } from "@/lib/desk/ticker";
import type { AssetId, AssetSnapshot, DeskSnapshot, Setup } from "@/lib/desk/types";
import { cn } from "@/lib/cn";
// OWN CLOSE LANE (Oct 16, Love: "close at market when i click... no latency pls"): the close goes to its own door (port 8091),
// out of the browser's 6-at-a-time line behind the page's polling. Falls back to the normal path if that door is down.
function fastClose(ticker: string, tapAt?: number): Promise<{ line: string }> {
  const clickAt = Date.now();
  const url = `${window.location.protocol}//${window.location.hostname}:8091/close`;
  return fetch(url, { method: "POST", body: JSON.stringify({ ticker, clickAt, tapAt: tapAt || 0 }), headers: { "Content-Type": "text/plain" } })
    .then((r) => (r.ok ? r.json() : Promise.reject(new Error(String(r.status)))))
    .catch(() => closeNow({ data: { ticker, clickAt } }));
}

// 25% / 50% ON THE EXPRESS LANE (Oct 17 ~3:00 PM PT, Love: "i just closed 3/4 of my position trying to close 25%"): same door as CLOSE.
function fastPart(ticker: string, pct: number): Promise<{ ok?: boolean; line: string }> {
  const url = `${window.location.protocol}//${window.location.hostname}:8091/part`;
  return fetch(url, { method: "POST", body: JSON.stringify({ ticker, pct, clickAt: Date.now() }), headers: { "Content-Type": "text/plain" } })
    .then((r) => (r.ok ? r.json() : Promise.reject(new Error(String(r.status)))))
    .catch(() => partNow({ data: { ticker, pct } }));
}

// SCROLL ANCHOR (Love, Oct 5 ~1:15 PM PT: "the page keeps jumping up and down"). Cards above where she is reading grow and
// shrink as trades open and close and numbers refresh; Safari has no built-in scroll anchoring, so the page jumped. This
// holds whatever she is looking at in place: it remembers an element near the top of the view and, whenever the page's
// content changes, scrolls by exactly how far that element moved. Native anchoring is switched off so the two never fight.
function useScrollAnchor(ref: { current: HTMLDivElement | null }) {
  useEffect(() => {
    const el = ref.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    el.style.overflowAnchor = "none";
    let anchor: Element | null = null;
    let anchorTop = 0;
    let fixing = false;
    let frame = 0;
    // Her own taps (12H / 24H / ALL, opening a card, a tab) are meant to move things: don't hold the page for 0.7s after one.
    let quietUntil = 0;
    const pick = () => {
      anchor = null;
      if (el.scrollTop < 8) return; // at the very top: nothing to hold
      const box = el.getBoundingClientRect();
      let n = document.elementFromPoint(box.left + box.width / 2, box.top + Math.min(120, box.height / 4));
      // climb off tiny text to a block (a card / row) at least 24px tall
      while (n && n !== el && n.getBoundingClientRect().height < 24) n = n.parentElement;
      if (!n || n === el || !el.contains(n)) return;
      anchor = n;
      anchorTop = n.getBoundingClientRect().top;
    };
    const check = () => {
      frame = 0;
      if (!anchor || !anchor.isConnected || Date.now() < quietUntil) {
        pick();
        return;
      }
      const d = anchor.getBoundingClientRect().top - anchorTop;
      if (Math.abs(d) >= 1) {
        fixing = true;
        el.scrollTop += d;
        anchorTop = anchor.getBoundingClientRect().top;
        requestAnimationFrame(() => {
          fixing = false;
        });
      }
    };
    const soon = () => {
      if (!frame) frame = requestAnimationFrame(check);
    };
    const onScroll = () => {
      if (!fixing) pick();
    };
    const onTap = () => {
      quietUntil = Date.now() + 700;
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    el.addEventListener("pointerdown", onTap, { passive: true });
    el.addEventListener("keydown", onTap);
    const ro = new ResizeObserver(soon);
    const content = el.children;
    for (const c of Array.from(content)) ro.observe(c);
    const mo = new MutationObserver(soon);
    mo.observe(el, { childList: true, subtree: true });
    pick();
    return () => {
      el.removeEventListener("scroll", onScroll);
      el.removeEventListener("pointerdown", onTap);
      el.removeEventListener("keydown", onTap);
      ro.disconnect();
      mo.disconnect();
      if (frame) cancelAnimationFrame(frame);
    };
  }, [ref]);
}

function ticketDollars(row: { result: string; multiple?: number; profit?: number | null }): number | null {
  if (row.result !== "open" && row.profit != null && Number.isFinite(row.profit)) return row.profit;
  if (row.result === "no") return -25;
  if (row.multiple && row.multiple > 1) return Math.round(25 * (row.multiple - 1) * 100) / 100;
  return null;
}

function bookedDollars(row: { result: string; multiple?: number; profit?: number | null }): number | null {
  if (row.result === "open") return null;
  return ticketDollars(row);
}

function PaperShelf({
  title,
  blurb,
  rows,
}: {
  title: string;
  blurb: string;
  rows: { id: string; asset: string; side: string; pattern: string; result: string; multiple?: number; profit?: number | null }[];
}) {
  const yes = rows.filter((row) => row.result === "yes").length;
  const no = rows.filter((row) => row.result === "no").length;
  const dollars = rows.reduce((sum, row) => sum + (bookedDollars(row) ?? 0), 0);
  return (
    <section className="mt-4 rounded-md border border-white bg-black px-4 py-4 text-white">
      <div className="flex items-end justify-between gap-3">
        <p className="text-[10px] tracking-[0.22em] text-white/70">{title}</p>
        <p className="text-right font-mono text-xs">
          <span className={dollars >= 0 ? "text-up" : "text-down"}>{money(dollars)}</span>
          <span className="text-white/40"> · </span>
          <span className="text-up">{yes} yes</span>
          <span className="text-white/40"> / </span>
          <span className="text-down">{no} no</span>
        </p>
      </div>
      <p className="mt-2 text-xs leading-snug text-white/70">{blurb}</p>
      {rows.length === 0 ? (
        <p className="mt-4 text-sm text-white/70">Nothing yet. The next window will show here.</p>
      ) : (
        <ul className="mt-3 space-y-2">
          {rows.map((row) => {
            const dollars = ticketDollars(row);
            return (
              <li key={row.id} className="flex items-start justify-between gap-3 rounded-md border border-white bg-black px-4 py-2.5">
                <div className="min-w-0">
                  <p className="text-sm text-white">
                    {row.asset.toUpperCase()} {row.side.toUpperCase()}
                    <span className="ml-2 text-xs uppercase tracking-wider text-white/70">
                      {row.multiple && row.multiple > 1 ? `${row.multiple.toFixed(2)}x · ` : ""}
                      {row.result === "yes" ? "yes" : row.result === "no" ? "no" : "open"}
                    </span>
                  </p>
                  <p className="mt-1 text-xs text-white/60">{row.pattern}</p>
                </div>
                <div className="text-right">
                  <p className={`font-mono text-sm tabular-nums ${dollars == null ? "text-white/50" : dollars >= 0 ? "text-up" : "text-down"}`}>
                    {dollars == null ? "—" : money(dollars)}
                  </p>
                  {row.result === "open" && dollars != null ? <p className="font-mono text-[10px] text-white/50">if yes</p> : null}
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}

function ComboBook({
  rows,
}: {
  rows: { id: string; at: string; asset: string; side: string; pattern: string; route: string; dollars: number; result: string }[];
}) {
  const yes = rows.filter((row) => row.result === "yes").length;
  const no = rows.filter((row) => row.result === "no").length;
  return (
    <section className="rounded-md border border-white bg-black px-4 py-4 text-white">
      <div className="flex items-end justify-between gap-3">
        <p className="text-[10px] tracking-[0.22em] text-white/70">PRIME + PAPER</p>
        <p className="text-right font-mono text-xs">
          <span className="text-up">{yes} yes</span>
          <span className="text-white/40"> / </span>
          <span className="text-down">{no} no</span>
        </p>
      </div>
      <p className="mt-2 text-xs leading-snug text-white/70">
        The two live routes. Prime stays on its book. The paper book sends Bitcoin and gold only, at $10, and only one side at a time. Nothing else can send.
      </p>
      {rows.length === 0 ? (
        <p className="mt-4 text-sm text-white/70">Nothing sent on the combined book yet. The next one will show here.</p>
      ) : (
        <ul className="mt-3 space-y-2">
          {rows.map((row) => (
            <li key={row.id} className="flex items-start justify-between gap-3 rounded-md border border-white bg-black px-4 py-2.5">
              <div className="min-w-0">
                <p className="text-sm text-white">
                  {row.asset.toUpperCase()} {row.side.toUpperCase()}
                  <span className="ml-2 text-xs uppercase tracking-wider text-white/70">
                    {row.route} · ${row.dollars} · {row.result}
                  </span>
                </p>
                <p className="mt-1 text-xs text-white/60">{row.pattern}</p>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function useHydrated() {
  const [h, setH] = useState(false);
  useEffect(() => setH(true), []);
  return h;
}

function useForeground() {
  const [on, setOn] = useState(true);
  useEffect(() => {
    const sync = () => setOn(document.visibilityState === "visible");
    sync();
    document.addEventListener("visibilitychange", sync);
    return () => document.removeEventListener("visibilitychange", sync);
  }, []);
  return on;
}

function useWakeLock(active: boolean) {
  useEffect(() => {
    if (!active || typeof navigator === "undefined" || !("wakeLock" in navigator)) return;
    let lock: WakeLockSentinel | null = null;
    let cancelled = false;

    const request = async () => {
      try {
        lock = await navigator.wakeLock.request("screen");
      } catch {
        // iOS may deny unless the desk is installed / foregrounded
      }
    };

    void request();
    const onVis = () => {
      if (!cancelled && document.visibilityState === "visible") void request();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      cancelled = true;
      document.removeEventListener("visibilitychange", onVis);
      void lock?.release();
    };
  }, [active]);
}

function PnlFigure({ value, ready }: { value: number; ready: boolean }) {
  const shown = useRollingNumber(value);
  return (
    <p className={`mt-1 font-mono text-3xl tabular-nums leading-none ${shown >= 0 ? "text-up" : "text-down"}`}>
      {ready ? money(shown) : "—"}
    </p>
  );
}

const StillJournal = memo(Journal);

const salePins = new Map<string, number>();
const SALE_PCTS = [25, 38, 50, 75, 100];

function savedSale(ticker: string): number | null {
  const held = salePins.get(ticker);
  if (held != null) return held;
  try {
    const n = Number(localStorage.getItem(`aurelius-sale-pct:${ticker}`));
    if (!Number.isFinite(n) || n < 5) return null;
    salePins.set(ticker, n);
    return n;
  } catch {
    return null;
  }
}

function keepSale(ticker: string, n: number) {
  salePins.set(ticker, n);
  try {
    localStorage.setItem(`aurelius-sale-pct:${ticker}`, String(n));
  } catch {
    // the map still holds it for this session
  }
}

function patternBackwards(side: string, pattern: string): boolean {
  const above = /\+[0-9]/.test(pattern);
  if (side === "up" && (pattern.startsWith("Open -") || pattern.startsWith("Open −") || pattern.includes("through −") || pattern.includes("through -"))) return true;
  if (side === "down" && (above || pattern === "At VWAP")) return true;
  return false;
}

function LiveOrder({
  row,
  spot,
  mark,
  closeTime,
  secondsLeft,
  why,
  onRefresh,
}: {
  row: HeldOrder;
  spot: number;
  mark: number;
  closeTime?: string;
  secondsLeft: number;
  why: string;
  onRefresh: () => void;
}) {
  const step = row.name === "BTC" ? 1 : 0.01;
  const price = useRollingPrice(spot);
  const strike = useRollingPrice(row.target ?? 0);
  const left = useLiveCountdown(closeTime, secondsLeft);
  const maxCash = Math.round(row.contracts * 100) / 100;
  const mult = row.cost > 0 ? maxCash / row.cost : 0;
  const cash = mark > 0 ? mark : row.value > 0 ? row.value : 0;
  const halfCash = cash > 0 ? cash / 2 : 0;
  const cashRoll = useRollingPrice(cash);
  const halfRoll = useRollingPrice(halfCash);
  const livePct = row.cost > 0 ? ((cash - row.cost) / row.cost) * 100 : 0;
  const pctRoll = useRollingNumber(livePct);
  const tone = pctRoll > 0.5 ? "text-up" : pctRoll < -0.5 ? "text-down" : "text-white";
  const maxPct = row.cost > 0 && maxCash > row.cost ? Math.round(((maxCash - row.cost) / row.cost) * 1000) / 10 : 100;
  const cap = Math.max(5, maxPct);
  // Default slider = her per-multiple take-profit table (33 / 44 / 50 / 60 / max-15).
  const entryPx = row.contracts > 0 ? row.cost / row.contracts : 0;
  const tableArm = trailScale(entryPx).arm;
  const gatePct = tableArm > 0 ? Math.min(cap, tableArm) : Math.max(5, Math.round((cap - 15) * 10) / 10);
  const remembered = savedSale(row.ticker);
  const [pin, setPin] = useState<number | null>(remembered != null && remembered <= cap + 0.2 ? remembered : null);
  const [drag, setDrag] = useState<number | null>(null);
  const [showWhy, setShowWhy] = useState(false);
  const cashAt = (pct: number) => Math.round(Math.min(maxCash, row.cost * (1 + pct / 100)) * 100) / 100;
  const arm = (pct: number) => {
    const n = Math.max(5, Math.min(cap, Math.round(pct * 10) / 10));
    setPin(n);
    setDrag(null);
    keepSale(row.ticker, n);
    void setPinSale({ data: { ticker: row.ticker, ask: cashAt(n), pct: n } });
  };
  const armCash = (dollars: number) => {
    if (!(row.cost > 0)) return;
    const ask = Math.round(Math.min(maxCash, Math.max(row.cost, dollars)) * 100) / 100;
    arm(((ask - row.cost) / row.cost) * 100);
  };
  // Claude (4:30 AM): the slider no longer arms itself on every new order. An auto-set slider
  // overrode her take profit (no 1% trail, no gates, no "reason" rules). Now the slider only acts
  // when Love moves it; otherwise the desk's take profit + trail + gates run the exit.
  const pill =
    "inline-flex h-7 shrink-0 items-center justify-center rounded-md border border-white bg-black px-2 font-sans text-[10px] leading-none tracking-[0.06em] text-white";
  const pctPill =
    "inline-flex h-5 min-w-11 shrink-0 items-center justify-center rounded-md border border-white bg-black px-2.5 font-sans text-[10px] leading-none tracking-[0.04em] text-white";
  return (
    <li className="mt-2 border-t-[0.5px] border-white pt-1 first:mt-0 first:border-t-0 first:pt-0">
      <div className="flex items-baseline justify-between gap-3">
        <p className="min-w-0 font-sans text-[15px] tracking-wide text-white">
          {row.name}
          <span className="px-1.5 text-white/40">•</span>
          {row.side.toUpperCase()}
          <span className="px-1.5 text-white/40">•</span>
          <span className="tabular-nums">{countdown(left)}</span>
        </p>
        <p className="shrink-0 text-right font-sans text-[12px] tabular-nums leading-none text-white">
          {row.stale ? <span className="mr-2 rounded-full border border-[#e7c56a] px-1.5 py-0.5 text-[9px] tracking-[0.18em] text-[#e7c56a]">STALE QUOTE</span> : null}
          MAX ${usd(maxCash, 2)}
          <span className="px-2 text-white/40">•</span>
          {mult > 0 ? `${mult.toFixed(2)}x` : "—"}
        </p>
      </div>
      <p className="mt-1.5 text-right font-sans text-[22px] font-medium leading-none tabular-nums">
        <span className="text-white">{livePct > 0.5 ? "+" : livePct < -0.5 ? "−" : ""}</span>
        <RollDigits className={tone} text={`${Math.abs(livePct).toFixed(1)}%`} />
        <span className="mx-4 text-white/30">•</span>
        <span className="text-white">$</span>
        <RollDigits className={tone} text={cash.toFixed(2)} />
      </p>
      <p className="mt-1 font-sans text-[22px] font-medium tabular-nums leading-none text-white">
        {spot > 0 ? <>$<RollDigits text={usd(spot, 2)} /></> : "—"}
      </p>
      <p className="mt-1 font-sans text-[11px] tabular-nums text-white/80">
        Target {row.target != null && strike > 0 ? `$${usd(strike, 2)}` : "—"}
      </p>
      <input
        type="range"
        min={Math.round(row.cost * 100) / 100}
        max={maxCash}
        step={0.01}
        value={drag ?? (pin != null ? cashAt(pin) : cashAt(Math.min(gatePct, cap)))}
        onInput={(e) => setDrag(Number(e.currentTarget.value))}
        onChange={(e) => setDrag(Number(e.currentTarget.value))}
        onPointerUp={(e) => armCash(drag ?? Number(e.currentTarget.value))}
        onKeyUp={() => {
          if (drag != null) armCash(drag);
        }}
        aria-label="Sell at this Kalshi price"
        className="glass-range mt-1.5 w-full cursor-pointer"
        style={{ touchAction: "none" }}
      />
      <div className="mt-1.5 flex flex-wrap items-center gap-2">
        <button
          type="button"
          className={pill}
          onClick={() => {
            void halfNow({ data: { ticker: row.ticker } }).then((res) => {
              toast(res ? `Half banked $${res.payout.toFixed(2)}.` : "Half didn't fill.");
              onRefresh();
            });
          }}
        >
          HALF{halfRoll > 0 ? ` $${halfRoll >= 20 ? halfRoll.toFixed(0) : halfRoll.toFixed(1)}` : ""}
        </button>
        <button
          type="button"
          className={pill}
          onClick={() => {
            void fastClose(row.ticker, performance.timeOrigin + (((window as any).event?.timeStamp as number | undefined) ?? performance.now())).then((res) => {
              toast(res.line);
              onRefresh();
            }).catch(() => toast("Close didn't send. Press it again."));
          }}
        >
          CLOSE{cashRoll > 0 ? ` $${cashRoll >= 20 ? cashRoll.toFixed(0) : cashRoll.toFixed(1)}` : ""}
        </button>
        <label className={pill}>
          SIZE
          <input
            inputMode="decimal"
            defaultValue={String(Math.max(1, Math.round(row.cost)))}
            onBlur={(e) => {
              const n = Math.max(1, Math.min(100, Math.round(Number(e.target.value) || row.cost)));
              e.target.value = String(n);
              if (n >= row.cost - 0.5) return;
              void trimNow({ data: { ticker: row.ticker, dollars: n } }).then((res) => {
                toast(res ? `Size left at $${res.left.toFixed(0)}.` : "Size didn't change.");
                onRefresh();
              });
            }}
            className="w-5 bg-transparent text-center font-sans text-[10px] text-white outline-none"
          />
        </label>
        <span className="ml-auto font-sans text-[10px] tracking-[0.08em] text-white/70">
          {drag != null
            ? `SELL AT $${drag.toFixed(2)} · +${row.cost > 0 ? (((drag - row.cost) / row.cost) * 100).toFixed(1) : "0"}%`
            : pin != null
              ? `SELL AT $${cashAt(pin).toFixed(2)} · +${Math.round(pin)}%`
              : gatePct <= cap
                ? `TAKE PROFIT $${cashAt(gatePct).toFixed(2)} · +${Math.round(gatePct)}% · RIDES 1% TRAIL`
                : "HOLD TO THE BELL"}
        </span>
      </div>
      <div className="mt-1.5 flex flex-wrap items-center justify-end gap-1.5">
        <button type="button" onClick={() => setShowWhy((on) => !on)} className={cn(pctPill, showWhy ? "bg-white/10" : "")}>
          WHY
        </button>
        {SALE_PCTS.map((pct) => (
          <button
            key={pct}
            type="button"
            disabled={pct > cap}
            onClick={() => arm(pct)}
            className={cn(pctPill, pin === pct ? "bg-white text-black" : "", pct > cap ? "opacity-30" : "")}
          >
            {pct}%
          </button>
        ))}
      </div>
      {showWhy ? <p className="mt-1.5 text-[12px] leading-snug text-white/80">{why}</p> : null}
    </li>
  );
}

function DockOrder({ row, onClose: onCloseNow, onPart: onPartNow }: { row: HeldOrder; onClose: () => void; onPart?: (pct: number) => void }) {
  // ONE TAP AGAIN (Love, Oct 5 ~1:30 PM PT: "the close button doesn't work... it blocks it with a label and makes me click
  // again"). The two-tap rule (Oct 4, after a slider touch landed on the flush 75% button) is gone. What it guarded against
  // is guarded directly now: a sell button ignores any tap that comes within 0.8 s of touching the slider, and the buttons
  // sit a little further from the slider. A real tap sells on the first touch.
  const slideAt = useRef(0);
  // 350 ms, was 800 (Oct 15, Love: "it doesn't even register sometimes"): the slider guard ate real clicks in silence.
  const fromSlider = () => Date.now() - slideAt.current < 350;
  // TWO TAPS, NO LABEL (Love, Oct 5 ~1:40 PM PT: "i like the tap again concept. But the label was blocking it"). First tap
  // arms the button (it reads AGAIN for 3 s), the second tap sells. No pop-up toast over the buttons anymore.
  const [armedSell, setArmedSell] = useState<string | null>(null);
  const armedAt = useRef(0);
  const twoTap = (key: string, go: () => void) => {
    if (fromSlider()) return;
    if (armedSell === key && Date.now() - armedAt.current < 3000) {
      setArmedSell(null);
      go();
      return;
    }
    armedAt.current = Date.now();
    setArmedSell(key);
    setTimeout(() => setArmedSell((cur) => (cur === key ? null : cur)), 3000);
  };
  // ONE TAP (Love, Oct 5 ~11:15 PM PT: "can we take the two clicks off the boxes to close? its being troublesome"). The
  // slider guard stays (a tap within 0.8 s of touching the slider is ignored).
  void twoTap;
  const onPart = (pct: number) => {
    if (fromSlider()) { toast("Finger was on the slider - tap once more."); return; }
    onPartNow?.(pct);
  };
  const onClose = () => {
    if (fromSlider()) { toast("Finger was on the slider - tap once more."); return; }
    onCloseNow();
  };
  const cash = row.value > 0 ? row.value : row.cost;
  const roll = useRollingPrice(cash);
  const livePct = row.cost > 0 ? ((cash - row.cost) / row.cost) * 100 : 0;
  // A quote that didn't come back (or is 15 s+ old) no longer paints a stale red/green: it goes grey with "SYNCING".
  const old = Boolean(row.stale) || (row.at ? Date.now() - Date.parse(row.at) > 15000 : false);
  const tone = old ? "text-white/50" : livePct > 0.5 ? "text-up" : livePct < -0.5 ? "text-down" : "text-white";
  const maxCash = Math.round(row.contracts * 100) / 100;
  const mult = row.cost > 0 ? maxCash / row.cost : 0;
  // SLIM DOCK (Love, Oct 3 ~5:30 PM PT: "more compact rectangles and less squares... the whole box a bit more compact,
  // slimmer... remove the slide to set a scale"). The sell-at slider lives on the big card now; the dock keeps the
  // quick sells plus one small line with the stake, multiple and max. Buttons draw their own even 1px outline (no glow,
  // no half-pixel offsets) so the top never reads brighter than the sides.
  const btn = { border: "1px solid rgba(255,255,255,0.78)", boxShadow: "none" };
  // SELL-AT SLIDER, back in the dock (Love, Oct 3 ~7 PM PT: "just a slider with the percentage and dollar amount...
  // matched to kalshi's numbers"). It moves in whole cents like Kalshi's own sell ticket: the price per contract, the %
  // that price is on your cost, and the dollars it pays (contracts x price, before Kalshi's fee).
  const entryC = row.contracts > 0 ? (row.cost / row.contracts) * 100 : 0;
  const minC = Math.min(99, Math.floor(entryC) + 1);
  const pctAtC = (c: number) => (row.cost > 0 ? ((row.contracts * c) / 100 / row.cost - 1) * 100 : 0);
  const cashAtC = (c: number) => Math.round(row.contracts * c) / 100;
  const cFromPct = (pct: number) => Math.max(minC, Math.min(99, Math.round(entryC * (1 + pct / 100))));
  const remembered = savedSale(row.ticker);
  const [pinC, setPinC] = useState<number | null>(remembered != null && remembered > 0 ? cFromPct(remembered) : null);
  const [dragC, setDragC] = useState<number | null>(null);
  const shownC = dragC ?? pinC;
  const nowC = Math.max(minC, Math.min(99, Math.round(row.contracts > 0 ? (cash / row.contracts) * 100 : minC)));
  const armC = (c: number) => {
    const cc = Math.max(minC, Math.min(99, Math.round(c)));
    const pct = Math.round(pctAtC(cc) * 10) / 10;
    setPinC(cc);
    setDragC(null);
    keepSale(row.ticker, pct);
    void setPinSale({ data: { ticker: row.ticker, ask: cashAtC(cc), pct } });
    toast(`Sells at ${cc}¢ · +${pct}% · $${cashAtC(cc).toFixed(2)}.`);
  };
  const canSlide = entryC > 0 && minC < 99;
  // DOCK LAYOUT (Love, Oct 3 ~6:55 PM PT: "numbers above the slider, not under the percentage boxes... boxes sit flush on
  // the floor... slider a lil less long so they can sit next to each other"). Top: the position line + IN/x/MAX.
  // Bottom row, on the floor: the sale numbers stacked over a shorter slider, then the 25/50/75/100 boxes beside it.
  return (
    <div className="border-t border-white/25 pt-1 first:border-t-0">
      <p className="truncate font-sans text-[12px] leading-[14px] tabular-nums text-white">
        {row.name}
        <span className="px-1 text-white/40">•</span>
        {row.side.toUpperCase()}
        <span className="px-1 text-white/40">•</span>
        <span className={tone}>
          {livePct > 0.5 ? "+" : livePct < -0.5 ? "−" : ""}
          {Math.abs(Math.round(livePct))}%
        </span>
        <span className="px-1 text-white/40">•</span>
        <span className={tone}>${roll >= 20 ? roll.toFixed(0) : roll.toFixed(2)}</span>
        {old ? <span className="pl-1 font-mono text-[9px] text-white/50">SYNCING</span> : null}
      </p>
      <p className="truncate font-mono text-[9px] leading-[11px] tabular-nums text-white/60">
        IN ${row.cost.toFixed(2)} · {mult > 0 ? `${mult.toFixed(2)}x` : "—"} · MAX ${maxCash.toFixed(2)}
        {/* TARGET ON THE DOCK (Oct 24 ~11:55 PM PT, Love: "could you add in the target price for the orders at the lil back label with the percentage close buttons") */}
        {row.target != null && row.target > 0 ? ` · TARGET $${usd(row.target, 2)}` : ""}
      </p>
      <div className="mt-1 flex items-end gap-1.5">
        <div className="mr-1.5 min-w-0 flex-1">
          {canSlide ? (
            <>
              <p className="truncate font-mono text-[10px] leading-[12px] tabular-nums text-white">
                {shownC != null ? (
                  <>
                    <span className="text-white/60">SELL </span>
                    {shownC}¢ · <span className="text-up">+{pctAtC(shownC).toFixed(1)}%</span> · ${cashAtC(shownC).toFixed(2)}
                  </>
                ) : (
                  <span className="text-white/60">SLIDE TO SET A SALE</span>
                )}
              </p>
              <input
                type="range"
                min={minC}
                max={99}
                step={1}
                value={shownC ?? nowC}
                onPointerDown={() => {
                  slideAt.current = Date.now();
                }}
                onInput={(e) => {
                  slideAt.current = Date.now();
                  setDragC(Number(e.currentTarget.value));
                }}
                onChange={(e) => setDragC(Number(e.currentTarget.value))}
                onPointerUp={(e) => {
                  slideAt.current = Date.now();
                  armC(dragC ?? Number(e.currentTarget.value));
                }}
                onKeyUp={() => {
                  if (dragC != null) armC(dragC);
                }}
                aria-label="Sell at this price"
                className="glass-range mt-0.5 block h-4 w-full cursor-pointer"
                style={{ touchAction: "none" }}
              />
            </>
          ) : null}
        </div>
        {/* Love, Oct 3: sell a share right from the dock, no tab switching. 100% = CLOSE. */}
        {[25, 50, 75].map((p) => (
          <button key={p} type="button" style={btn} className="h-7 w-[44px] shrink-0 rounded-[5px] bg-black font-mono text-[10px] leading-none text-white" onClick={() => onPart(p)}>
            {armedSell === String(p) ? "AGAIN" : `${p}%`}
          </button>
        ))}
        <button type="button" style={btn} className="h-7 w-[48px] shrink-0 rounded-[5px] bg-black font-mono text-[10px] leading-none text-white" onClick={onClose}>
          {armedSell === "close" ? "AGAIN" : "100%"}
        </button>
      </div>
    </div>
  );
}

function WatchingCards({ note }: { note?: Record<string, string> }) {
  return (
    <section className="rounded-md border border-white bg-black px-4 py-4 text-white">
      <p className="text-[10px] tracking-[0.22em] text-white/70">WATCHING</p>
      <p className="mt-2 text-xs leading-snug text-white/70">Prime book only. No chart. This is what it sees right now.</p>
      <ul className="mt-3 space-y-2">
        {(["btc", "gold", "silver"] as const).map((id) => (
          <li key={id} className="rounded-md border border-white bg-black px-4 py-2.5">
            <p className="text-sm text-white">{id.toUpperCase()}</p>
            <p className="mt-1 whitespace-pre-line text-xs leading-snug text-white/80">{note?.[id] || "looking"}</p>
          </li>
        ))}
      </ul>
    </section>
  );
}

function DeskTab({
  active,
  label,
  onClick,
}: {
  active: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      data-active={active ? "true" : "false"}
      className={cn(
        "desk-tab-glow shrink-0 rounded-[6px] border-[0.5px] px-2.5 py-1 text-center text-[10px] leading-none tracking-[0.12em]",
        active ? "text-fg" : "text-muted",
      )}
    >
      {label}
    </button>
  );
}

class QuietChart extends Component<{ children: ReactNode }, { bad: boolean }> {
  state = { bad: false };
  static getDerivedStateFromError() {
    return { bad: true };
  }
  render() {
    if (this.state.bad) return <p className="text-sm text-subtle">The chart is off so the book can stay open.</p>;
    return this.props.children;
  }
}

function MirrorSheet({ rows }: { rows: { id: string; asset: string; side: string; pattern: string; kind: string; result: string }[] }) {
  const names = ["btc", "gold", "silver", "platinum", "palladium"] as const;
  const label: Record<string, string> = {
    btc: "BITCOIN",
    gold: "GOLD",
    silver: "SILVER",
    platinum: "PLATINUM",
    palladium: "PALLADIUM",
  };
  const groups = names.map((id) => {
    const mine = rows.filter((row) => row.asset === id && (row.result === "yes" || row.result === "no"));
    const tally = new Map<string, { pattern: string; primeYes: number; primeNo: number; otherYes: number; otherNo: number }>();
    for (const row of mine) {
      const cur = tally.get(row.pattern) || { pattern: row.pattern, primeYes: 0, primeNo: 0, otherYes: 0, otherNo: 0 };
      const other = row.kind === "other-way" || row.kind === "mirror";
      if (row.result === "yes") other ? (cur.otherYes += 1) : (cur.primeYes += 1);
      else other ? (cur.otherNo += 1) : (cur.primeNo += 1);
      tally.set(row.pattern, cur);
    }
    return { id, open: rows.filter((row) => row.asset === id && row.result === "open").length, scores: [...tally.values()] };
  }).filter((group) => group.open || group.scores.length);
  return (
    <section className="rounded-md border border-white bg-black px-4 py-4 text-white">
      <p className="text-[10px] tracking-[0.22em] text-white/70">MIRROR SHEET</p>
      <p className="mt-2 text-xs leading-snug text-white/70">
        Score only. Not a book. Nothing here can send an order. Each prime setup is written down, and so is the other direction, on bitcoin, gold, and silver. Platinum and palladium only score a band reject.
      </p>
      {groups.length === 0 ? (
        <p className="mt-4 text-sm text-white/70">Nothing scored yet.</p>
      ) : (
        <ul className="mt-4 space-y-4">
          {groups.map((group) => (
            <li key={group.id}>
              <p className="text-[10px] tracking-[0.18em] text-white/70">{label[group.id]}{group.open ? ` · ${group.open} open` : ""}</p>
              <ul className="mt-1 space-y-2">
                {group.scores.map((row) => (
                  <li key={row.pattern} className="border-t border-white/20 pt-2">
                    <p className="text-sm text-white">{row.pattern}</p>
                    <p className="mt-1 font-mono text-[11px] text-white/80">
                      <span className="text-white/50">her way </span>
                      <span className="text-up">{row.primeYes}</span>
                      <span className="text-white/40">-</span>
                      <span className="text-down">{row.primeNo}</span>
                      <span className="text-white/50"> · other way </span>
                      <span className="text-up">{row.otherYes}</span>
                      <span className="text-white/40">-</span>
                      <span className="text-down">{row.otherNo}</span>
                    </p>
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function BookRoll({
  rows,
}: {
  rows: { asset: string; side: string; setup: string; yes: number; no: number; net: number }[];
}) {
  const [which, setWhich] = useState<"all" | "prime" | "paper">("all");
  const [sort, setSort] = useState<"paying" | "hitting" | "success">("hitting");
  const grouped = useMemo(() => {
    const prime = rows.filter((row) => row.yes >= 2 && row.yes > row.no);
    const primeKeys = new Set(prime.map((row) => `${row.asset}|${row.side}|${row.setup}`));
    const paper = rows.filter((row) => !primeKeys.has(`${row.asset}|${row.side}|${row.setup}`));
    return { all: rows, prime, paper };
  }, [rows]);
  const shown = useMemo(() => {
    const list = grouped[which];
    const hit = (row: { yes: number; no: number }) => {
      const n = row.yes + row.no;
      return n ? row.yes / n : 0;
    };
    return [...list].sort((a, b) => {
      if (sort === "paying") return b.net - a.net || hit(b) - hit(a);
      if (sort === "hitting") return hit(b) - hit(a) || b.yes - a.yes;
      return b.yes - b.no - (a.yes - a.no) || hit(b) - hit(a);
    });
  }, [grouped, which, sort]);
  const totals = useMemo(() => {
    const list = grouped[which];
    const yes = list.reduce((sum, row) => sum + row.yes, 0);
    const no = list.reduce((sum, row) => sum + row.no, 0);
    return { yes, no, hit: yes + no ? Math.round((100 * yes) / (yes + no)) : 0 };
  }, [grouped, which]);
  const pill = (on: boolean) => cn("desk-pill h-6 px-2", on ? "text-fg" : "text-white/45");
  return (
    <section className="px-3 pb-8">
      <div className="flex flex-wrap gap-1">
        <button type="button" className={pill(which === "all")} onClick={() => setWhich("all")}>ALL</button>
        <button type="button" className={pill(which === "prime")} onClick={() => setWhich("prime")}>PRIME</button>
        <button type="button" className={pill(which === "paper")} onClick={() => setWhich("paper")}>PAPER</button>
      </div>
      <div className="mt-2 flex flex-wrap gap-1">
        <button type="button" className={pill(sort === "paying")} onClick={() => setSort("paying")}>HIGHEST PAYING</button>
        <button type="button" className={pill(sort === "hitting")} onClick={() => setSort("hitting")}>HIGHEST HITTING</button>
        <button type="button" className={pill(sort === "success")} onClick={() => setSort("success")}>MOST SUCCESSFUL</button>
      </div>
      <p className="mt-3 text-[12px] text-white/60">
        {shown.length} setups · {totals.yes}-{totals.no} · {totals.hit}%
        {" · "}
        <a className="underline" href="/aurelius-source.zip" download="aurelius-source.zip">app source</a>
      </p>
      <div className="mt-3">
        <table className="w-full text-left text-[12px]">
          <thead>
            <tr className="text-[10px] tracking-[0.14em] text-white/45">
              <th className="pb-2 pr-2 font-medium">SETUP</th>
              <th className="pb-2 pr-2 text-right font-medium">YES-NO</th>
              <th className="pb-2 pr-2 text-right font-medium">HIT</th>
              <th className="pb-2 text-right font-medium">$</th>
            </tr>
          </thead>
          <tbody>
            {shown.map((row) => {
              const n = row.yes + row.no;
              const rate = n ? Math.round((100 * row.yes) / n) : 0;
              return (
                <tr key={`${row.asset}-${row.side}-${row.setup}`} className="border-t border-white/10">
                  <td className="max-w-[14rem] py-2 pr-2">
                    <p className="truncate">{row.setup}</p>
                    <p className="text-[10px] uppercase tracking-wider text-white/40">{row.asset} {row.side}</p>
                  </td>
                  <td className="py-2 pr-2 text-right font-mono tabular-nums">{row.yes}-{row.no}</td>
                  <td className="py-2 pr-2 text-right font-mono tabular-nums">{rate}%</td>
                  <td className={`py-2 text-right font-mono tabular-nums ${row.net < 0 ? "text-down" : "text-up"}`}>{row.net.toFixed(2)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function spanLine(rows: { at: string; win: boolean }[], hours: number) {
  const ms = hours ? hours * 3600e3 : 0;
  let hit = 0;
  let lost = 0;
  for (const row of rows) {
    if (ms) {
      const t = Date.parse(row.at);
      if (!Number.isFinite(t) || Date.now() - t > ms) continue;
    }
    if (row.win) hit += 1;
    else lost += 1;
  }
  const n = hit + lost;
  return n ? `${Math.round((hit / n) * 100)}%  ${hit}-${lost}` : "—";
}

function ModeSwitch({
  live,
  paper,
  prime,
  onSubmit,
}: {
  live: "paper" | "prime" | "both";
  paper: { at: string; kind: string; venue: string; profit: number | null; ticker?: string; id?: string }[];
  prime: { at: string; result: string; ticker?: string; id: string }[];
  onSubmit: (only: "paper" | "prime" | "both") => void;
}) {
  const [pick, setPick] = useState<"paper" | "prime" | "both">(live);
  useEffect(() => setPick(live), [live]);
  const rates = useMemo(() => {
    const paperBook = new Map<string, { at: string; win: boolean }>();
    for (const row of paper) {
      if (row.kind !== "banked" || row.venue !== "paper" || row.profit == null) continue;
      const key = row.ticker || row.id || row.at;
      const prev = paperBook.get(key);
      if (!prev || row.at > prev.at) paperBook.set(key, { at: row.at, win: row.profit > 0 });
    }
    const primeBook = prime
      .filter((row) => row.result === "yes" || row.result === "no")
      .map((row) => ({ key: row.ticker || row.id, at: row.at, win: row.result === "yes" }));
    const both = new Map<string, { at: string; win: boolean }>(paperBook);
    for (const row of primeBook) {
      if (!both.has(row.key)) both.set(row.key, { at: row.at, win: row.win });
    }
    const pack = (rows: { at: string; win: boolean }[]) => ({
      h12: spanLine(rows, 12),
      h24: spanLine(rows, 24),
      all: spanLine(rows, 0),
    });
    return {
      paper: pack([...paperBook.values()]),
      prime: pack(primeBook),
      both: pack([...both.values()]),
    };
  }, [paper, prime]);
  const lines = [
    ["PAPER", rates.paper],
    ["PRIME", rates.prime],
    ["BOTH", rates.both],
  ] as const;
  return (
    <section className="flex flex-col gap-4">
      <p className="text-[10px] tracking-[0.18em] text-subtle">TAP A BOOK. SUBMIT LOCKS IT.</p>
      <div className="flex gap-2">
        {(["paper", "prime", "both"] as const).map((key) => (
          <button
            key={key}
            type="button"
            onClick={() => setPick(key)}
            className={cn(
              "h-8 min-w-16 rounded-[3px] border-[0.5px] border-[#4a1020] px-3 text-[10px] tracking-[0.14em]",
              pick === key
                ? "translate-y-px bg-black text-fg shadow-[inset_0_2px_6px_rgba(0,0,0,0.95),inset_0_1px_0_rgba(255,255,255,0.14)]"
                : "bg-transparent text-muted shadow-[0_1px_0_rgba(255,255,255,0.2)]",
            )}
          >
            {key === "both" ? "BOTH" : key.toUpperCase()}
          </button>
        ))}
      </div>
      <button
        type="button"
        onClick={() => onSubmit(pick)}
        className="h-8 w-fit rounded-[3px] border-[0.5px] border-white/70 px-4 text-[10px] tracking-[0.16em] text-fg"
      >
        SUBMIT
      </button>
      <p className="text-sm text-muted">{pick === live ? `Live on ${live}.` : `${live} is live. Submit to switch to ${pick}.`}</p>
      <div className="grid grid-cols-4 gap-y-2 font-mono text-[11px] tabular-nums text-fg">
        <span />
        <span className="text-right text-[10px] tracking-[0.14em] text-subtle">12H</span>
        <span className="text-right text-[10px] tracking-[0.14em] text-subtle">24H</span>
        <span className="text-right text-[10px] tracking-[0.14em] text-subtle">ALL</span>
        {lines.map(([name, row]) => (
          <span key={name} className="contents">
            <span className="text-[10px] tracking-[0.14em] text-subtle">{name}</span>
            <span className="text-right">{row.h12}</span>
            <span className="text-right">{row.h24}</span>
            <span className="text-right">{row.all}</span>
          </span>
        ))}
      </div>
    </section>
  );
}

export function DeskApp() {
  const [bookTab, setBookTab] = useState<"mode" | "shift" | "paper" | "prime" | "lead" | "open" | "watch" | "lean" | "fuel" | "symbols" | "mirror" | "markets" | "kalshi" | "poly" | "cash" | "stats" | "scale" | "hedge" | "log" | "audit" | "look" | "outside" | "notes" | "pnl" | "day" | "alerts" | "sitrep" | "books" | "traj" | "scanner" | "positions" | "scope">("kalshi");
  const [span, setSpan] = useState<"12" | "24" | "all">("24");
  const [deskNote, setDeskNote] = useState("");
  const [cashVenue, setCashVenue] = useState<CashVenue>("kalshi");
  const [look, setLook] = useState<Look>(LOOK_DEFAULT);
  const hydrated = useHydrated();
  useEffect(() => setLook(loadLook()), []);
  useEffect(() => {
    try {
      sessionStorage.removeItem("aurelius-stall-reload");
    } catch {
      // a private browser can skip this
    }
  }, []);
  const foreground = useForeground();
  const settings = useDesk((s) => s.settings);
  const setSettings = useDesk((s) => s.setSettings);
  const trades = useDesk((s) => s.trades);
  const grokBySetup = useDesk((s) => s.grokBySetup);
  const acted = useDesk((s) => s.acted);
  const rememberGrok = useDesk((s) => s.rememberGrok);
  const openPaper = useDesk((s) => s.openPaper);
  const patchTrade = useDesk((s) => s.patchTrade);
  const closeTrade = useDesk((s) => s.closeTrade);
  const adoptBook = useDesk((s) => s.adoptBook);

  useWakeLock(hydrated && settings.autoPaper && foreground);

  const settingsRef = useRef(settings);
  settingsRef.current = settings;

  const q = useQuery({
    queryKey: ["desk"],
    queryFn: () => getDeskSnapshot({ data: { settings: settingsRef.current } }),
    refetchInterval: foreground ? (bookTab === "open" || bookTab === "kalshi" || bookTab === "prime" ? 4000 : 12000) : 20000,
    refetchOnWindowFocus: false,
    staleTime: 3500,
    placeholderData: (prev) => prev,
  });

  const bookMode = useQuery({
    queryKey: ["book-mode"],
    queryFn: () => getBookMode(),
    refetchInterval: foreground ? 8000 : false,
  });

  const book = useQuery({
    queryKey: ["book"],
    queryFn: () => pullBook(),
    refetchInterval: foreground ? 30000 : false, // Oct 14 (lighter page): was 12 s, every tab, even in the background
    refetchOnWindowFocus: false,
    staleTime: 4000,
  });

  // CLOSE BUTTONS (Oct 16 ~1:45 PM PT): the book pulled from the server was pushed straight back (1 MB each way every 30 s).
  const adoptedRef = useRef<unknown>(null);
  useEffect(() => {
    if (!hydrated || !book.data) return;
    adoptBook(book.data);
    adoptedRef.current = useDesk.getState().trades;
  }, [book.data, hydrated, adoptBook]);

  useEffect(() => {
    if (!hydrated) return;
    if (trades === adoptedRef.current) return;
    const timer = window.setTimeout(() => {
      void pushBook({ data: { trades, settings } });
    }, 400);
    return () => window.clearTimeout(timer);
  }, [trades, settings, hydrated]);

  const sizeTouched = useRef(false);
  useEffect(() => {
    if (!hydrated) return;
    void getLiveSize().then((row) => {
      if (sizeTouched.current || !(row.dollars >= 1)) return;
      setSettings({ liveStake: row.dollars });
    });
  }, [hydrated, setSettings]);

  const spots = useQuery({
    queryKey: ["spots"],
    queryFn: () => getLiveSpots(),
    // The live tapes (MARKETS, and OPEN NOW on SHIFT) glide between quotes; fresher quotes = livelier tape (Oct 4).
    refetchInterval: foreground ? (bookTab === "shift" || bookTab === "markets" ? 2000 : 8000) : 12000,
    refetchOnWindowFocus: false,
    staleTime: 400,
  });
  const alts = useQuery({
    queryKey: ["alt-boards"],
    queryFn: () => getAltBoards(),
    enabled: hydrated && bookTab === "markets",
    refetchInterval: foreground ? 20000 : false,
  });
  const fillLog = useQuery({
    queryKey: ["fill-log"],
    queryFn: () => getFillLog(),
    enabled: hydrated,
    refetchInterval: foreground ? 20000 : false,
    refetchOnWindowFocus: false,
  });
  const exitLog = useQuery({
    queryKey: ["exit-log"],
    queryFn: () => getExitLog(),
    enabled: hydrated,
    refetchInterval: foreground ? 20000 : false,
    refetchOnWindowFocus: false,
  });
  const primeScore = useQuery({
    queryKey: ["prime-score"],
    queryFn: () => getPrimeScore(),
    enabled: hydrated && (bookTab === "paper" || bookTab === "prime" || bookTab === "lead" || bookTab === "open"),
    refetchInterval: foreground && (bookTab === "paper" || bookTab === "prime" || bookTab === "lead" || bookTab === "open") ? (bookTab === "open" ? 4000 : 12000) : false,
    refetchOnWindowFocus: false,
  });
  const primeRows = useQuery({
    queryKey: ["prime-rows"],
    queryFn: () => getPrimeRows(),
    enabled: hydrated && (bookTab === "prime" || bookTab === "lead" || bookTab === "open" || bookTab === "books" || bookTab === "mode"),
    refetchInterval: foreground && (bookTab === "prime" || bookTab === "lead" || bookTab === "open" || bookTab === "mode") ? 12000 : false,
    refetchOnWindowFocus: false,
  });
  const setupBoard = useQuery({
    queryKey: ["setup-board"],
    queryFn: () => getSetupBoard(),
    enabled: hydrated && bookTab === "books",
    refetchOnWindowFocus: false,
  });
  const comboRows = useQuery({
    queryKey: ["combo-rows"],
    queryFn: () => getComboRows(),
    enabled: hydrated && (bookTab === "paper" || bookTab === "prime"),
    refetchInterval: foreground && (bookTab === "paper" || bookTab === "prime") ? 8000 : false,
    refetchOnWindowFocus: false,
  });
  const halfRows = useQuery({
    queryKey: ["half-rows"],
    queryFn: () => getHalfRows(),
    enabled: hydrated && bookTab === "prime",
    refetchInterval: foreground && bookTab === "prime" ? 12000 : false,
    refetchOnWindowFocus: false,
  });
  const decidedRows = useQuery({
    queryKey: ["decided-rows"],
    queryFn: () => getDecidedRows(),
    enabled: hydrated && (bookTab === "prime" || bookTab === "lead"),
    refetchInterval: foreground && (bookTab === "prime" || bookTab === "lead") ? 12000 : false,
    refetchOnWindowFocus: false,
  });
  const primeWatch = useQuery({
    queryKey: ["prime-watch"],
    queryFn: () => getPrimeWatch(),
    enabled: hydrated && (bookTab === "watch" || bookTab === "prime" || bookTab === "lead" || bookTab === "open"),
    refetchInterval: foreground && (bookTab === "watch" || bookTab === "prime" || bookTab === "lead" || bookTab === "open") ? 12000 : false,
    refetchOnWindowFocus: false,
  });
  const leanRows = useQuery({
    queryKey: ["lean-rows"],
    queryFn: () => getLeanRows(),
    enabled: hydrated && bookTab === "lean",
    refetchInterval: foreground && bookTab === "lean" ? 12000 : false,
    refetchOnWindowFocus: false,
  });
  const fuelRows = useQuery({
    queryKey: ["fuel-rows"],
    queryFn: () => getFuelRows(),
    enabled: hydrated && bookTab === "fuel",
    refetchInterval: foreground && bookTab === "fuel" ? 12000 : false,
    refetchOnWindowFocus: false,
  });
  const symbolLab = useQuery({
    queryKey: ["symbol-lab"],
    queryFn: () => getSymbolLab(),
    enabled: hydrated && bookTab === "symbols",
    refetchInterval: foreground && bookTab === "symbols" ? 12000 : false,
    refetchOnWindowFocus: false,
  });
  const mirrorSheet = useQuery({
    queryKey: ["mirror-sheet"],
    queryFn: () => getMirrorSheet(),
    enabled: hydrated && bookTab === "mirror",
    refetchInterval: foreground && bookTab === "mirror" ? 12000 : false,
    refetchOnWindowFocus: false,
  });
  const poly = useQuery({
    queryKey: ["poly-ledger"],
    queryFn: () => getPolyLedger(),
    enabled: hydrated,
    refetchInterval: foreground ? 30000 : false, // Oct 14 (lighter page): Polymarket isn't trading; was every 8 s
    refetchOnWindowFocus: false,
  });
  const kalshiCash = useQuery({
    queryKey: ["kalshi-cash"],
    queryFn: () => getKalshiCash(),
    enabled: hydrated,
    refetchInterval: foreground ? 15000 : false, // Oct 14 (lighter page): was every 8 s, even in the background
    refetchOnWindowFocus: false,
  });
  const prime = useQuery({
    queryKey: ["prime-book"],
    queryFn: () => getPrimeBook(),
    enabled: hydrated,
    refetchInterval: foreground ? 20000 : false,
    refetchOnWindowFocus: false,
  });
  const audit = useQuery({
    queryKey: ["audit"],
    queryFn: () => getAudit(),
    enabled: hydrated,
    refetchInterval: foreground ? 20000 : false,
    refetchOnWindowFocus: false,
  });
  const outside = useQuery({
    queryKey: ["outside"],
    queryFn: () => getOutside(),
    enabled: hydrated,
    refetchInterval: foreground ? 20000 : false,
    refetchOnWindowFocus: false,
  });
  const watch = useQuery({
    queryKey: ["watch"],
    queryFn: () => getWatch(),
    enabled: hydrated,
    refetchInterval: foreground ? 15000 : false,
    refetchOnWindowFocus: false,
  });
  const trailQ = useQuery({
    queryKey: ["trail"],
    queryFn: () => getTrail(),
    enabled: hydrated,
    refetchInterval: 20000,
    refetchOnWindowFocus: false,
  });
  const rulesQ = useQuery({
    queryKey: ["desk-rules"],
    queryFn: () => getRules(),
    enabled: hydrated && bookTab === "shift",
    refetchInterval: 20000,
  });
  const recordsQ = useQuery({
    queryKey: ["prime-records"],
    queryFn: () => getPrimeRecords(),
    enabled: hydrated && bookTab === "prime",
    refetchInterval: 15000,
  });
  const monitorQ = useQuery({
    queryKey: ["claude-monitor"],
    queryFn: () => getMonitor(),
    enabled: hydrated && bookTab === "shift",
    refetchInterval: 15000,
  });
  const shadowQ = useQuery({
    queryKey: ["shadow-reject"],
    queryFn: () => getShadow(),
    enabled: hydrated && bookTab === "shift",
    refetchInterval: 15000,
  });
  const btQ = useQuery({
    queryKey: ["claude-backtest"],
    queryFn: () => getClaudeBacktest(),
    enabled: hydrated && bookTab === "shift",
    refetchInterval: 60000,
  });
  // TRAJECTORY (Love, Oct 4): every book's settled trades + LIVE from Kalshi's own fills, projected on the page.
  const trajQ = useQuery({
    queryKey: ["trajectory"],
    queryFn: () => getTrajectory(),
    enabled: hydrated && bookTab === "traj",
    refetchInterval: 60000,
  });
  // LIGHT SHIFT (Oct 17 ~6:30 PM PT, Love: "only pull up the trades for the cards i actually click on"): the page no longer
  // downloads every book's trades. The cards' numbers come counted from the desk (NightCard), a card's trades load when she
  // taps it, and this keeps only the few old live books the open-window lines read.
  const nightHeldQ = useQuery({
    queryKey: ["night-held"],
    queryFn: () => getShiftRows({ data: { books: ["brick", "cotc", "trend", "claude", "brickc", "sole5", "sole5v"] } }),
    enabled: hydrated && bookTab === "shift",
    refetchInterval: 30000,
    placeholderData: (prev) => prev,
  });
  const nightQ = { data: nightHeldQ.data as any[] | undefined };
  const truthQ = useQuery({
    queryKey: ["kalshi-truth"],
    queryFn: () => getTruth(),
    enabled: hydrated && bookTab === "shift",
    refetchInterval: 30000,
  });
  const lottoQ = useQuery({
    queryKey: ["lotto-lab"],
    queryFn: () => getLotto(),
    enabled: hydrated && bookTab === "shift",
    refetchInterval: 15000,
  });
  const liveQ = useQuery({
    queryKey: ["live-switch"],
    queryFn: () => getLiveSwitch(),
    enabled: hydrated,
    refetchInterval: 10000,
  });
  const scaleQ = useQuery({
    queryKey: ["scale75"],
    queryFn: () => getScale75(),
    enabled: hydrated,
    refetchInterval: 20000,
    refetchOnWindowFocus: false,
  });
  const [trail, setTrail] = useState(45);
  const trailDrag = useRef(false);
  useEffect(() => {
    if (trailDrag.current) return;
    const n = trailQ.data?.pct;
    if (typeof n === "number" && Number.isFinite(n)) setTrail(n);
  }, [trailQ.data?.pct]);
  useEffect(() => {
    if (!hydrated || trailDrag.current) return;
    void setTrailFloor({ data: { pct: settings.defaultExitPct } });
  }, [settings.defaultExitPct, hydrated]);
  const held = useQuery({
    queryKey: ["held-orders"],
    queryFn: () => getHeldOrders(),
    enabled: hydrated,
    // Love, Oct 3 ~6:25 PM PT: "the black box at the bottom doesn't refresh... said red when it was green". The dock
    // reads every 3 s on every tab now (and keeps reading in the background), not every 10 s.
    refetchInterval: foreground ? 3000 : 8000,
    refetchIntervalInBackground: true,
    refetchOnWindowFocus: true,
    placeholderData: (prev) => prev,
  });
  // DOCK THAT DOESN'T SHIFT (Oct 14 ~3:45 AM PT, Love: "i clicked again, it closed gold, moved btc in its place, and then
  // closed btc on the second click... stop them from flipping positions"). The dock keeps a fixed order (BTC, gold, then
  // the rest), a closed row holds its slot as "CLOSING…" for 3 s, and after any close / part-sell every dock button
  // ignores taps for 2.5 s, so a second tap can never land on the trade that slid into the gap.
  const [dockClosing, setDockClosing] = useState<Record<string, number>>({});
  const dockLock = useRef(0);
  // Oct 14 ~12:55 PM PT (Love: "put it back the way it was... click - close, not this extra window"): no CLOSING… placeholder
  // and no tap lock any more; a tap sends the close at once. The fixed BTC / gold / rest order stays.
  void dockLock; void setDockClosing;
  const dockTap = (_ticker: string, go: () => void) => {
    go();
  };
  const dockOrderKey = (t: string) => `${/BTC/.test(t) ? 0 : /GOLD/.test(t) ? 1 : /SILVER/.test(t) ? 2 : 3}:${t}`;
  const dockRows: (HeldOrder & { ghost?: boolean })[] = (() => {
    const live = (held.data ?? []) as (HeldOrder & { ghost?: boolean })[];
    return [...live].sort((a, b) => (dockOrderKey(a.ticker) < dockOrderKey(b.ticker) ? -1 : 1));
  })();

  const snap: DeskSnapshot | undefined = useMemo(
    () => overlayDesk(q.data, spots.data),
    [q.data, spots.data],
  );
  const cashView = useMemo(() => {
    const events = fillLog.data ?? [];
    const gaps = (venue: "paper" | "kalshi") => {
      const flags: string[] = [];
      const rows = events
        .filter((e) => e.kind === "banked" && e.venue === venue)
        .map((e) => {
          const book = trades.find((t) => t.id === e.tradeId);
          let flag: string | undefined;
          if (book && book.profit != null && e.profit != null && Math.abs(book.profit - e.profit) > 0.5) {
            flag = `book ${money(book.profit)} vs log ${money(e.profit)}`;
          }
          if (flag) flags.push(`${e.asset.toUpperCase()} ${e.side.toUpperCase()} · ${flag}`);
          return {
            id: e.id,
            at: e.at,
            label: `${e.asset.toUpperCase()} ${e.side.toUpperCase()}`,
            profit: e.profit,
            flag,
          };
        })
        .sort((a, b) => b.at.localeCompare(a.at));
      return { rows, flags };
    };
    if (cashVenue === "paper") {
      const { rows, flags } = gaps("paper");
      const ordered = [...rows].sort((a, b) => a.at.localeCompare(b.at));
      let run = 0;
      const trail = ordered.map((row) => {
        run += row.profit ?? 0;
        return { t: row.at, cash: Math.round(run * 100) / 100 };
      });
      return { cash: trail.length ? run : 0, anchor: 0, trail, rows, flags };
    }
    if (cashVenue === "kalshi") {
      const { rows, flags } = gaps("kalshi");
      for (const row of audit.data ?? []) {
        if (row.desk == null || Math.abs(row.desk - row.kalshi) <= 0.5) continue;
        flags.push(`${row.asset.toUpperCase()} ${row.side.toUpperCase()} · desk ${money(row.desk)} vs Kalshi ${money(row.kalshi)}`);
      }
      const book = kalshiCash.data;
      return {
        cash: book?.cash ?? snap?.kalshi?.cash ?? null,
        anchor: book?.anchor ?? null,
        trail: book?.trail ?? [],
        rows,
        flags,
      };
    }
    const book = poly.data;
    const flags: string[] = [];
    const rows = (book?.rows ?? []).map((row) => {
      let flag: string | undefined;
      if (row.status === "off" || row.status === "missing") flag = row.note || row.status;
      else if (row.expected != null && row.accountNet != null && Math.abs(row.expected - row.accountNet) > 0.5) {
        flag = `book ${money(row.expected)} vs account ${money(row.accountNet)}`;
      }
      if (flag) flags.push(`${row.side.toUpperCase()} · ${flag}`);
      return { id: row.orderId || row.slug, at: row.at, label: `${row.side.toUpperCase()} ${row.status}`, profit: row.accountNet, flag };
    });
    return {
      cash: book?.cash ?? null,
      anchor: book?.anchor ?? null,
      trail: book?.trail ?? [],
      rows,
      flags,
    };
  }, [audit.data, cashVenue, fillLog.data, kalshiCash.data, poly.data, snap?.kalshi?.cash, trades]);
  const [grokBusy, setGrokBusy] = useState<Record<string, boolean>>({});
  const [grokError, setGrokError] = useState<Record<string, string>>({});
  const asking = useRef(new Set<string>());
  const heard = useRef(new Set<string>());
  const papered = useRef(new Set<string>());
  const told = useRef(new Set<string>());
  const toldReady = useRef(false);
  const exiting = useRef(new Set<string>());
  const exitWait = useRef(new Map<string, number>());
  const spotMemory = useRef<Record<string, number>>({});
  const lastSpot = useRef<Record<AssetId, number>>({ btc: 0, gold: 0, silver: 0 });

  useEffect(() => {
    if (!hydrated) return;
    if (!toldReady.current) {
      if (!trades.length) return;
      for (const t of trades) told.current.add(`${t.id}:${t.result}`);
      toldReady.current = true;
      return;
    }
    for (const t of trades) {
      if (t.venue !== "kalshi" && t.venue !== "polymarket") continue;
      if (t.source !== "live") continue;
      const key = `${t.id}:${t.result}`;
      if (told.current.has(key)) continue;
      const sawOpen = told.current.has(`${t.id}:open`);
      told.current.add(key);
      const name = t.asset === "gold" ? "Gold" : t.asset === "eth" ? "ETH" : t.asset === "sol" ? "SOL" : t.asset === "silver" ? "Silver" : "BTC";
      const where = t.venue === "polymarket" ? "Polymarket" : "Kalshi";
      if (t.result === "open") {
        toast(`${where} fill`, { description: `${name} ${t.side.toUpperCase()}` });
        continue;
      }
      if (!sawOpen || t.profit == null || t.profit === 0) continue;
      const closedAt = Date.parse(t.closedAt ?? "");
      if (!Number.isFinite(closedAt) || Date.now() - closedAt > 2 * 60 * 1000) continue;
      toast(t.profit > 0 ? `${where} banked` : `${where} loss`, {
        description: `${name} ${t.side.toUpperCase()} ${money(t.profit)}`,
      });
    }
  }, [trades, hydrated]);

  useEffect(() => {
    if (!snap) return;
    for (const id of ["btc", "gold", "silver"] as AssetId[]) {
      const asset = snap.assets[id];
      if (asset?.spot) lastSpot.current[id] = asset.spot;
    }
  }, [snap]);

  useEffect(() => {
    if (!hydrated || !snap) return;
    for (const t of trades) {
      try {
      if (t.result !== "open") continue;
      if (goldHaltFill(t)) {
        closeTrade(t.id, {
          result: "exited",
          payout: t.stake,
          profit: 0,
          notes: "Gold book closed",
        });
        continue;
      }
      const asset = snap.assets[t.asset];
      if (!asset) continue;
      if (asset.spot) spotMemory.current[t.id] = asset.spot;

      const liveTicker = asset.market?.ticker;
      if (asset.secondsLeft > 0 || liveTicker !== t.ticker || windowStillOpen(t.ticker)) continue;
      // LIVE KALSHI TRADES SETTLE FROM KALSHI (Claude, Oct 4): the browser used to call these from its own spot vs strike at the
      // bell, and booked the 4:30 AM COTC short as +$12.18 when Kalshi paid nothing (cash says -$22.20). The server reads Kalshi's
      // real settlement (settleRolled), so the browser leaves live Kalshi trades alone.
      if (t.source === "live" && t.venue !== "polymarket" && t.venue !== "paper") continue;

      const spot = spotMemory.current[t.id] ?? t.lastSpot ?? asset.spot ?? lastSpot.current[t.asset];
      const target = t.target ?? asset.target;
      if (target == null || !spot) {
        closeTrade(t.id, {
          result: "loss",
          payout: 0,
          profit: -t.stake,
          notes: "No settle print",
        });
        continue;
      }
      const win = settleSide(t.side, spot, target);
      const payout = win ? t.contracts * 1 : 0;
      closeTrade(t.id, {
        result: win ? "win" : "loss",
        payout,
        profit: payout - t.stake,
        lastSpot: spot,
      });
      } catch {
        // one bad card cannot take the whole desk down
      }
    }
  }, [snap, trades, hydrated, closeTrade, settings.defaultExitPct]);

  useEffect(() => {
    if (!hydrated) return;
    for (const t of trades) {
      if (t.result !== "open" || t.grokThesis || !t.setupId) continue;
      const call = grokBySetup[t.setupId];
      if (!call) continue;
      patchTrade(t.id, {
        grokThesis: call.thesis,
        conviction: call.side === "pass" ? t.conviction : call.conviction,
        exitPct: exitForMultiple(t.multiple, settings.defaultExitPct),
        holdToExpiry: false,
        notes: call.side === "pass" ? "Grok would have passed" : t.notes,
      });
    }
  }, [grokBySetup, trades, hydrated, patchTrade]);

  async function runGrok(setup: Setup, asset: AssetSnapshot) {
    if (asking.current.has(setup.id)) return;
    asking.current.add(setup.id);
    setGrokBusy((s) => ({ ...s, [setup.id]: true }));
    setGrokError((s) => ({ ...s, [setup.id]: "" }));
    try {
      const res = await askDeskGrok({ data: { setup, asset } });
      if (res.ok) {
        rememberGrok(res.call);
      } else {
        setGrokError((s) => ({ ...s, [setup.id]: res.error }));
      }
    } catch (err) {
      setGrokError((s) => ({
        ...s,
        [setup.id]: err instanceof Error ? err.message : "Grok failed",
      }));
    } finally {
      setGrokBusy((s) => ({ ...s, [setup.id]: false }));
      asking.current.delete(setup.id);
    }
  }

  function takePaper(
    setup: Setup,
    asset: AssetSnapshot,
    autoFilled = false,
    probe = false,
  ) {
    if (goldHalted(setup.asset)) return;
    if (papered.current.has(setup.id)) return;
    papered.current.add(setup.id);
    const grok = grokBySetup[setup.id];
    const trade = openPaper(setup, {
      grok,
      target: asset.target,
      lastSpot: asset.spot,
      autoFilled,
      probe,
      stake: setup.clip,
    });
    if (trade) {
      if (!probe && asset.market) {
        void armLiveNow({ data: { setup, asset } })
          .then(async (live) => {
            if (live) {
              adoptBook([live]);
              return;
            }
            const book = await pullBook();
            const hit = book.find(
              (t) =>
                t.source === "live" &&
                (t.setupId === `${setup.id}:live` ||
                  t.setupId === `${setup.id}:poly` ||
                  (t.ticker === setup.ticker && t.side === setup.side && t.venue !== "polymarket")),
            );
            if (hit) adoptBook([hit]);
          })
          .catch(() => {
            // the live book announces the fill
          });
      }
    } else {
      papered.current.delete(setup.id);
    }
  }

  useEffect(() => {
    if (!hydrated || !snap || !foreground) return;
    for (const id of ["btc", "gold", "silver"] as AssetId[]) {
      const asset = snap.assets[id];
      if (!asset) continue;
      const setup = asset.setup;
      if (goldHalted(id)) continue;
      const lockedOut = (side: Setup["side"], ticker: string) => {
        const held = heldSide(useDesk.getState().trades, ticker, snap.sideLocks);
        return Boolean(held && held !== side);
      };
      const late = lateWindow(asset);
      const openWindow = useDesk
        .getState()
        .trades.some((t) => t.result === "open" && t.ticker === late?.ticker && !t.probe);
      if (
        late &&
        !openWindow &&
        !lockedOut(late.side, late.ticker) &&
        !acted.includes(late.id) &&
        !papered.current.has(late.id)
      ) {
        takePaper(late, asset, true);
      }
      if (!setup || lockedOut(setup.side, setup.ticker)) continue;

      if (!setup.watchOnly && !heard.current.has(setup.id)) {
        heard.current.add(setup.id);
        toast("Setup", { description: `${setup.side.toUpperCase()} · ${setup.pattern.label}` });
      }

      if (settings.autoGrok && !setup.watchOnly && !grokBySetup[setup.id] && !asking.current.has(setup.id)) {
        void runGrok(setup, asset);
      }

      if (acted.includes(setup.id) || papered.current.has(setup.id)) {
        const probe = farBandProbe(setup);
        if (
          probe &&
          !acted.includes(probe.id) &&
          !papered.current.has(probe.id)
        ) {
          takePaper(probe, asset, true, true);
        }
        continue;
      }
      const verdict = autoDecision(setup, settings, grokBySetup[setup.id]);
      if (verdict.action === "fill") takePaper(setup, asset, true);
      const probe = farBandProbe(setup);
      if (probe && !acted.includes(probe.id) && !papered.current.has(probe.id)) {
        takePaper(probe, asset, true, true);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [snap, settings.autoGrok, settings.autoPaper, settings.minConviction, grokBySetup, hydrated, acted, foreground]);

  // Claude: the paper headline is the real ledger. Every banked paper trade, its real stake and
  // real profit. Grok's version skipped "backwards" trades and exited losses and re-scored the rest.
  const paperOut = useMemo(() => {
    const ms = span === "12" ? 12 * 3600e3 : span === "24" ? 24 * 3600e3 : 0;
    const seen = new Set<string>();
    let pnl = 0;
    let hit = 0;
    let lost = 0;
    for (const row of fillLog.data ?? []) {
      if (row.venue !== "paper" || row.kind !== "banked" || row.profit == null) continue;
      if (seen.has(row.tradeId)) continue;
      seen.add(row.tradeId);
      if (ms) {
        const at = Date.parse(row.at ?? "");
        if (!Number.isFinite(at) || Date.now() - at > ms) continue;
      }
      pnl += row.profit;
      if (row.profit > 0) hit += 1;
      else if (row.profit < 0) lost += 1;
    }
    const closed = hit + lost;
    return { pnl: Math.round(pnl * 100) / 100, hit, lost, closed, rate: closed ? (hit / closed) * 100 : 0 };
  }, [fillLog.data, span]);
  const shown = useMemo(() => {
    if (bookTab === "poly") {
      const now = Date.now();
      const rows = (poly.data?.rows ?? []).filter((row) => row.deskStake >= 7);
      if (!rows.length) {
        return trades
          .filter((t) => t.venue === "polymarket" && t.stake >= 7)
          .map((t) => {
            const match = t.ticker.match(/(\d{4}-\d{2}-\d{2})-(\d{2})(\d{2})z$/);
            const end = match ? Date.parse(`${match[1]}T${match[2]}:${match[3]}:00Z`) + 15 * 60 * 1000 : NaN;
            if (!Number.isFinite(end) || now < end) return t;
            return { ...t, result: "exited" as const, profit: t.profit ?? 0, notes: t.notes || "Window ended." };
          });
      }
      return rows.map((row) => {
        const trade = trades.find((t) => t.ticker === row.slug && t.venue === "polymarket");
        const match = row.slug.match(/(\d{4}-\d{2}-\d{2})-(\d{2})(\d{2})z$/);
        const end = match ? Date.parse(`${match[1]}T${match[2]}:${match[3]}:00Z`) + 15 * 60 * 1000 : NaN;
        const stillOpen = row.status === "open" && (!Number.isFinite(end) || now < end);
        const won =
          row.downWon == null ? (row.expected ?? 0) > 0 : row.side === "down" ? row.downWon : !row.downWon;
        const waiting = !stillOpen && row.expected == null && row.downWon == null;
        return {
          id: trade?.id ?? row.slug,
          openedAt: trade?.openedAt ?? row.at,
          closedAt: stillOpen ? null : (trade?.closedAt ?? row.at),
          asset: "btc" as const,
          ticker: row.slug,
          side: row.side,
          source: "live" as const,
          setupId: trade?.setupId ?? row.slug,
          autoFilled: true,
          patternLabel: trade?.patternLabel ?? "Polymarket",
          stake: row.accountCost ?? row.deskStake,
          ask: row.deskAsk || trade?.ask || 0,
          multiple: row.deskAsk > 0 ? 1 / row.deskAsk : (trade?.multiple ?? 0),
          contracts: row.deskContracts,
          result: stillOpen ? ("open" as const) : waiting ? ("exited" as const) : won ? ("win" as const) : ("loss" as const),
          payout: null,
          profit: stillOpen ? null : (row.expected ?? 0),
          exitPct: null,
          holdToExpiry: true,
          conviction: trade?.conviction ?? 0,
          notes: waiting ? "Window ended. Waiting on the cash." : row.note,
          grokThesis: "",
          target: row.beat ?? trade?.target ?? null,
          lastSpot: trade?.lastSpot ?? null,
          venue: "polymarket" as const,
        };
      });
    }
    if (bookTab === "kalshi") return trades.filter((t) => t.source === "live" && t.venue !== "polymarket" && !bugExit(t));
    return trades.filter((t) => t.source !== "live" && !bugExit(t));
  }, [trades, bookTab, poly.data]);
  const runScore = useMemo(() => {
    const ms = span === "12" ? 12 * 3600e3 : span === "24" ? 24 * 3600e3 : 0;
    const inSpan = (at: string | undefined) => {
      if (!ms) return true;
      const t = Date.parse(at ?? "");
      return Number.isFinite(t) && Date.now() - t <= ms;
    };
    if (bookTab === "kalshi") {
      const grouped = new Map<string, { pnl: number; stake: number }>();
      for (const row of exitLog.data ?? []) {
        if (!inSpan(row.at)) continue;
        const key = row.ticker || row.at;
        const cur = grouped.get(key) ?? { pnl: 0, stake: 0 };
        cur.pnl += row.profit ?? 0;
        cur.stake += row.stake ?? 0;
        grouped.set(key, cur);
      }
      for (const row of fillLog.data ?? []) {
        if (row.kind !== "banked" || row.venue !== "kalshi" || row.profit == null || !inSpan(row.at)) continue;
        const key = row.ticker || row.id;
        if (grouped.has(key)) continue;
        grouped.set(key, { pnl: row.profit, stake: row.stake ?? 0 });
      }
      let hit = 0;
      let lost = 0;
      for (const row of grouped.values()) {
        if (row.stake > 0 && row.stake < 1) continue;
        if (row.pnl > 0.05) hit += 1;
        else if (row.pnl < -0.05) lost += 1;
      }
      return { hit, lost, closed: hit + lost };
    }
    const venue = bookTab === "poly" ? "polymarket" : "paper";
    const rows = (fillLog.data ?? []).filter((row) => {
      if (row.kind !== "banked" || row.venue !== venue || row.profit == null || smallExit(row.profit, row.stake)) return false;
      if (row.opposite || patternBackwards(row.side, row.pattern || "")) return false;
      return inSpan(row.at);
    });
    const latest = new Map<string, (typeof rows)[number]>();
    for (const row of rows) {
      const key = row.ticker || row.id;
      const prev = latest.get(key);
      if (!prev || row.at > prev.at) latest.set(key, row);
    }
    let hit = 0;
    let lost = 0;
    for (const row of latest.values()) {
      if ((row.profit ?? 0) > 0) hit += 1;
      else if ((row.profit ?? 0) < 0) lost += 1;
    }
    return { hit, lost, closed: latest.size };
  }, [bookTab, fillLog.data, exitLog.data, span]);
  const stats = useMemo(
    () => sessionStats(shown, bookTab === "kalshi" || bookTab === "poly" ? 0 : settings.stake),
    [shown, bookTab, settings.stake],
  );
  const stakeView = bookTab === "kalshi" || bookTab === "poly" ? 0 : settings.stake;
  const livePnl = useMemo(() => {
    if (bookTab === "poly" || bookTab === "cash") {
      const cash = poly.data?.cash;
      const anchor = poly.data?.anchor;
      if (cash != null && anchor != null) {
        let marks = 0;
        if (bookTab === "poly" && snap) {
          for (const t of shown) {
            if (t.result !== "open") continue;
            marks += markTrade(t, snap.assets[t.asset]).value;
          }
        }
        return Math.round((cash + marks - anchor) * 100) / 100;
      }
    }
    let pnl = stats.pnl;
    if (!snap) return pnl;
    for (const t of shown) {
      if (t.result !== "open" || goldHaltFill(t)) continue;
      const mark = markTrade(t, snap.assets[t.asset]);
      pnl +=
        t.probe || t.source === "live" || !(stakeView > 0)
          ? mark.profit
          : sized(mark.profit, t.stake, stakeView);
    }
    return pnl;
  }, [bookTab, poly.data, shown, snap, stats.pnl, stakeView]);


  // The MARKETS card, one render for both tabs: MARKETS, and SHIFT under the curve for whatever is open (Love, Oct 4).
  const renderMarketCard = (id: AssetId) => {
    if (!snap) return null;
    const asset = snap.assets[id];
    if (!asset) return null;
    const setup = asset.setup;
    const grok = setup ? grokBySetup[setup.id] : undefined;
    const already = Boolean(setup && acted.includes(setup.id));
    const verdict = setup ? autoDecision(setup, settings, grok) : null;
    const filled = setup
      ? trades.find(
          (t) =>
            t.setupId === setup.id ||
            (t.result === "open" && t.ticker === setup.ticker && t.side === setup.side),
        )
      : undefined;
    const autoNote = already
      ? filled?.autoFilled
        ? "Auto filled. Sitting until expiry or the exit hurdle."
        : "Logged. Sitting until expiry or the exit hurdle."
      : verdict?.action === "skip"
        ? verdict.reason
        : verdict?.action === "fill"
          ? "Armed. Auto fill on this scan."
          : undefined;
    return (
      <AssetCard
        key={id}
        snap={asset}
        grok={grok}
        grokBusy={Boolean(setup && grokBusy[setup.id])}
        grokError={setup ? grokError[setup.id] : undefined}
        already={already}
        stake={settings.stake}
        autoPaper={settings.autoPaper}
        autoNote={autoNote}
        look={look}
        onAsk={() => setup && void runGrok(setup, asset)}
        onPaper={() => setup && takePaper(setup, asset, false)}
      />
    );
  };

  const paused = hydrated && settings.autoPaper && !foreground;
  const bookWatchQ = useBookWatch();
  // TOASTS SIT ABOVE THE DOCK (Love, Oct 8 ~4:20 AM PT: "these notifications... cover the boxes and they stack over each
  // other and block me from being able to close anything whenever i move the slider, can you have those come up on top of
  // the label instead"). The Toaster's bottom offset follows the live height of the position dock, so notes stack above it.
  const [dockH, setDockH] = useState(0);
  useEffect(() => {
    if (typeof window === "undefined" || typeof ResizeObserver === "undefined") return;
    let el: Element | null = null;
    const ro = new ResizeObserver(() => setDockH(el ? Math.ceil(el.getBoundingClientRect().height) : 0));
    const attach = () => {
      const next = document.querySelector("[data-dock]");
      if (next === el) return;
      if (el) ro.unobserve(el);
      el = next;
      if (el) ro.observe(el);
      setDockH(el ? Math.ceil(el.getBoundingClientRect().height) : 0);
    };
    attach();
    const iv = window.setInterval(attach, 1000);
    return () => {
      window.clearInterval(iv);
      ro.disconnect();
    };
  }, []);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  useScrollAnchor(scrollRef);

  return (
    <div ref={scrollRef} data-desk="live" className="h-dvh overflow-x-hidden overflow-y-auto overscroll-y-contain bg-bg text-fg [-webkit-overflow-scrolling:touch]">
      <HandGuard />
      <Toaster
        theme="dark"
        position="bottom-right"
        closeButton
        expand={false}
        visibleToasts={3}
        gap={14}
        offset={{ bottom: dockH + 12, right: 12 }}
        mobileOffset={{ bottom: dockH + 12, right: 12, left: 12 }}
        duration={6000}
        toastOptions={{
          style: {
            background: "#000000",
            color: "#ffffff",
            border: "1px solid rgba(255,255,255,0.28)",
          },
        }}
      />
      <header className="sticky top-0 z-30 border-b border-line bg-bg pt-[env(safe-area-inset-top)]">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-2 px-3 py-2">
          <p className="shrink-0 font-display text-xs font-medium uppercase leading-none tracking-[0.22em]">
            Aurelius
            <a className="ml-2 text-[10px] tracking-[0.16em] text-white/45 underline" href="/aurelius-source.zip" download="aurelius-source.zip">source</a>
          </p>
          <div className="flex min-w-0 items-center gap-1">
            <button
              type="button"
              onClick={() => {
                void askHelp()
                  .then((row) => {
                    toast(row.line || "Help called.", { duration: 12000 });
                  })
                  .catch(() => {
                    toast("Help didn't go through. Tap it again.");
                  });
              }}
              className={cn(
                "flex h-8 items-center rounded-md px-2 text-[10px] tracking-[0.16em] hairline-soft",
                watch.data?.ok === false ? "text-fg" : "text-muted",
              )}
              aria-label="Call for help"
            >
              HELP
            </button>
            <span
              className="flex h-8 items-center rounded-md px-2 hairline-soft"
              title={watch.data?.line ?? "Firewall on"}
              aria-label={watch.data?.ok === false ? "Firewall alarm" : "Firewall on"}
            >
              <span
                className={cn(
                  "inline-block size-2.5 rounded-full",
                  watch.data?.ok === false ? "firewall-bad" : "firewall-on",
                )}
              />
            </span>
            <button
              type="button"
              onClick={() => {
                const next = !(watch.data?.entries === true);
                void setEntries({ data: { on: next } }).then(() => {
                  toast(next ? "Entries on. $25." : "Entries off. Open trades can still cash.");
                  void watch.refetch();
                });
              }}
              className="flex h-8 items-center rounded-md px-2 text-[10px] tracking-[0.16em] hairline-soft"
              aria-pressed={watch.data?.entries === true}
              aria-label="Toggle new entries"
            >
              {watch.data?.entries === false ? "OFF" : "ON"}
            </button>
            <button
              type="button"
              onClick={() => {
                const next = scaleQ.data?.on === false;
                void setScale75({ data: { on: next } }).then(() => {
                  toast(next ? "75% scale on. She sells when a trade clears it." : "75% scale off. You close.");
                  void scaleQ.refetch();
                });
              }}
              className="flex h-8 items-center rounded-md px-2 text-[10px] tracking-[0.16em] hairline-soft"
              aria-pressed={scaleQ.data?.on !== false}
              aria-label="Toggle 75 percent scale"
            >
              <span className={scaleQ.data?.on === false ? "text-muted" : "text-fg"}>
                {scaleQ.data?.on === false ? "75 OFF" : "75%"}
              </span>
            </button>
            <button
              type="button"
              onClick={() => {
                const next = liveQ.data?.live !== true;
                if (next && !window.confirm(`Turn LIVE on? Real Kalshi and Polymarket orders will be sent, up to $${liveQ.data?.maxDollars ?? 10} each.`)) return;
                void setLiveSwitch({ data: { live: next } }).then(() => {
                  toast(next ? "LIVE is on. Real orders can go out." : "LIVE is off. No new orders will be sent.");
                  void liveQ.refetch();
                });
              }}
              className={cn(
                "flex h-8 items-center gap-1.5 rounded-md px-2 hairline-soft",
                liveQ.data?.live === true ? "ring-1 ring-red-500/70" : "",
              )}
              aria-pressed={liveQ.data?.live === true}
              aria-label="Toggle live trading"
            >
              <span className={cn("inline-block size-1.5 rounded-full", liveQ.data?.live === true ? "bg-red-500" : "bg-subtle")} />
              <span className={cn("text-[10px] tracking-[0.16em]", liveQ.data?.live === true ? "text-fg" : "text-muted")}>
                {liveQ.data?.live === true ? "LIVE ON" : "LIVE OFF"}
              </span>
            </button>
            {hydrated ? (
              <button
                type="button"
                onClick={() => setSettings({ autoPaper: !settings.autoPaper })}
                className="flex h-8 items-center gap-1.5 rounded-md px-2 hairline-soft"
                aria-pressed={settings.autoPaper}
                aria-label="Toggle auto paper"
              >
                <span
                  className={cn(
                    "inline-block size-1.5 rounded-full",
                    paused ? "bg-warn" : settings.autoPaper ? "bg-fg glow-live" : "bg-subtle",
                  )}
                />
                <span className="text-[10px] tracking-[0.14em] text-muted">
                  {paused ? "PAUSED" : settings.autoPaper ? "AUTO" : "MANUAL"}
                </span>
              </button>
            ) : null}
            {hydrated ? (
              <SettingsDrawer
                settings={settings}
                onChange={(patch) => {
                  setSettings(patch);
                  if (typeof patch.liveStake === "number") {
                    sizeTouched.current = true;
                    void setLiveSize({ data: { dollars: patch.liveStake } });
                  }
                }}
              />
            ) : null}
          </div>
        </div>
        <label className="mx-auto hidden max-w-5xl items-center gap-2 px-3 pb-2 md:flex">
          <span className="text-[10px] tracking-[0.16em] text-muted">TRAIL</span>
          <input
            type="range"
            min={35}
            max={65}
            step={1}
            value={trail}
            aria-label="Trailing autosell trigger"
            className="glass-range min-w-0 flex-1 cursor-pointer"
            style={{ touchAction: "none" }}
            onPointerDown={() => {
              trailDrag.current = true;
            }}
            onChange={(e) => {
              const n = Number(e.target.value);
              setTrail(n);
              setSettings({ defaultExitPct: n });
            }}
            onPointerUp={() => {
              trailDrag.current = false;
            }}
            onPointerCancel={() => {
              trailDrag.current = false;
            }}
          />
          <span className="w-9 text-right text-sm tabular-nums text-fg">{trail}%</span>
        </label>
        <label className="mx-auto hidden max-w-5xl items-center gap-2 px-3 pb-2 md:flex">
          <span className="text-[10px] tracking-[0.16em] text-muted">SIZE</span>
          <input
            type="range"
            min={5}
            max={100}
            step={1}
            value={Math.min(100, Math.max(5, Math.round(settings.liveStake || 50)))}
            aria-label="Position size"
            className="glass-range min-w-0 flex-1 cursor-pointer"
            style={{ touchAction: "none" }}
            onChange={(e) => {
              const n = Number(e.target.value);
              sizeTouched.current = true;
              setSettings({ liveStake: n });
              void setLiveSize({ data: { dollars: n } });
            }}
          />
          <span className="w-10 text-right text-sm tabular-nums text-fg">${Math.round(settings.liveStake || 50)}</span>
        </label>
        <div className="flex flex-nowrap gap-1 overflow-x-auto overflow-y-hidden px-3 pb-2 [-webkit-overflow-scrolling:touch] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          <DeskTab active={bookTab === "mode"} label="MODE" onClick={() => setBookTab("mode")} />
          <DeskTab active={bookTab === "shift"} label="SHIFT" onClick={() => setBookTab("shift")} />
          <DeskTab active={bookTab === "alerts"} label={(bookWatchQ.data?.alerts ?? []).some((a) => a.level === "red") ? `ALERTS · ${(bookWatchQ.data?.alerts ?? []).length} ●` : (bookWatchQ.data?.alerts ?? []).length ? `ALERTS · ${(bookWatchQ.data?.alerts ?? []).length}` : "ALERTS"} onClick={() => setBookTab("alerts")} />
          <DeskTab active={bookTab === "kalshi"} label="KALSHI" onClick={() => setBookTab("kalshi")} />
          <DeskTab active={bookTab === "positions"} label="POSITIONS" onClick={() => setBookTab("positions")} />
          <DeskTab active={bookTab === "scanner"} label="SCANNER" onClick={() => setBookTab("scanner")} />
          <DeskTab active={bookTab === "scope"} label="SCOPE" onClick={() => setBookTab("scope")} />
          <DeskTab active={bookTab === "books"} label="BOOKS" onClick={() => setBookTab("books")} />
          <DeskTab active={bookTab === "prime"} label="PRIME BOOK" onClick={() => setBookTab("prime")} />
          <DeskTab active={bookTab === "lead"} label="$150" onClick={() => setBookTab("lead")} />
          <DeskTab active={bookTab === "symbols"} label="SYMBOLS" onClick={() => setBookTab("symbols")} />
          <DeskTab active={bookTab === "mirror"} label="MIRROR" onClick={() => setBookTab("mirror")} />
          <DeskTab active={bookTab === "open"} label="OPEN" onClick={() => setBookTab("open")} />
          <DeskTab active={bookTab === "paper"} label="PAPER" onClick={() => setBookTab("paper")} />
          <DeskTab active={bookTab === "watch"} label="WATCHING" onClick={() => setBookTab("watch")} />
          <DeskTab active={bookTab === "cash"} label="CASH" onClick={() => setBookTab("cash")} />
          <DeskTab active={bookTab === "lean"} label="SILVER" onClick={() => setBookTab("lean")} />
          <DeskTab active={bookTab === "fuel"} label="FUEL" onClick={() => setBookTab("fuel")} />
          <DeskTab active={bookTab === "markets"} label="MARKETS" onClick={() => setBookTab("markets")} />
          <DeskTab active={bookTab === "pnl"} label="P&L" onClick={() => setBookTab("pnl")} />
          <DeskTab active={bookTab === "day"} label="DAY" onClick={() => setBookTab("day")} />
          <DeskTab active={bookTab === "poly"} label="POLY" onClick={() => setBookTab("poly")} />
          <DeskTab active={bookTab === "cash"} label="CASH" onClick={() => setBookTab("cash")} />
          <DeskTab active={bookTab === "hedge"} label="HEDGE" onClick={() => setBookTab("hedge")} />
          <DeskTab active={bookTab === "scale"} label="SCALE" onClick={() => setBookTab("scale")} />
          <DeskTab active={bookTab === "stats"} label="STATS" onClick={() => setBookTab("stats")} />
          <DeskTab active={bookTab === "log"} label="LOG" onClick={() => setBookTab("log")} />
          <DeskTab active={bookTab === "sitrep"} label="SITREP" onClick={() => setBookTab("sitrep")} />
          <DeskTab active={bookTab === "audit"} label="MATCH" onClick={() => setBookTab("audit")} />
          <DeskTab active={bookTab === "outside"} label="OUTSIDE" onClick={() => setBookTab("outside")} />
          <DeskTab active={bookTab === "look"} label="LOOK" onClick={() => setBookTab("look")} />
          <DeskTab active={bookTab === "traj"} label="TRAJECTORY" onClick={() => setBookTab("traj")} />
          <DeskTab active={bookTab === "notes"} label="NOTES" onClick={() => setBookTab("notes")} />
        </div>
      </header>

      <main className={cn("mx-auto flex max-w-5xl flex-col gap-4 px-4 py-3", (held.data ?? []).length ? "pb-28" : "pb-8")}>
        {paused ? (
          <p className="text-sm text-warn">
            This screen is asleep. The desk keeps filling, and the book stays put if the page goes black.
          </p>
        ) : null}
        {bookTab === "paper" ? <PaperTruth fills={fillLog.data ?? []} /> : null}
        {bookTab === "prime" ? <PrimeTruth
            rows={primeRows.data ?? []}
            fills={fillLog.data ?? []}
            records={recordsQ.data}
            onForty={(on) => {
              void setFortyRule({ data: { on } }).then(() => recordsQ.refetch());
            }}
          /> : null}
        {bookTab === "shift" ? <ShiftBook fills={fillLog.data ?? []} start={liveQ.data?.shiftStart} held={held.data ?? []} shadow={shadowQ.data ?? []} lotto={lottoQ.data ?? []} night={nightQ.data ?? []} bt={(btQ.data as ClaudeBt) ?? null} paperStake={settings.stake} whatIf={settings.defaultExitPct} truth={truthQ.data ?? null} monitor={monitorQ.data} rules={rulesQ.data} onRule={(patch) => { void setRule({ data: patch }).then(() => rulesQ.refetch()); }} look={look} card={(id) => renderMarketCard(id)} tapes={snap ? Object.fromEntries((["btc", "gold", "silver"] as AssetId[]).filter((id) => snap.assets[id]).map((id) => [id, { spark: snap.assets[id].spark ?? [], spot: (spots.data as { [k: string]: unknown } | undefined)?.[id] && Number((spots.data as Record<string, unknown>)[id]) > 0 ? Number((spots.data as Record<string, unknown>)[id]) : snap.assets[id].spot, target: snap.assets[id].target ?? null, closeTime: snap.assets[id].market?.closeTime }])) : undefined} /> : null}
        <div className={bookTab === "shift" ? "hidden" : "contents"}>

        <section className="flex flex-col gap-4">
          <div className="flex items-end justify-between gap-3">
            <div>
            {bookTab === "audit" ? (
              <>
                <p className="mt-1 text-[10px] tracking-[0.18em] text-subtle">KALSHI VS DESK</p>
                <p className="mt-1 font-mono text-3xl tabular-nums leading-none text-fg">
                  {(audit.data ?? []).length ? (audit.data ?? []).length : "OK"}
                </p>
              </>
            ) : bookTab === "sitrep" ? (
              <>
                <p className="mt-1 text-[10px] tracking-[0.18em] text-subtle">SITUATION REPORT</p>
                <p className="mt-1 font-mono text-3xl tabular-nums leading-none text-fg">{(exitLog.data ?? []).length}</p>
              </>
            ) : bookTab === "log" ? (
              <>
                <p className="mt-1 text-[10px] tracking-[0.18em] text-subtle">OPPOSITE FILLS</p>
                <p className="mt-1 font-mono text-3xl tabular-nums leading-none text-fg">
                  {(fillLog.data ?? []).filter((e) => e.kind === "taken" && e.opposite).length}
                </p>
              </>
            ) : bookTab === "kalshi" ? (
              <>
                <p className="mt-1 text-[10px] tracking-[0.18em] text-white">BALANCE</p>
                <p className="mt-1 font-mono text-3xl tabular-nums leading-none text-white">
                  {(kalshiCash.data?.cash ?? snap?.kalshi?.cash) != null ? `$${usd(Math.max(0, kalshiCash.data?.cash ?? snap?.kalshi?.cash ?? 0), 2)}` : "—"}
                </p>
              </>
            ) : bookTab === "mode" ? (
              <>
                <p className="mt-1 text-[10px] tracking-[0.18em] text-white">MODE</p>
                <p className="mt-1 font-mono text-3xl tabular-nums leading-none text-white">
                  {(bookMode.data?.only ?? "paper").toUpperCase()}
                </p>
              </>
            ) : bookTab === "markets" ? (
              <>
                <p className="mt-1 text-[10px] tracking-[0.18em] text-subtle">MARKETS</p>
                <p className="mt-1 font-mono text-3xl tabular-nums leading-none text-fg">TAPE</p>
              </>
            ) : bookTab === "scale" || bookTab === "hedge" || bookTab === "pnl" || bookTab === "day" || bookTab === "scope" ? null : (
              <>
                <p className="mt-1 text-[10px] tracking-[0.18em] text-subtle">
                  {bookTab === "paper" ? "PAPER · REAL LEDGER" : bookTab === "kalshi" ? `$${(settings.liveStake ?? 20).toFixed(0)} LIVE` : bookTab === "cash" ? "SINCE START" : bookTab === "poly" ? "LIVE P&L" : hydrated ? "OUTCOMES" : ""}
                </p>
                <PnlFigure value={bookTab === "paper" ? paperOut.pnl : livePnl} ready={hydrated} />
              </>
            )}
          </div>
          {bookTab === "audit" ? (
            <div className="text-right font-mono text-xs tabular-nums text-muted">
              <p>Kalshi wins a tie</p>
            </div>
          ) : bookTab === "log" ? (
            <div className="text-right font-mono text-xs tabular-nums text-muted">
              <p>{(fillLog.data ?? []).filter((e) => e.kind === "taken").length} taken</p>
              <p className="mt-1 text-subtle">
                {(fillLog.data ?? []).filter((e) => e.kind === "banked").length} banked
              </p>
            </div>
          ) : bookTab === "cash" ? (
            <div className="text-right font-mono text-xs tabular-nums text-muted">
              <p>{cashView.cash != null ? `$${usd(cashView.cash, 2)}` : "—"}</p>
              <p className="mt-1 text-subtle">{cashVenue} now</p>
            </div>
          ) : bookTab === "mode" || bookTab === "scale" || bookTab === "pnl" || bookTab === "markets" ? null : (
            <div className="text-right font-mono text-xs tabular-nums text-muted">
              {bookTab === "paper" ? (
                <>
                  <p>
                    <span className="text-up">{paperOut.hit} hit</span>
                    <span> / </span>
                    <span className="text-down">{paperOut.lost} lost</span>
                  </p>
                  <p className="mt-1 text-subtle">{paperOut.closed ? `${Math.round(paperOut.rate)}%` : ""}</p>
                  <p className="mt-1 text-subtle">
                    PRIME {primeScore.data?.yes ?? 0} yes / {primeScore.data?.no ?? 0} no · all-time {primeScore.data?.allYes ?? 0} yes / {primeScore.data?.allNo ?? 0} no
                  </p>
                </>
              ) : (
                <>
                  <p className="flex items-baseline justify-end gap-3">
                    <span className="text-up">{runScore.hit}W</span>
                    <span>/</span>
                    <span className="text-down">{runScore.lost}L</span>
                    <span className="text-white/40">•</span>
                    <span className="text-white">{hydrated ? `${runScore.closed ? Math.round((runScore.hit / runScore.closed) * 100) : 0}%` : ""}</span>
                  </p>
                </>
              )}
              <div className="mt-2 flex justify-end gap-1">
                {(["12", "24", "all"] as const).map((key) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setSpan(key)}
                    className={cn("desk-pill h-6 px-2", span === key ? "text-fg" : "text-muted")}
                  >
                    {key === "all" ? "ALL" : `${key}H`}
                  </button>
                ))}
              </div>
            </div>
          )}
          </div>
        </section>

        {bookTab === "stats" ? (
          <Analytics
            trades={trades.filter((t) => t.source !== "live")}
            prime={prime.data ?? []}
            events={fillLog.data ?? []}
          />
        ) : null}

        {bookTab === "cash" ? (
          <CashBook
            venue={cashVenue}
            onVenue={setCashVenue}
            cash={cashView.cash}
            anchor={cashView.anchor}
            trail={cashView.trail}
            rows={cashView.rows}
            flags={cashView.flags}
          />
        ) : null}

        {bookTab === "audit" ? <Audit rows={audit.data ?? []} /> : null}

        {bookTab === "outside" ? (
          <section className="flex flex-col gap-2">
            <p className="text-[10px] tracking-[0.18em] text-subtle">NO DESK ID</p>
            {(outside.data ?? []).length === 0 ? (
              <p className="text-sm text-muted">None in the last six hours.</p>
            ) : (
              (outside.data ?? []).map((row) => (
                <div key={`${row.at}-${row.ticker}-${row.action}-${row.yes}`} className="flex items-baseline justify-between gap-3 border-b border-white/10 py-2">
                  <div className="min-w-0">
                    <p className="truncate font-mono text-xs text-fg">
                      {row.ticker} {row.action} {row.side}
                    </p>
                    <p className="font-mono text-[10px] text-subtle">
                      {row.at.slice(11, 19)} · {row.qty} @ {row.yes} · {row.status}
                    </p>
                  </div>
                </div>
              ))
            )}
          </section>
        ) : null}

        {bookTab === "log" ? <FillLog events={fillLog.data ?? []} /> : null}

        {bookTab === "sitrep" ? (
          <SitRep
            rows={exitLog.data ?? []}
            takes={(fillLog.data ?? []).filter((row) => row.kind === "taken" && row.venue === "kalshi").slice(-4).reverse()}
            answer=""
            note={deskNote}
            error=""
            busy={false}
            onAsk={() => {
              const last = (fillLog.data ?? []).filter((row) => row.kind === "taken" && row.venue === "kalshi").slice(-1)[0];
              const text = last
                ? explainTake(last)
                : (exitLog.data ?? [])[0]
                  ? explainExit((exitLog.data ?? [])[0])
                  : "Nothing to explain yet.";
              setDeskNote(text);
            }}
            onDig={(row) => setDeskNote(explainExit(row))}
            onTake={(row) => setDeskNote(explainTake(row))}
          />
        ) : null}


        {(bookTab === "kalshi" || bookTab === "prime") ? (
          <div className="flex flex-col gap-3">
          <section className={cn("rounded-md border border-[#6b1524]", (held.data ?? []).length === 0 ? "px-4 py-4" : "px-3 pt-1.5 pb-1.5")}>
            <p className="pb-1 text-[10px] leading-none tracking-[0.18em] text-muted">LIVE ORDERS</p>
            {(held.data ?? []).length === 0 ? (
              <p className="mt-1 text-sm text-subtle">No open 15-minute order.</p>
            ) : (
              <ul className="flex flex-col">
                {(held.data ?? []).map((row) => {
                  const book =
                    row.name === "GOLD"
                      ? snap?.assets.gold
                      : row.name === "SILVER"
                        ? snap?.assets.silver
                      : row.name === "BTC"
                        ? snap?.assets.btc
                        : undefined;
                  const market = book?.market;
                  const bid = market && market.ticker === row.ticker ? (row.side === "up" ? market.yesBid : market.noBid) : 0;
                  // One source of truth: the fresh Kalshi quote for this exact position. The board
                  // snapshot is only a fallback when that quote is stale.
                  // Freshest number wins: the position's own Kalshi quote if it is under 6 seconds old,
                  // otherwise the board's live bid for this exact contract.
                  const rowAge = row.at ? Date.now() - Date.parse(row.at) : Infinity;
                  const fresh = !row.stale && rowAge < 6000 && row.value > 0;
                  const mark = fresh ? row.value : bid > 0 ? Math.round(row.contracts * bid * 100) / 100 : row.value;
                  const taken = (fillLog.data ?? []).find(
                    (event) => event.ticker === row.ticker && event.kind === "taken" && event.pattern && event.pattern !== "Live",
                  );
                  const closeMs = windowCloseMs(row.ticker);
                  const tickerLeft = closeMs ? Math.max(0, Math.round((closeMs - Date.now()) / 1000)) : 0;
                  return (
                  <LiveOrder
                    key={row.ticker}
                    row={row}
                    why={whyTrade({
                      name: row.name,
                      side: row.side,
                      pattern: taken?.pattern,
                      spot: taken?.spot ?? row.spot,
                      target: taken?.target ?? row.target,
                    })}
                    spot={
                      row.name === "ETH"
                        ? (spots.data?.eth ?? 0)
                        : row.name === "SOL"
                          ? (spots.data?.sol ?? 0)
                          : row.spot && row.spot > 0
                            ? row.spot
                            : (book?.spot ?? 0)
                    }
                    mark={mark}
                    closeTime={book?.market?.closeTime}
                    secondsLeft={book?.secondsLeft || tickerLeft}
                    onRefresh={() => {
                      void held.refetch();
                    }}
                  />
                  );
                })}
              </ul>
            )}
          </section>
            {bookTab === "prime" ? <WatchingCards note={primeWatch.data?.note} /> : null}
            {bookTab === "kalshi" ? (
              <QuietChart>
                <TapeBook title="KALSHI" points={pointsFromFills(fillLog.data ?? [])} cash={kalshiCash.data?.cash ?? snap?.kalshi?.cash ?? null} list scaled={false} />
              </QuietChart>
            ) : (
              <QuietChart>
                <TapeBook title="PRIME BOOK" points={pointsFromPrime(prime.data ?? [])} list={false} scaled={false} />
              </QuietChart>
            )}
          </div>
        ) : null}

        {bookTab === "mode" ? (
          <ModeSwitch
            live={bookMode.data?.only ?? "paper"}
            paper={fillLog.data ?? []}
            prime={primeRows.data ?? []}
            onSubmit={(only) => {
              void setBookMode({ data: { only } }).then(() => bookMode.refetch());
            }}
          />
        ) : null}

        {bookTab === "books" ? <BookRoll rows={setupBoard.data ?? []} /> : null}

        {bookTab === "notes" ? <Notes notices={watch.data?.notices ?? []} lessons={watch.data?.lessons ?? []} /> : null}
        {bookTab === "alerts" ? <BookWatchTab /> : null}
        {bookTab === "scanner" ? <ScannerTab /> : null}
        {bookTab === "positions" ? <PositionsTab /> : null}
        {bookTab === "alerts" ? <Notes notices={watch.data?.notices ?? []} /> : null}

        {bookTab === "day" ? <DayBoardTab /> : null}
        {bookTab === "scope" ? <ScopeTab /> : null}

        {bookTab === "pnl" ? (
          <div className="flex flex-col gap-4">
            <TapeBook
              title="TAKEN"
              points={pointsFromFills(fillLog.data ?? [])}
              cash={kalshiCash.data?.cash ?? snap?.kalshi?.cash ?? null}
            />
            <TapeBook title="PRIME BOOK" points={pointsFromPrime(prime.data ?? [], "kalshi")} />
          </div>
        ) : null}

        {bookTab === "mode" || bookTab === "scale" || bookTab === "hedge" || bookTab === "log" || bookTab === "audit" || bookTab === "outside" || bookTab === "cash" || bookTab === "stats" || bookTab === "notes" || bookTab === "pnl" || bookTab === "day" || bookTab === "scope" || bookTab === "alerts" || bookTab === "scanner" || bookTab === "positions" || bookTab === "sitrep" || bookTab === "kalshi" || bookTab === "prime" || bookTab === "lead" || bookTab === "open" || bookTab === "watch" || bookTab === "lean" || bookTab === "fuel" || bookTab === "symbols" || bookTab === "mirror" || bookTab === "books" || !hydrated || !snap ? null : (
          <Positions
            trades={shown}
            assets={snap.assets}
            stake={bookTab === "poly" || bookTab === "kalshi" ? 0 : settings.stake}
            asLive={bookTab === "kalshi"}
            onSellAt={(id, cash) => {
              const t = trades.find((x) => x.id === id);
              if (!t) return;
              const next = cash == null ? null : Math.round(cash * 100) / 100;
              for (const row of trades) {
                if (row.result !== "open" || row.ticker !== t.ticker || row.side !== t.side) continue;
                patchTrade(row.id, { exitCash: next });
              }
              toast(next == null ? "Auto sell restored" : `Holds until $${next.toFixed(2)}`);
            }}
            onSize={(id, dollars) => {
              const t = shown.find((x) => x.id === id);
              if (!t || t.venue === "polymarket") return;
              if (t.source !== "live") {
                setSettings({ stake: dollars });
                return;
              }
              const market = snap.assets[t.asset].market;
              void resizeLiveOrder({
                data: { id, dollars, yesBid: market?.yesBid ?? 0, yesAsk: market?.yesAsk ?? 0 },
              }).then((res) => {
                if (!res) {
                  toast("Kalshi didn't resize");
                  return;
                }
                patchTrade(id, { stake: res.trade.stake, contracts: res.trade.contracts });
                if (res.slice) adoptBook([res.slice]);
                toast("Size updated", { description: `$${res.trade.stake.toFixed(2)} on Kalshi` });
              });
            }}
            onHalf={(id) => {
              void halfLiveOrder({ data: { id } }).then((res) => {
                if (!res) {
                  toast("Half didn't fill. The position is still whole.");
                  return;
                }
                toast(`Half banked $${res.payout.toFixed(2)}. The rest is still running.`);
              });
            }}
            onExit={(id) => {
              const t = shown.find((x) => x.id === id);
              if (!t) return;
              if (bookTab === "kalshi" || t.source === "live") {
                void closeNow({ data: { ticker: t.ticker } }).then((row) => toast(row.line)).catch(() => toast("Close didn't send. Press it again."));
                return;
              }
              if (!t || t.venue === "polymarket" || !snap) return;
              const mtm = markTrade(t, snap.assets[t.asset]);
              closeTrade(id, {
                result: "exited",
                payout: mtm.value,
                profit: mtm.profit,
              });
            }}
          />
        )}

        {q.error ? (
          <p className="text-sm text-warn">
            Scanner: {q.error instanceof Error ? q.error.message : "scan failed"}
          </p>
        ) : null}
        {snap?.error ? <p className="text-sm text-warn">{snap.error}</p> : null}

        {bookTab === "traj" ? <TrajectoryPanel books={trajQ.data ?? []} /> : null}
        {bookTab === "look" ? (
          <LookPanel
            look={look}
            onChange={(patch) =>
              setLook((prev) => {
                const next = { ...prev, ...patch };
                saveLook(next);
                return next;
              })
            }
            onReset={() => {
              saveLook(LOOK_DEFAULT);
              setLook(LOOK_DEFAULT);
            }}
          />
        ) : null}
        {/* LIVE PREVIEW (Oct 4): every slider changes this tape as you drag it, the same tape as SHIFT and MARKETS. */}
        {bookTab === "look" && snap?.assets?.btc ? (
          <div className="overflow-hidden rounded-2xl border border-white/15">
            <Sparkline spark={snap.assets.btc.spark} target={snap.assets.btc.target} live={snap.assets.btc.spot} asset="btc" look={look} tapeId="look-preview" />
          </div>
        ) : null}

        {!q.data && q.isLoading ? (
          <div className="grid gap-4 md:grid-cols-2">
            {["BTC", "GOLD", "SILVER"].map((name) => (
              <section key={name} className="min-h-80 rounded-xl bg-surface p-4 hairline">
                <p className="font-display text-3xl leading-none tracking-tight">{name}</p>
                <p className="mt-3 text-[10px] tracking-[0.22em] text-subtle">SCANNING TAPE</p>
              </section>
            ))}
          </div>
        ) : bookTab !== "markets" || !snap ? null : (
          <div className="grid gap-4 md:grid-cols-2">
            {(["btc", "gold", "silver"] as AssetId[]).map((id) => renderMarketCard(id))}
            {(alts.data ?? []).map((board) => (
              <AltCard key={board.name} board={board} look={look} />
            ))}
          </div>
        )}

        {bookTab === "prime" ? (
          <section className="rounded-md border border-white bg-black px-4 py-4 text-white">
            <div className="flex items-end justify-between gap-3">
              <p className="text-[10px] tracking-[0.22em] text-white/70">PRIME BOOK</p>
              <p className="text-right font-mono text-xs">
                <span className="text-white/50">HYPOTHETICAL </span>
                <span className={(primeRows.data ?? []).reduce((sum, row) => sum + (bookedDollars(row) ?? 0), 0) >= 0 ? "text-up" : "text-down"}>
                  {money((primeRows.data ?? []).reduce((sum, row) => sum + (bookedDollars(row) ?? 0), 0))}
                </span>
                <span className="text-white/40"> · </span>
                <span className="text-up">{primeScore.data?.yes ?? 0} yes</span>
                <span className="text-white/40"> / </span>
                <span className="text-down">{primeScore.data?.no ?? 0} no</span>
                <span className="text-white/40"> · </span>
                <span className="text-white/80">all-time {primeScore.data?.allYes ?? 0} yes / {primeScore.data?.allNo ?? 0} no</span>
              </p>
            </div>
            <p className="mt-2 text-xs leading-snug text-white/70">
              The setups that have hit the most in the log. No band between the price and the strike. Kalshi takes this book, and the paper book on Bitcoin and gold at $10. One side at a time. Nothing else can send.
            </p>
            {(primeRows.data ?? []).length === 0 ? (
              <p className="mt-4 text-sm text-white/70">No prime trades yet. The next winning setup will show here.</p>
            ) : (
              <ul className="mt-3 space-y-2">
                {(primeRows.data ?? []).map((row) => {
                  const dollars = ticketDollars(row);
                  return (
                  <li key={row.id} className="flex items-start justify-between gap-3 rounded-md border border-white bg-black px-4 py-2.5">
                    <div className="min-w-0">
                    <p className="text-sm text-white">
                      {row.asset.toUpperCase()} {row.side.toUpperCase()}
                      <span className="ml-2 text-xs uppercase tracking-wider text-white/70">
                        {`${row.bookYes ?? 0} yes / ${row.bookNo ?? 0} no · `}
                        {row.multiple && row.multiple > 1 ? `${row.multiple.toFixed(2)}x · ` : ""}
                        {row.result === "yes" ? "yes" : row.result === "no" ? "no" : "open"}
                      </span>
                    </p>
                    <p className="mt-1 text-xs leading-snug text-white/80">
                      {whyTrade({ name: row.asset, side: row.side, pattern: row.pattern })}
                    </p>
                    <p className="mt-1 text-xs text-white/60">{row.pattern}</p>
                    {reachText(row.multiple, row.peak) ? (
                      <p className="mt-1 font-mono text-[10px] tabular-nums text-white/70">{reachText(row.multiple, row.peak)}</p>
                    ) : null}
                    </div>
                    <div className="text-right">
                    <p className={`font-mono text-sm tabular-nums ${dollars == null ? "text-white/50" : dollars >= 0 ? "text-up" : "text-down"}`}>
                      {dollars == null ? "—" : money(dollars)}
                    </p>
                    {row.result === "open" && dollars != null ? <p className="font-mono text-[10px] text-white/50">if yes</p> : null}
                    </div>
                  </li>
                  );
                })}
              </ul>
            )}
            <PaperShelf
              title="HALF-BAND BOOK"
              blurb="Same prime setups, same no-band rule. If price is already past the strike, the lead has to be at least half a band or she skips it. Paper only."
              rows={halfRows.data ?? []}
            />
            <PaperShelf
              title="$150 BOOK"
              blurb="Bitcoin only. Long when price is already $150 over the strike. Short when it is already $150 under. One try per window. Paper only."
              rows={decidedRows.data ?? []}
            />
          </section>
        ) : null}

        {bookTab === "lead" ? (
          <PaperShelf
            title="$150 BOOK"
            blurb="Bitcoin only. Long when price is already $150 over the strike. Short when it is already $150 under. One try per window. Paper only. It does not use the band rule, because price is already through the strike."
            rows={decidedRows.data ?? []}
          />
        ) : null}

        {bookTab === "open" ? (
          <section className="rounded-md border border-white bg-black px-4 py-4 text-white">
            <p className="text-[10px] tracking-[0.22em] text-white/70">OPEN POSITIONS</p>
            <p className="mt-2 text-xs leading-snug text-white/70">Prime book only. The same row Kalshi is allowed to hold.</p>
            {(primeRows.data ?? []).filter((row) => row.result === "open").length === 0 ? (
              <p className="mt-4 text-sm text-white/70">No open prime position.</p>
            ) : (
              <ul className="mt-3 space-y-2">
                {(primeRows.data ?? []).filter((row) => row.result === "open").map((row) => {
                  const book = row.asset === "gold" ? snap?.assets.gold : row.asset === "silver" ? snap?.assets.silver : snap?.assets.btc;
                  const market = book?.market;
                  const bid = market && market.ticker === row.ticker ? (row.side === "up" ? market.yesBid : market.noBid) : 0;
                  const live = (held.data ?? []).find((item) => item.ticker === row.ticker);
                  const entry = row.multiple && row.multiple > 1 ? 1 / row.multiple : 0;
                  const livePct = live && live.cost > 0 ? ((live.value - live.cost) / live.cost) * 100 : entry > 0 && bid > 0 ? (bid / entry - 1) * 100 : null;
                  const dollars = live ? live.value - live.cost : null;
                  const spot = book?.spot ?? 0;
                  const tone = livePct == null ? "text-white/50" : livePct > 0.5 ? "text-up" : livePct < -0.5 ? "text-down" : "text-white";
                  return (
                  <li key={row.id} className="rounded-md border border-white bg-black px-4 py-2.5">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-sm text-white">
                          {row.asset.toUpperCase()} {row.side.toUpperCase()}
                          <span className="ml-2 text-xs uppercase tracking-wider text-white/70">
                            {row.live === "filled" ? "on Kalshi" : "waiting"}
                            {row.multiple && row.multiple > 1 ? ` · ${row.multiple.toFixed(2)}x` : ""}
                          </span>
                        </p>
                        <p className="mt-1 font-mono text-sm tabular-nums text-white">{spot > 0 ? `$${usd(spot, 2)}` : "—"}</p>
                        <p className="mt-1 text-xs text-white/80">{row.pattern}</p>
                      </div>
                      <div className="text-right">
                        <p className={`font-mono text-sm tabular-nums ${tone}`}>
                          {livePct == null ? "—" : `${livePct > 0.5 ? "+" : livePct < -0.5 ? "−" : ""}${Math.abs(Math.round(livePct))}%`}
                        </p>
                        <p className={`mt-1 font-mono text-xs tabular-nums ${tone}`}>{dollars == null ? (bid > 0 ? `${Math.round(bid * 100)}¢` : "—") : money(dollars)}</p>
                      </div>
                    </div>
                  </li>
                  );
                })}
              </ul>
            )}
          </section>
        ) : null}

        {bookTab === "watch" ? <WatchingCards note={primeWatch.data?.note} /> : null}

        {bookTab === "symbols" ? (() => {
          const rows = symbolLab.data?.rows ?? [];
          const check = symbolLab.data?.check;
          const names = ["btc", "gold", "silver", "oil", "gas", "copper", "eth", "sol"] as const;
          const label: Record<string, string> = {
            btc: "BITCOIN",
            gold: "GOLD",
            silver: "SILVER",
            oil: "OIL",
            gas: "GAS",
            copper: "COPPER",
            eth: "ETH",
            sol: "SOL",
          };
          const clock = check?.at
            ? new Date(check.at).toLocaleTimeString("en-US", { timeZone: "America/Los_Angeles", hour: "numeric", minute: "2-digit" })
            : "";
          const groups = names.map((id) => {
            const mine = rows.filter((row) => row.asset === id);
            const tally = new Map<string, { side: string; pattern: string; yes: number; no: number; profit: number }>();
            for (const row of mine) {
              if (row.result !== "yes" && row.result !== "no") continue;
              const key = `${row.side}|${row.pattern}`;
              const cur = tally.get(key) || { side: row.side, pattern: row.pattern, yes: 0, no: 0, profit: 0 };
              if (row.result === "yes") cur.yes += 1;
              else cur.no += 1;
              cur.profit += row.profit || 0;
              tally.set(key, cur);
            }
            return { id, open: mine.filter((row) => row.result === "open"), scores: [...tally.values()] };
          }).filter((group) => group.open.length || group.scores.length);
          const green = check?.greenHours ?? 0;
          return (
            <section className="rounded-md border border-white bg-black px-4 py-4 text-white">
              <p className="text-[10px] tracking-[0.22em] text-white/70">EVERY SYMBOL</p>
              <p className="mt-2 text-xs leading-snug text-white/70">
                Every prime setup, on bitcoin, gold, silver, oil, gas, copper, eth, and sol. A long does not fire with a band above. A short does not fire with a band below. Paper only. Kalshi stays off until this is clean and green for 24 hours. It will not turn itself live.
              </p>
              <p className={`mt-3 text-sm ${check?.halted ? "text-down" : "text-white"}`}>
                {check?.halted
                  ? `Stopped. ${check.reason || "The logic broke."} New paper is off. Your positions were left alone.`
                  : clock
                    ? `Checked ${clock} PT. Logic is clean. ${green} of 24 green hours.`
                    : "Hourly check is on. It looks every hour and stops the test if a long is under a band or a short is above one."}
              </p>
              {groups.length === 0 ? (
                <p className="mt-4 text-sm text-white/70">Nothing has cleared yet. It only papers a setup the prime book already knows, and only when the band is not in the way.</p>
              ) : (
                <ul className="mt-4 space-y-4">
                  {groups.map((group) => (
                    <li key={group.id}>
                      <p className="text-[10px] tracking-[0.18em] text-white/70">{label[group.id]}</p>
                      <ul className="mt-1 space-y-2">
                        {group.scores.map((row) => (
                          <li key={`${row.side}|${row.pattern}`} className="flex items-start justify-between gap-3 border-t border-white/20 pt-2">
                            <p className="text-sm text-white">
                              {row.side === "up" ? "UP" : "DOWN"}
                              <span className="mt-1 block text-xs text-white/70">{row.pattern}</span>
                            </p>
                            <p className="text-right font-mono text-xs">
                              <span className="text-up">{row.yes} yes</span>
                              <span className="text-white/40"> / </span>
                              <span className="text-down">{row.no} no</span>
                              <span className={`mt-1 block tabular-nums ${row.profit >= 0 ? "text-up" : "text-down"}`}>{money(row.profit)}</span>
                            </p>
                          </li>
                        ))}
                        {group.open.map((row) => (
                          <li key={row.id} className="flex items-start justify-between gap-3 border-t border-white/20 pt-2">
                            <p className="text-sm text-white">
                              {row.side === "up" ? "UP" : "DOWN"}
                              <span className="ml-2 text-xs uppercase tracking-wider text-white/70">open{row.multiple && row.multiple > 1 ? ` · ${row.multiple.toFixed(2)}x` : ""}</span>
                              <span className="mt-1 block text-xs text-white/70">{row.pattern}</span>
                            </p>
                            <p className="font-mono text-xs text-white/70">paper</p>
                          </li>
                        ))}
                      </ul>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          );
        })() : null}

        {bookTab === "mirror" ? <MirrorSheet rows={mirrorSheet.data ?? []} /> : null}

        {bookTab === "fuel" ? (
          <section className="rounded-md border border-white bg-black px-4 py-4 text-white">
            <p className="text-[10px] tracking-[0.22em] text-white/70">OIL, GAS, COPPER</p>
            <p className="mt-2 text-xs leading-snug text-white/70">Paper only. Same prime setups as bitcoin, gold, and silver. Kalshi does not take these.</p>
            {(fuelRows.data ?? []).length === 0 ? (
              <p className="mt-4 text-sm text-white/70">Nothing on the fuel book yet. It takes the next prime setup that clears the band.</p>
            ) : (
              <ul className="mt-3 space-y-2">
                {(fuelRows.data ?? []).map((row) => (
                  <li key={row.id} className="rounded-md border border-white bg-black px-4 py-2.5">
                    <p className="text-sm text-white">
                      {row.asset.toUpperCase()} {row.side.toUpperCase()}
                      <span className="ml-2 text-xs uppercase tracking-wider text-white/70">
                        {row.multiple && row.multiple > 1 ? `${row.multiple.toFixed(2)}x · ` : ""}
                        {row.result}
                      </span>
                    </p>
                    <p className="mt-1 text-xs text-white/70">{row.pattern}</p>
                  </li>
                ))}
              </ul>
            )}
          </section>
        ) : null}

        {bookTab === "lean" ? (
          <section className="rounded-md border border-white bg-black px-4 py-4 text-white">
            <div className="flex items-end justify-between gap-3">
              <p className="text-[10px] tracking-[0.22em] text-white/70">SILVER PAPER</p>
              <p className="text-right font-mono text-xs">
                <span className={(leanRows.data ?? []).reduce((sum, row) => sum + (bookedDollars(row) ?? 0), 0) >= 0 ? "text-up" : "text-down"}>
                  {money((leanRows.data ?? []).reduce((sum, row) => sum + (bookedDollars(row) ?? 0), 0))}
                </span>
                <span className="text-white/40"> · </span>
                <span className="text-up">{(leanRows.data ?? []).filter((row) => row.result === "yes").length} yes</span>
                <span className="text-white/40"> / </span>
                <span className="text-down">{(leanRows.data ?? []).filter((row) => row.result === "no").length} no</span>
              </p>
            </div>
            <p className="mt-2 text-xs leading-snug text-white/70">
              Paper only. The setups Bitcoin and gold have won. Kalshi does not take these.
            </p>
            {(leanRows.data ?? []).length === 0 ? (
              <p className="mt-4 text-sm text-white/70">No silver paper trades yet. The next Bitcoin or gold setup will show here.</p>
            ) : (
              <ul className="mt-3 space-y-2">
                {(leanRows.data ?? []).map((row) => {
                  const dollars = ticketDollars(row);
                  return (
                  <li key={row.id} className="flex items-start justify-between gap-3 rounded-md border border-white bg-black px-4 py-2.5">
                    <div className="min-w-0">
                    <p className="text-sm text-white">
                      {row.asset.toUpperCase()} {row.side.toUpperCase()}
                      <span className="ml-2 text-xs uppercase tracking-wider text-white/70">
                        {row.multiple.toFixed(2)}x · {row.result === "yes" ? "yes" : row.result === "no" ? "no" : "open"}
                      </span>
                    </p>
                    <p className="mt-1 text-xs leading-snug text-white/80">
                      {whyTrade({ name: row.asset, side: row.side, pattern: row.pattern })} Price had already decided, and it was on the side of the target.
                    </p>
                    <p className="mt-1 text-xs text-white/60">{row.pattern}</p>
                    </div>
                    <div className="text-right">
                    <p className={`font-mono text-sm tabular-nums ${dollars == null ? "text-white/50" : dollars >= 0 ? "text-up" : "text-down"}`}>
                      {dollars == null ? "—" : money(dollars)}
                    </p>
                    {row.result === "open" && dollars != null ? <p className="font-mono text-[10px] text-white/50">if yes</p> : null}
                    </div>
                  </li>
                  );
                })}
              </ul>
            )}
          </section>
        ) : null}

        {bookTab === "paper" || bookTab === "prime" ? <ComboBook rows={comboRows.data ?? []} /> : null}

        {bookTab === "scale" ? (
          <ScaleBook />
        ) : bookTab === "hedge" ? (
          <HedgeBook />
        ) : bookTab === "log" || bookTab === "audit" || bookTab === "outside" || bookTab === "cash" || bookTab === "stats" || bookTab === "look" || bookTab === "notes" || bookTab === "pnl" || bookTab === "alerts" || bookTab === "scanner" || bookTab === "positions" || bookTab === "sitrep" || bookTab === "markets" || bookTab === "kalshi" || bookTab === "prime" || bookTab === "lead" || bookTab === "open" || bookTab === "watch" || bookTab === "lean" || bookTab === "fuel" || bookTab === "symbols" || bookTab === "mirror" ? null : hydrated ? (
          <StillJournal trades={shown} stake={bookTab === "paper" ? 25 : bookTab === "kalshi" || bookTab === "poly" ? 0 : settings.stake} outcomes={bookTab === "paper"} exits={exitLog.data ?? []} mirrorExits={bookTab === "kalshi"} />
        ) : null}
      </div>
      </main>
      {dockRows.length ? (
        <div data-dock className="fixed inset-x-0 bottom-0 z-40 border-t border-white/60 bg-black px-3 pb-[max(2px,env(safe-area-inset-bottom))]">
          {dockRows.map((row) => row.ghost || dockClosing[row.ticker] ? (
            <div key={row.ticker} className="my-1 rounded-lg px-3 py-2 font-mono text-[10px] tracking-[0.2em] text-white/50" style={{ border: "1px solid rgba(255,255,255,0.25)" }}>
              {Number(dockClosing[row.ticker]) > 0 && Number(dockClosing[row.ticker]) < 100 ? `SELLING ${dockClosing[row.ticker]}%` : "CLOSING"} {/BTC/.test(row.ticker) ? "BTC" : /GOLD/.test(row.ticker) ? "GOLD" : row.ticker}…
            </div>
          ) : (
            <DockOrder
              key={row.ticker}
              row={row}
              onClose={() => dockTap(row.ticker, () => {
                // INSTANT ANSWER (Oct 15, Love: "make it close when i hit close"): the row flips to CLOSING... the moment
                // she taps, before the server replies, so there is nothing left to double-click.
                setDockClosing((m) => ({ ...m, [row.ticker]: Date.now() }));
                void fastClose(row.ticker, performance.timeOrigin + (((window as any).event?.timeStamp as number | undefined) ?? performance.now())).then((res) => {
                  toast(res.line);
                  void held.refetch();
                }).catch(() => toast("Close didn't send. Press it again.")).finally(() => {
                  setDockClosing((m) => { const next = { ...m }; delete next[row.ticker]; return next; });
                });
              })}
              onPart={(pct) => dockTap(`${row.ticker}:part`, () => {
                // INSTANT LOCK (Oct 17): the row flips to SELLING 25%… on the tap, so a second tap can't sell more; express lane.
                if (dockClosing[row.ticker]) return;
                setDockClosing((m) => ({ ...m, [row.ticker]: pct }));
                void fastPart(row.ticker, pct).then((res) => {
                  toast(res.line);
                  void held.refetch();
                }).catch(() => toast(`Couldn't sell ${pct}%. Press it again.`)).finally(() => {
                  setDockClosing((m) => { const next = { ...m }; delete next[row.ticker]; return next; });
                });
              })}
            />
          ))}
        </div>
      ) : null}
    </div>
  );
}

import { useMemo as useShiftMemo, useState as useShiftState } from "react";
import type { FillEvent as ShiftFill } from "@/lib/desk/fill-log";
import type { HeldOrder as ShiftHeld } from "@/lib/desk/fns";
// one shared Pacific formatter for the inline trade lists (building one per row is what made Safari reload, Oct 11)
const INLINE_FMT = new Intl.DateTimeFormat("en-US", { timeZone: "America/Los_Angeles", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });

// SHIFT — the book that starts when Claude took over the desk.
// Kalshi live only. One row per 15-minute window. Pure black; light comes only from lines and numbers.

const SHIFT_UP = "#3ddc84";
const SHIFT_DOWN = "#ff5c5c";

type ShiftRow = { ticker: string; at: string; asset: string; side: string; setup: string; stake: number; multiple: number; pnl: number };

// A 15-minute window is over once its close time passes, even before Kalshi posts the result (Love, Oct 3).
function windowDone(ticker: string): boolean {
  const m = ticker.match(/-(\d\d)([A-Z]{3})(\d\d)(\d\d)(\d\d)/);
  if (!m) return false;
  const mon = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"].indexOf(m[2]);
  if (mon < 0) return false;
  const off = mon >= 2 && mon <= 9 ? 4 : 5;
  return Date.now() >= Date.UTC(2000 + Number(m[1]), mon, Number(m[3]), Number(m[4]) + off, Number(m[5]));
}
function shiftClock(at: string) {
  return new Date(at).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", hour12: true });
}
function shiftDay(at: string) {
  return new Date(at).toLocaleDateString("en-US", { month: "short", day: "numeric" }).toUpperCase();
}
function shiftMoney(n: number) {
  const s = `$${Math.abs(n).toFixed(2)}`;
  return n > 0.004 ? `+${s}` : n < -0.004 ? `−${s}` : s;
}
const shiftGlow = (color: string, px = 10) => ({ textShadow: `0 0 ${px}px ${color}` });

function ShiftChip({ label, value, tone }: { label: string; value: string; tone?: "up" | "down" }) {
  const color = tone === "up" ? SHIFT_UP : tone === "down" ? SHIFT_DOWN : "#ffffff";
  return (
    <div className="flex min-w-[96px] flex-1 flex-col items-center gap-1 rounded-full border border-white/25 px-4 py-2 shadow-[0_0_14px_rgba(255,255,255,0.08)]">
      <span className="text-[9px] tracking-[0.24em] text-white/70">{label}</span>
      <span className="font-mono text-sm tabular-nums" style={{ color, ...shiftGlow(color, 8) }}>
        {value}
      </span>
    </div>
  );
}

function shiftSym(row: { asset?: string; ticker?: string }) {
  const a = String(row.asset || row.ticker || "");
  if (/^KXMVE/i.test(a)) return "COMBO";
  if (/^KX/i.test(a)) return a.replace(/^KX/i, "").replace(/(15M|D)?-.*$/i, "").toUpperCase();
  return a.toUpperCase();
}
function ShiftCurve({ rows }: { rows: ShiftRow[] }) {
  // SHIFT CURVE (Love, Oct 4 ~12:40 AM PT: "it has whatever the last card opened stuck there... some dots are blocked by
  // the card... make the dots smaller and a tiny bit bigger when you hover... make the line white and remove the dotted
  // line"). Hover now follows the nearest dot to the pointer (no tiny targets to hit), the card sits next to that dot and
  // never over it, and it clears when the pointer leaves (or 2.5 s after a tap on a phone).
  const [hover, setHover] = useShiftState<number | null>(null);
  // Oct 12 (Love: "4h - 12 - 24h - 1 week - & all buttons to view the chart in those timeframes"): the curve restarts at
  // $0 at the start of the chosen window, so RUN on a dot is what that window has made up to that trade.
  const [range, setRange] = useShiftState<"4H" | "12H" | "24H" | "1W" | "ALL">("ALL");
  const boxRef = useRef<HTMLDivElement>(null);
  const clearRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const W = 640;
  const H = 200;
  const P = 18;
  const view = useShiftMemo(() => {
    const ms = { "4H": 4, "12H": 12, "24H": 24, "1W": 168, ALL: 0 }[range] * 3600 * 1000;
    if (!ms) return rows;
    const from = Date.now() - ms;
    return rows.filter((r) => Date.parse(r.at) >= from);
  }, [rows, range]);
  const pts = useShiftMemo(() => {
    let run = 0;
    const out: { x: number; y: number; row: ShiftRow | null }[] = [{ x: 0, y: 0, row: null }];
    view.forEach((row, i) => {
      run += row.pnl;
      out.push({ x: i + 1, y: Math.round(run * 100) / 100, row });
    });
    return out;
  }, [view]);
  const ys = pts.map((p) => p.y);
  const lo = Math.min(0, ...ys);
  const hi = Math.max(0, ...ys);
  const span = hi - lo || 1;
  const sx = (x: number) => P + (x / Math.max(1, pts.length - 1)) * (W - 2 * P);
  const sy = (y: number) => H - P - ((y - lo) / span) * (H - 2 * P);
  const path = pts.map((p, i) => `${i ? "L" : "M"}${sx(p.x).toFixed(1)},${sy(p.y).toFixed(1)}`).join(" ");
  const nearest = (clientX: number) => {
    const el = boxRef.current;
    if (!el || pts.length < 2) return null;
    const r = el.getBoundingClientRect();
    const fx = ((clientX - r.left) / r.width) * W;
    let best = 1;
    let bd = Infinity;
    for (let i = 1; i < pts.length; i++) {
      const d = Math.abs(sx(pts[i].x) - fx);
      if (d < bd) {
        bd = d;
        best = i;
      }
    }
    return best;
  };
  const pick = (clientX: number) => {
    if (clearRef.current) clearTimeout(clearRef.current);
    setHover(nearest(clientX));
  };
  const h = hover != null ? pts[hover] : null;
  const hx = h ? (sx(h.x) / W) * 100 : 0;
  const hy = h ? (sy(h.y) / H) * 100 : 0;
  const runEnd = pts.length ? pts[pts.length - 1].y : 0;
  return (
    <div>
    <div className="mb-1.5 flex items-center justify-end gap-1.5">
      {/* Oct 12 (Love: "her labels stick... the card blocks them... just the symbol, the date and time and the P&L"): the
          readout sits up here, never over the dots. */}
      {h?.row ? (
        <span className="mr-auto font-mono text-[10px] tabular-nums tracking-[0.08em]">
          <span className="text-white/80">{shiftSym(h.row)} · {shiftDay(h.row.at)} · {shiftClock(h.row.at)} · </span>
          <span style={{ color: h.row.pnl >= 0 ? SHIFT_UP : SHIFT_DOWN }}>{shiftMoney(h.row.pnl)}</span>
        </span>
      ) : (
        <span className="mr-auto font-mono text-[10px] tabular-nums" style={{ color: runEnd >= 0 ? SHIFT_UP : SHIFT_DOWN }}>
          {range === "ALL" ? "" : `${range} · ${shiftMoney(runEnd)} · ${view.length} trades`}
        </span>
      )}
      {(["4H", "12H", "24H", "1W", "ALL"] as const).map((k) => (
        <button
          key={k}
          type="button"
          onClick={() => { setRange(k); setHover(null); }}
          className="rounded-full border px-2.5 py-0.5 font-mono text-[9px] tracking-[0.15em]"
          style={{ borderColor: range === k ? SHIFT_UP : "rgba(255,255,255,0.3)", color: range === k ? SHIFT_UP : "rgba(255,255,255,0.7)" }}
        >
          {k}
        </button>
      ))}
    </div>
    <div
      ref={boxRef}
      className="relative touch-pan-y select-none"
      onMouseMove={(e) => pick(e.clientX)}
      onMouseLeave={() => setHover(null)}
      onTouchStart={(e) => pick(e.touches[0].clientX)}
      onTouchMove={(e) => pick(e.touches[0].clientX)}
      onTouchEnd={() => {
        if (clearRef.current) clearTimeout(clearRef.current);
        clearRef.current = setTimeout(() => setHover(null), 2500);
      }}
    >
      <svg viewBox={`0 0 ${W} ${H}`} className="h-[200px] w-full" preserveAspectRatio="none">
        <defs>
          <filter id="shift-shiftGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
        <path d={path} fill="none" stroke="#ffffff" strokeWidth="1.6" filter="url(#shift-shiftGlow)" vectorEffect="non-scaling-stroke" strokeLinejoin="round" />
      </svg>
      {pts.map((p, i) => {
        if (i === 0) return null;
        const c = (p.row?.pnl ?? 0) >= 0 ? SHIFT_UP : SHIFT_DOWN;
        const on = hover === i;
        return (
          <span
            key={i}
            className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 rounded-full transition-[width,height] duration-150"
            style={{
              left: `${(sx(p.x) / W) * 100}%`,
              top: `${(sy(p.y) / H) * 100}%`,
              width: on ? 10 : 4,
              height: on ? 10 : 4,
              background: c,
              boxShadow: on ? `0 0 10px ${c}` : undefined,
              zIndex: on ? 2 : 1,
            }}
          />
        );
      })}
    </div>
    </div>
  );
}

type ShiftShadow = { id: string; at: string; asset: string; side: string; band: string; multiple: number; result: string; bellProfit: number | null; tpProfit: number | null; tpHit: boolean };

function ShadowCard({ rows }: { rows: ShiftShadow[] }) {
  const done = rows.filter((r) => r.result !== "open");
  const wins = done.filter((r) => r.result === "win").length;
  const bell = done.reduce((t, r) => t + (r.bellProfit ?? 0), 0);
  const tp = done.reduce((t, r) => t + (r.tpProfit ?? 0), 0);
  const open = rows.filter((r) => r.result === "open").length;
  return (
    <section className="rounded-[22px] border border-white/20 px-5 py-4 shadow-[0_0_18px_rgba(255,255,255,0.05)]">
      <div className="flex items-baseline justify-between gap-3">
        <p className="text-[10px] tracking-[0.28em] text-white/85">REJECTION MODEL · SHADOW</p>
        <p className="text-[9px] tracking-[0.2em] text-white/50">PAPER ONLY · 1-MIN CLOSE OFF A BAND</p>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        <ShiftChip label="CALLS" value={String(rows.length)} />
        <ShiftChip label="AT THE BELL" value={done.length ? `${wins}-${done.length - wins}` : "—"} />
        <ShiftChip label="HIT RATE" value={done.length ? `${Math.round((wins / done.length) * 100)}%` : "—"} />
        <ShiftChip label="HELD P&L" value={done.length ? shiftMoney(bell) : "—"} tone={bell >= 0 ? "up" : "down"} />
        <ShiftChip label="WITH TAKE PROFIT" value={done.length ? shiftMoney(tp) : "—"} tone={tp >= 0 ? "up" : "down"} />
      </div>
      <div className="mt-3 flex flex-col gap-1.5">
        {rows.slice(0, 6).map((r) => {
          const p = r.result === "open" ? null : r.tpProfit ?? r.bellProfit;
          const c = p == null ? "#ffffff" : p >= 0 ? SHIFT_UP : SHIFT_DOWN;
          return (
            <div key={r.id} className="flex items-center justify-between gap-3 rounded-full border border-white/15 px-4 py-1.5">
              <span className="text-[10px] tracking-[0.16em] text-white/85">
                {shiftClock(r.at)} · {r.asset.toUpperCase()} {r.side === "up" ? "LONG" : "SHORT"} · OFF {r.band} · {Number(r.multiple).toFixed(2)}x
              </span>
              <span className="font-mono text-[11px] tabular-nums" style={{ color: c }}>
                {r.result === "open" ? (open ? "OPEN" : "") : `${r.result.toUpperCase()} ${shiftMoney(p ?? 0)}`}
              </span>
            </div>
          );
        })}
        {!rows.length ? <p className="py-2 text-center text-[10px] tracking-[0.22em] text-white/55">WATCHING FOR THE FIRST REJECTION</p> : null}
      </div>
    </section>
  );
}

type ShiftLotto = { id: string; at: string; asset: string; side: string; sigma: number; multiple: number; peakPct: number; result: string; profits: Record<string, number> | null };

// LOTTO LAB: $5 out-of-band tickets, 3x-20x, scored five ways on real Kalshi bids. Paper only.
function LottoCard({ rows }: { rows: ShiftLotto[] }) {
  const done = rows.filter((r) => r.result !== "open" && r.profits);
  const rules = ["+50", "+100", "+200", "+300", "hold"];
  const score = rules.map((k) => {
    const pnl = done.reduce((t, r) => t + (r.profits?.[k] ?? 0), 0);
    const wins = done.filter((r) => (r.profits?.[k] ?? 0) > 0).length;
    return { k, pnl, wins };
  });
  const best = done.length ? score.reduce((b, x) => (x.pnl > b.pnl ? x : b), score[0]) : null;
  return (
    <section className="rounded-[22px] border border-white/20 px-5 py-4 shadow-[0_0_18px_rgba(255,255,255,0.05)]">
      <div className="flex items-baseline justify-between gap-3">
        <p className="text-[10px] tracking-[0.28em] text-white/85">LOTTO LAB · OUT OF BAND</p>
        <p className="text-[9px] tracking-[0.2em] text-white/50">PAPER ONLY · $5 · 3x–20x · FADE 2σ+</p>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        <ShiftChip label="TICKETS" value={`${rows.length}${rows.length - done.length ? ` · ${rows.length - done.length} OPEN` : ""}`} />
        {score.map((x) => (
          <ShiftChip
            key={x.k}
            label={`${x.k === "hold" ? "HOLD TO BELL" : `SELL AT ${x.k}%`}${best && best.k === x.k ? " ★" : ""}`}
            value={done.length ? `${shiftMoney(x.pnl)} · ${x.wins}/${done.length}` : "—"}
            tone={done.length ? (x.pnl >= 0 ? "up" : "down") : undefined}
          />
        ))}
      </div>
      <div className="mt-3 flex flex-col gap-1.5">
        {rows.slice(0, 8).map((r) => {
          const p = best && r.profits ? r.profits[best.k] : null;
          const c = p == null ? "#ffffff" : p >= 0 ? SHIFT_UP : SHIFT_DOWN;
          return (
            <div key={r.id} className="flex items-center justify-between gap-3 rounded-full border border-white/15 px-4 py-1.5">
              <span className="text-[10px] tracking-[0.16em] text-white/85">
                {shiftClock(r.at)} · {r.asset.toUpperCase()} {r.side === "up" ? "LONG" : "SHORT"} · {r.sigma > 0 ? "+" : ""}{Number(r.sigma).toFixed(1)}σ · {Number(r.multiple).toFixed(1)}x
              </span>
              <span className="font-mono text-[11px] tabular-nums" style={{ color: c }}>
                PEAK {r.peakPct > 0 ? "+" : ""}{r.peakPct}%{r.result === "open" ? " · OPEN" : p != null ? ` · ${shiftMoney(p)}` : ""}
              </span>
            </div>
          );
        })}
        {!rows.length ? <p className="py-2 text-center text-[10px] tracking-[0.22em] text-white/55">WAITING FOR PRICE TO LEAVE THE BANDS</p> : null}
      </div>
    </section>
  );
}

type ShiftNight = { id: string; book: "recon-fresh" | "recon-all" | "recon-dly" | "recon-ogp5" | "recon-paper" | "recon-tog" | "recon-top" | "recon-rej" | "ogp5-sess" | "ogp5-c1" | "ogp5-c5" | "ogp5-hrs" | "ogp5-bbsr" | "ogp5-dly" | "supernova" | "ogp5-r15" | "ogp5-r30" | "ogp5-cb" | "ogp5-fast" | "ogp5-gw" | "ogp5-inv" | "ogp5-boll" | "ogp5-lock" | "ogp5-btco" | "ogp5-pv" | "brk-sess" | "brk-sesspk" | "brk-sessrj" | "brk5" | "brk10" | "brk15" | "gold-rg" | "twtog" | "twhyb" | "twtrend" | "twflush" | "twrev2" | "twrev" | "twrev5" | "twrevsp5" | "twrevogp15" | "twrevogp5" | "twlive" | "twbtc" | "twgold" | "twclean" | "twno45" | "twnocs" | "twsp5b" | "twogp15b" | "twogp5b" | "oggb" | "oghb" | "ogp2b" | "ogp5b" | "ogp10b" | "ogp15b" | "ogp2" | "ogp5" | "ogp10" | "ogp15" | "ogg" | "ogh" | "grokb" | "pap20" | "piv2" | "piv5" | "piv10" | "piv15" | "sp2" | "sp5" | "sp10" | "sp15" | "brnw" | "sqnw" | "pap247" | "papbest" | "papwin" | "original" | "new" | "refined" | "golden" | "optA" | "optB" | "claude" | "trend" | "brick" | "cotc" | "diamond" | "diamond25" | "confirm" | "brk1" | "sole5" | "sole10" | "sole15" | "sole5p" | "sole5z" | "sole5v" | "brickc" | "lastmin" | "lastgrant" | "bank" | "bank2" | "bank5p" | "claudex" | "trendx" | "brickx" | "bank5px" | "brickt" | "brickp" | "bricks" | "brickcr" | "brickc75" | "brickcf" | "brickcm" | "brickcpt" | "brickcx" | "brickcw" | "brickcl" | "brickch" | "brk" | "hold90" | "tap3x" | "taphold" | "rescue" | "hour" | "snap50" | "snap100" | "snap200" | "snap300" | "snaphold" | "x16_50" | "x16_100" | "x16_200" | "x16_300" | "x16hold" | "squeeze" | "reent" | "vine" | "gall" | "gclear" | "dcd" | "new24" | "rt100" | "rt200" | "rt90" | "w5" | "anchor" | "phr" | "rvw" | "snapb" | "cfol" | "ldc1" | "ldc5" | "ldc15" | "ldc2" | "ldc10" | "ldc20" | "ldc30" | "vwap1" | "vwap2" | "vwap5" | "vwap10" | "vwap15" | "vwap30" | "vlc" | "newp" | "diap" | "snpt" | "b11"; at: string; asset: string; side: string; setup: string; multiple: number; stake: number; peakPct: number; exit: string | null; result: string; pnl: number | null; notes?: { worked: string[]; better: string[]; keep: string[] } | null; bankPnl?: number | null; bankExit?: string; stale?: boolean; dnaMode?: "atr" | "free" | "fix"; bell?: string; ticker?: string; soldAt?: string; ask?: number; lonePurple?: boolean; vanBlock?: boolean; insPnl?: number; insNote?: string };

// NIGHT PAPER: the same setups traded two ways on real Kalshi bids while LIVE is off.
const EMPTY_ROWS: ShiftNight[] = [];
function NightCard({ scale = 1, size = 50, whatIf }: { rows?: ShiftNight[]; scale?: number; size?: number; whatIf?: number }) {
  // Every ledger books at Kalshi's $30 ($15 on 3x+) since Oct 8; the cards show it as booked.
  // Love's toggle: every trade re-run with BANK's exits (trailing gate 5% off the high after +30%,
  // band-tap rejection banks, breaks hold). Computed on the server from the real bid paths.
  // LIGHT SHIFT (Oct 17 ~6:30 PM PT, Love: "can you have it only pull up the trades for the cards i actually click on? not load
  // everything else" + "Remove them" for the BANK / 11:55 FIX / DNA x ATR / CLEAN / 2 FEEDS / INSURANCE view toggles). The cards'
  // numbers come counted from the desk (getShiftSummary, same math as before); only the opened card's trades are downloaded.
  const TAPS: ShiftNight["book"][] = ["tap3x", "taphold", "rescue", "snap50", "snap100", "snap200", "snap300", "snaphold", "x16_50", "x16_100", "x16_200", "x16_300", "x16hold"];
  const isTap = (b: string) => (TAPS as string[]).includes(b);
  const [pick, setPick] = useState<ShiftNight["book"] | "all" | "origClean" | "taps">("all");
  const sumQ = useQuery({ queryKey: ["shift-summary"], queryFn: () => getShiftSummary(), refetchInterval: 15000, placeholderData: (prev) => prev });
  const fetchBooks: string[] = pick === "all" ? [] : pick === "taps" || isTap(pick) ? TAPS : pick === "origClean" ? ["original"] : pick === "supernova" ? ["ogp5-fast"] : pick === "recon-fresh" ? ["recon-tog"] : [pick];
  const rowsQ = useQuery({ queryKey: ["shift-rows", fetchBooks.join(",")], queryFn: () => getShiftRows({ data: { books: fetchBooks } }), enabled: fetchBooks.length > 0, refetchInterval: 8000 }); // (Oct 19 ~2:13 PM PT, Love: "have her show the trades she takes on paper on her card here? they don't show immediately") 30 s -> 8 s
  const rowsIn = (fetchBooks.length && rowsQ.data ? rowsQ.data : EMPTY_ROWS) as unknown as ShiftNight[];
  // SUPERNOVA ✨💞 (Oct 17 ~2:51 PM PT): the fast twin's own trades (ogp5-fast) from 10 PM PT Oct 16 on, as their own card.
  const SN_START = "2026-10-17T05:00:00.000Z";
  const RF_START = "2026-10-20T19:59:00.000Z"; // FRESH SLATE (Oct 20 ~2:37 PM PT, Love): TOGETHER since THE WALL AT THE WIRE (12:59 PM PT)
  const rowsSN = useMemo(() => [...rowsIn, ...rowsIn.filter((r) => r.book === "ogp5-fast" && r.at >= SN_START).map((r) => ({ ...r, id: `${r.id}:supernova`, book: "supernova" as ShiftNight["book"] })), ...rowsIn.filter((r) => r.book === "recon-tog" && r.at >= RF_START).map((r) => ({ ...r, id: `${r.id}:recon-fresh`, book: "recon-fresh" as ShiftNight["book"] }))], [rowsIn]);
  const rowsAll = useMemo(
    () => rowsSN.filter((r) => (TAPS as string[]).includes(r.book) || !r.dnaMode).map((r) => ({ ...r, stake: r.stake * scale, pnl: r.pnl == null ? null : r.pnl * scale })),
    [rowsSN, scale],
  );
  // Trades booked while the BTC feed was frozen (OANDA closed for the weekend, Fri 2:00-5:24 PM PT) are
  // listed but never counted: they were decided on a price that wasn't moving.
  const rows = useMemo(() => rowsAll.filter((r) => !r.stale), [rowsAll]);
  // Head to head: every ledger counted from the moment REFINED + GOLDEN started (fair comparison).
  // Seven-ledger start (CLAUDE / OPTION A / OPTION B arrived 8:45 AM PT Oct 2); fall back to REFINED + GOLDEN.
  const firstOf = (books: string[]) => rows.filter((r) => books.includes(r.book)).reduce((m, r) => (r.at < m ? r.at : m), "9999");
  const seven = "2026-10-02T15:45:00.000Z";
  // Ten-ledger start (TREND / BRICK / COTC arrived 10:15 AM PT Oct 2).
  const ten = "2026-10-02T17:15:00.000Z";
  // Oct 12: archiving BRICK / COTC / TREND / CLAUDE took them out of the rows, which used to push this start line up to
  // REFINED's first row still on the page (hours ago) and cut every card's history. The start is fixed now.
  void seven; void firstOf;
  const since = ten;
  const h2h = since !== "9999";
  // 12H / 24H / ALL on every card (Love, Oct 3 ~9 PM PT): one switch, every card's numbers follow it.
  const [span, setSpan] = useState<"4h" | "12h" | "24h" | "all">("all");
  // RUN per book (Love, Oct 5): green = this book sends to Kalshi, red = paper only. First book to fire owns the window.
  const runQ = useQuery({ queryKey: ["run-books"], queryFn: () => getRunBooks(), refetchInterval: 10000 });
  const schedQ = useQuery({ queryKey: ["schedule-pill"], queryFn: () => getSchedule(), refetchInterval: 60000 });
  const archQ = useQuery({ queryKey: ["archived-books"], queryFn: () => getArchived(), refetchInterval: 120000 });
  const [showArch, setShowArch] = useState(false);
  const [runBusy, setRunBusy] = useState<string | null>(null);
  const runOn = (book: string) => (runQ.data?.books ?? []).includes(book);
  const liveQ2 = useQuery({ queryKey: ["live-by-book"], queryFn: () => getLiveByBook(), refetchInterval: 30000 });
  const copyQ = useQuery({ queryKey: ["live-copy-map"], queryFn: () => getLiveCopyMap(), refetchInterval: 30000 });
  // OPEN NOW (Oct 21 ~11:07 AM PT, Love: "i want to see her open trades for the main book / i need to see which positions she is taking"): her main book's
  // and the delayed book's open calls, always loaded (the card lists only load when a card is tapped), on top of RUNNING ON KALSHI - live or paper.
  const openQ = useQuery({ queryKey: ["open-now"], queryFn: () => getShiftRows({ data: { books: ["recon-tog", "recon-dly"] } }), refetchInterval: 5000 });
  const openNow = useMemo(() => ((openQ.data ?? []) as any[]).filter((r) => r.result === "open").sort((a, b) => (a.at < b.at ? 1 : -1)), [openQ.data]);
  const flipAuto = () => {
    const next = !runQ.data?.autoOn;
    void setAutoRoll({ data: { on: next } }).then(() => {
      void runQ.refetch();
      toast(next ? `AUTO ROLL on: the best book of the last ${runQ.data?.autoHours ?? 4}h rides next to yours` : "AUTO ROLL off: only the books you RUN go to Kalshi");
    });
  };
  const flipRun = (book: string) => {
    if (runBusy) return;
    const next = !runOn(book);
    setRunBusy(book);
    void setRunBook({ data: { book, on: next } })
      .then((r) => {
        void runQ.refetch();
        const names = r.books.map((b) => b.toUpperCase()).join(" · ") || "none";
        toast(`${book.toUpperCase()} ${next ? "RUNNING on Kalshi" : "off Kalshi (paper only)"}`, { description: `${r.live ? "Kalshi LIVE is on" : "Kalshi LIVE is off: nothing sends until you turn it on"} · running: ${names}` });
      })
      .catch(() => toast("RUN didn't save, try again"))
      .finally(() => setRunBusy(null));
  };
  // SAVED SETS (Love, Oct 7: "4 Leaf Clover"): tap a set to put exactly its books on RUN; + SAVE keeps the books on RUN now.
  const sameSet = (a: string[], b: string[]) => a.length === b.length && a.every((x) => b.includes(x));
  const useSet = (name: string) => {
    void applyRunPreset({ data: { name } })
      .then((r) => {
        void runQ.refetch();
        toast(`${name} is on`, { description: `running: ${r.books.map((b) => b.toUpperCase()).join(" · ")}${r.live ? "" : " · Kalshi LIVE is off"}` });
      })
      .catch(() => toast("That set didn't load, try again"));
  };
  const flipStep = () => {
    const out = !runQ.data?.stepped;
    if (out && runQ.data && !runQ.data.live) {
      toast("Kalshi LIVE is already off");
      return;
    }
    void stepOut({ data: { out } })
      .then(() => {
        void runQ.refetch();
        toast(out ? "Stepped out 🧘 Kalshi LIVE is off" : "Back in ✨ Kalshi LIVE is on", { description: out ? "Open trades keep their exits. Paper keeps booking, and YOUR CALLS on the DAY tab will show what this call saved or missed." : "Only trades booked from now on go to Kalshi." });
      })
      .catch(() => toast("Didn't save, try again"));
  };
  const saveSet = () => {
    const name = typeof window !== "undefined" ? window.prompt("Name this set of books", "") : null;
    if (!name || !name.trim()) return;
    void saveRunPreset({ data: { name: name.trim() } })
      .then(() => {
        void runQ.refetch();
        toast(`Saved: ${name.trim()}`);
      })
      .catch(() => toast("Didn't save, try again"));
  };
  // 4H added (Love, Oct 5 ~11 PM PT: "could you add a 4 hour button here for the cards")
  const spanFrom = span === "all" ? 0 : Date.now() - (span === "4h" ? 4 : span === "12h" ? 12 : 24) * 3600 * 1000;
  // Card numbers, counted on the desk (LIGHT SHIFT, Oct 17): same rows, same math, no trades downloaded for them.
  void spanFrom;
  const Z_S = { n: 0, open: 0, pnl: 0, wins: 0, losses: 0 };
  const Z_K = { live: 0, held: 0, why: {} as Record<string, { n: number; p: number }>, pnl: 0, wins: 0, losses: 0 };
  const side = (book: ShiftNight["book"]) => sumQ.data?.books?.[book]?.s?.[span] ?? Z_S;
  const kTrue = (book: ShiftNight["book"]) => sumQ.data?.books?.[book]?.k?.[span] ?? Z_K;
  const BOOKS: { book: ShiftNight["book"]; title: string; note: string }[] = [
    { book: "twflush", title: "HER LINEUP 🪞 · LIVE HOURS, NO FLUSH (twin)", note: "Her live setup on paper (her live hours), minus an On-the-line entry at an outer band or pivot (±1.5σ+, S1/S2/R1/R2) right after a one-minute flush into it. Forward test from Oct 12 ~3:20 PM PT. Paper, $20." },
    { book: "twrev2", title: "HER LINEUP 🪞 · REVISED + 8 & 10 AM OFF (twin)", note: "Her live lineup on paper exactly as Kalshi trades it with every book OFF 3–4a, 6–9a, 10–11a, 11a–2p, 7–9p and 10–11p PT (gold also 6 PM). Paper, $20." },
    { book: "twrev", title: "HER LINEUP 🪞 · REVISED HOURS (twin)", note: "Her live lineup on paper exactly as Kalshi trades it, but every book OFF 3–4a, 6–8a, 11a–2p, 7–9p and 10–11p PT (gold also off 6 PM); ON everywhere else. Paper, $20." },
    { book: "twrev5", title: "HER LINEUP 🪞 · REVISED HOURS + $5 SNIPES (twin)", note: "REVISED HOURS, with her under-45c snipes kept at $5 instead of $20. Paper." },
    // NEW 🆕 (Love, Oct 15 ~3:50 PM PT: "put them in the shift tab... a NEW tab for all of our new ones there").
    // First cards on SHIFT so nothing new has to be hunted for.
    { book: "supernova", title: "SUPERNOVA ✨💞", note: "Her clean slate since Claude took over (10 PM PT Oct 16): the fast twin's own trades with every rule built since - the last gate (closest band, breaks, rejections off the pink / session bands / red-green, no band between price and the Kalshi target, at-the-band and pink waits, red/green with the push), carry-over session bands after the 2 PM reset, flip only on direction, half at 75% + trail from 90%, $2 add-on at 2.8x, directional lock. Same trades as 5M FAST, fresh record." },
    { book: "ogp5-r15", title: "SUPERNOVA ✨ + 15% ROOM (paper twin)", note: "Supernova exactly, plus the old room rule: no long/short with an unbroken band within 15% of sigma in front. Since 3:20 PM PT Oct 17." },
    { book: "ogp5-sess", title: "SESSION + PINK ONLY 🌌 · LIVE", note: "Her live book from 6:05 PM PT Oct 17, fresh ledger: session bands (VWAP ±1/2/3σ) + the pink only - no red/green pivot zones. Breaks and rejections, trade away from the band. Every other rule of hers stands." },
    { book: "ogp5-c1", title: "SESSION + PINK · 1M CLOSE ⏱ (paper twin)", note: "Her live session + pink book exactly, but every break or rejection waits for a closed 1-minute candle on the trade's side of the band (through it for a break, back away from it for a rejection). Since 10:50 PM PT Oct 17." },
    { book: "ogp5-c5", title: "SESSION + PINK · 5M CLOSE 🕐 (paper twin)", note: "Her live session + pink book exactly, but every break or rejection waits for the last 5-minute candle to close on the trade's side of the band. Fewer trades, cleaner ones. Since 10:50 PM PT Oct 17." },
    { book: "ogp5-hrs", title: "SESSION + PINK · SITS OUT 2, 4, 8, 9 PM 🕰 (paper twin)", note: "Her live session + pink book exactly, but no trades in the 2, 4, 8 and 9 PM Pacific hours (red on every day they traded last week; 2 PM is the session reset). Since 9:00 AM PT Oct 18." },
    { book: "ogp5-bbsr", title: "SESSION + PINK + BBSR EXTREME 📈 (paper twin)", note: "Her live session + pink book, plus the Bollinger Bands Stochastic RSI Extreme bands (5m, 20, 2.0) as bands to break or reject - no red/green. Never trades against a BBSR triangle from the last 15 minutes. Since 9:25 AM PT Oct 18." },
    { book: "ogp5-dly", title: "DELAYED 🕰 · NEXT BAND AFTER HER OPENING ENTRY · LIVE IN OFF HOURS", note: "Her session + pink brain, but it waits out her opening entry each window, then trades the NEXT band price reaches, normally (break or rejection). Live at $5 only in TOGETHER's off hours (7, 10, 11 AM, 6 PM PT); paper the rest. Since 11:05 AM PT Oct 18." },
    { book: "ogp5-cb", title: "SUPERNOVA ✨ + CLOSEST BAND (paper twin)", note: "Supernova exactly, plus the old closest-band rule: the closest unbroken band decides - closer above = no long, closer below = no short (her 25% rule only refuses the top/bottom quarter). Since 4:30 PM PT Oct 17." },
    { book: "ogp5-r30", title: "SUPERNOVA ✨ + 30% ROOM (paper twin)", note: "Supernova exactly, plus the room rule at 30% of sigma. Since 3:20 PM PT Oct 17." },
    { book: "ogp5-fast", title: "5M FAST OPEN \u26A1 \u00B7 LIVE", note: "Her 5M book, live on Kalshi at $25. Paper fires = Kalshi fires, no entry gates at the door: her laws run in the brain (side of the band at order time, falling away from a band = short, body rule, $2.22 gold room, 1.38x floor, ticket-back). Only her hand-window law (a window her hand traded is hers alone) and one position per window after a fill hold an order back. An open here IS a Kalshi position; a held one shows MISSED with the reason. Hourly audits." },
    { book: "ogp5-boll", title: "NEW 🆕 · 5M FAST · + BOLLINGER BANDS 📊 (paper)", note: "The live fast twin exactly - your BTC band laws and your gold laws - with the 5m Bollinger bands added to the bands she reads, gold and BTC. To see if they do any better. Paper, $20." },
    { book: "ogp5-lock", title: "NEW 🆕 · 5M FAST · 5M CLOSE + SAME-CANDLE LOCK 🔒 (paper)", note: "The live fast twin with the 4:50 AM rules on gold AND BTC: a last-candle break needs a 5m close through the band, and the first break in a 5m candle locks its direction until a fresh candle. To see if it does any better. Paper, $20." },
    { book: "ogp5-btco", title: "NEW 🆕 · 5M FAST · BTC OWN LAWS + ZONES ₿ (paper)", note: "BTC only: her own BTC band laws, plus a red-zone (5m R1/R2) rejection = short, a green-zone (5m S1/S2) rejection = long, and no long at a red-zone band while the 5m candle is falling. Paper, $20." },
    { book: "ogp5-inv", title: "NEW 🆕 · 5M FAST · INVERSE 🔄 (paper)", note: "Takes the opposite of every trade the live fast twin takes - same window, the other side at its own price, same exits. When she's doing bad, this is the book to look at. Paper, $20." },
    { book: "ogp5-gw", title: "NEW 🆕 · 5M FAST · GOLD WAITS A MINUTE ⏳ (paper twin)", note: "The live fast twin exactly, except gold never enters in the first 60 s of a 5m candle: she keeps watching and lets your laws decide once the candle is a minute old. BTC unchanged. Overnight test - if she beats the live twin, it goes live. Paper, $20." },
    { book: "ogp5-pv", title: "NEW 🆕 · 5M PUSH VETO 🛑 (twin)", note: "Her 5M book exactly, but a Bounce/Rejected entry is vetoed while the 3 s tick push is against it. Breaks and On-entries untouched. Paper, $20." },
    { book: "gold-rg", title: "NEW 🆕 · GOLD SHORT RED / BUY GREEN 📍 (paper)", note: "Gold, 5m pivot bands only: any setup at red (R1/R2) is a short, at green (S1/S2) a long; the pink trades only its break or its rejection, her rules. Paper, $20." },
    { book: "recon-fresh", title: "RECONSTRUCTED 🧬 · TOGETHER · FRESH SLATE ✨ (since the wall)", note: "TOGETHER's own trades from 12:59 PM PT Oct 20 only - the moment THE WALL AT THE WIRE went in (no long in the top 33%/20% or short in the bottom 33%/20% of the channel into an unbroken band, sliding by channel width). Nothing from before, so the backwards fires don't muddy her read. Same trades as the TOGETHER card, fresh ledger." },
    { book: "recon-dly", title: "RECONSTRUCTED 🧬 · DELAYED ⏳ · FRESH SLATE ✨ (since 10:30 AM Oct 21)", note: "After TOGETHER enters, every touch of a band (Bollinger upper/lower, session VWAP and sigmas, pink, gold's R/S) is an interaction. The first passes; from the second on she trades the first rejection or break, whichever way it points. Gold also takes the other side at 4x once TOGETHER has been in profit, if no band is within $1.50. Live at $2 in your off hours. Fresh record from 10:30 AM PT Oct 21." },
    { book: "recon-ogp5", title: "RECONSTRUCTED 🧬 · OG × PIVOT 5M (Oct 12)", note: "The book that went 27-2 on Kalshi Mon Oct 12, 6:31-10:15 PM PT, rebuilt line for line from that evening's code (recon.ts, locked): session VWAP + half-sigma bands + the 5m pivot lines from closed bars; a 1m close through a line = trade the break, price on a line = long above / short below; refused only for a line between price and the strike or a centre on the wrong side. No pink wait, no channel rule, no rejection memory, no band lock. Paper $20; TOGETHER carries it live." },
    { book: "recon-paper", title: "RECONSTRUCTED 🧬 · PAPER 24/7 (Oct 12)", note: "PAPER's own setups (tap-rejects, break-retests, opens, gold clock) taken the way the engine took them on Oct 12: her DNA and the VWAP-band-in-the-way check, nothing added since. Paper $20; TOGETHER carries it live." },
    { book: "recon-top", title: "RECONSTRUCTED 🧬 · MOST SUCCESSFUL 70%+", note: "Her bones exactly, but it only takes a setup whose whole-desk record (the shared book file, recent days) is 70%+ over its settled record (any number of trades; a setup that dips under 70% drops off on its own, the list recomputes every 5 minutes) — the MOST SUCCESSFUL list as a filter. Paper $20; skipped setups and why -> data/recon-skips.jsonl. (Love, Oct 19 ~9:02 PM PT)" },
    { book: "recon-all", title: "RECONSTRUCTED 🧬 · TOGETHER · ALL HOURS 🌙 (off hours included)", note: "Every call TOGETHER made, unfiltered: her live hours AND the off hours she sits out on paper while the DELAYED twin trades. Same trades as the TOGETHER card plus the off-hours ones, so you can always see which windows she took. (Love, Oct 21 ~4:25 PM PT)" },
    { book: "recon-tog", title: "RECONSTRUCTED 🧬 · TOGETHER", note: "The two reconstructed books as one: whichever speaks first in a window is the trade. This is the one on Kalshi. Spine lock: data/spine-lock.json - if recon.ts drifts from it, all three stop booking until Love re-signs." },
    { book: "recon-rej", title: "RECONSTRUCTED 🧬 · REJECTIONS ONLY", note: "Her Oct 20 twin: only rejections - shorts off the band above, longs off the band below, candle flips and zone flips included, every break muted. Every trade ends up coming back, most of the time. Paper, same door as her siblings." },
    { book: "brk-sess", title: "NEW 🆕 · BREAK BOOK · SESSION ONLY (paper)", note: "Breaks only: a 1m close or a live $5 / 92c push through a session band, entered in the break's direction; no band between price and the strike. Paper, $20." },
    { book: "brk-sessrj", title: "NEW 🆕 · BREAK BOOK · SESSION + PINK REJECTIONS (paper)", note: "The session-band break book's trades + REJECTIONS off the pink when it has no setup: price taps the pink (BTC $3 / gold 30c) without breaking it and pushes back that far = trade away from it. Paper, $20." },
    { book: "brk-sesspk", title: "NEW 🆕 · BREAK BOOK · SESSION + PINK", note: "The session-band break book's trades + the pink's BREAKS when it has no setup (no rejections; card = all of them, paper $20). Live: only its pink trades go to Kalshi, alongside the session book." },
    { book: "brk5", title: "NEW 🆕 · BREAK BOOK · +5M PIVOTS (paper)", note: "The Break Book with the 5m pivot lines added. Paper, $20." },
    { book: "brk10", title: "NEW 🆕 · BREAK BOOK · +10M PIVOTS (paper)", note: "The Break Book with the 10m pivot lines added. Paper, $20." },
    { book: "brk15", title: "NEW 🆕 · BREAK BOOK · +15M PIVOTS (paper)", note: "The Break Book with the 15m pivot lines added. Paper, $20." },
    { book: "twrevsp5", title: "SESSION + PIVOT 5M · REVISED HOURS (twin)", note: "SP5 on the revised hours. Paper, $20." },
    { book: "twrevogp15", title: "OG 👑 + PIVOT 15M · REVISED HOURS (twin)", note: "OG PIVOT 15M on the revised hours. Paper, $20." },
    { book: "twrevogp5", title: "OG + PIVOT 5M · REVISED HOURS (twin)", note: "OG+PIVOT 5M on the revised hours. Paper, $20." },
    { book: "twclean", title: "HER LINEUP 🪞 · CLEAN (twin)", note: "Her live lineup replayed on paper exactly as Kalshi trades it (each book's off hours, gold off at 6 PM, one per window, $20), minus entries under 45c and minus 'Close through a σ band' setups. Paper." },
    { book: "twtog", title: "TOGETHER 💞 · PAPER 24/7 + 5M PIVOT (twin)", note: "Both books on at once, as the copier runs them: one trade per window per asset, whoever signals first takes it, and when one sits a window out the other can take it. Each book's own off hours, $20 tickets, rebuilt days included." },
    { book: "twhyb", title: "HYBRID ✨ · AS LIVE SINCE THE SWITCH (twin)", note: "Trend Assassin when price is more than 1σ from the session VWAP, both ways with today's rules inside the channel. Since 2:45 AM Oct 13, her off hours, one per window, $20. Compare with TREND ASSASSIN and BOTH WAYS." },
    { book: "twtrend", title: "TREND ASSASSIN 🗡️ · ALL DAY YESTERDAY → NOW (twin)", note: "The model she ran all day Oct 12, exactly as Kalshi traded it until the switch at 2:45 AM Oct 13, then the same model on paper. Her off hours, one per window, $20." },
    { book: "twlive", title: "HER LINEUP 🪞 · AS LIVE (twin)", note: "Her live lineup replayed on paper exactly as Kalshi trades it: off hours, gold off at 6 PM, one per window, $20. The yardstick for the others. Paper." },
    { book: "twbtc", title: "HER LINEUP 🪞 · BTC ONLY (twin)", note: "The AS LIVE twin's BTC trades only. Paper." },
    { book: "twgold", title: "HER LINEUP 🪞 · GOLD ONLY (twin)", note: "The AS LIVE twin's gold trades only. Paper." },
    { book: "twno45", title: "HER LINEUP 🪞 · NO ENTRIES UNDER 45c (twin)", note: "AS LIVE minus entries under 45c (when one is skipped, the next book's call can take the window). Paper." },
    { book: "twnocs", title: "HER LINEUP 🪞 · NO CLOSE-THROUGH-σ (twin)", note: "AS LIVE minus 'Close above/below a σ band' setups. Paper." },
    { book: "twsp5b", title: "SESSION + PIVOT 5M · BTC ONLY (twin)", note: "SP5 on BTC only, in its live hours. Paper." },
    { book: "twogp15b", title: "OG 👑 + PIVOT 15M · BTC ONLY (twin)", note: "OG PIVOT 15M on BTC only, in its live hours. Paper." },
    { book: "twogp5b", title: "OG + PIVOT 5M · BTC ONLY (twin)", note: "OG+PIVOT 5M on BTC only, in its live hours. Paper." },
    { book: "ogg", title: "OG 👑 · OCT 1 FEED", note: "Grok's original prime book, reanimated (Oct 11): price on/near a band = in instantly (over it long, under it short), or a 1m close through one; no band between price and the strike; 1.38x+, no cap; Grok's own gate exits. On the exact Oct 1 chart (OANDA BTC 5m, session from 5 PM PT). Paper, $20." },
    { book: "oghb", title: "OG 👑 🏦 BANK · YOUR BANDS", note: "OG · YOUR BANDS' exact entries with a bank exit: once a trade has been +35% the floor is +25%, and every 5% more of best gain lifts the floor 5%. Gain back at the floor = sold. Otherwise the bell. Paper, $20." },
    { book: "oggb", title: "OG 👑 🏦 BANK · OCT 1 FEED", note: "OG · OCT 1 FEED's entries with the bank exit (arm +35%, floor +25%, floor up 5% per 5%)." },
    { book: "ogp2b", title: "OG 👑 + PIVOT 🏦 BANK · 2M", note: "OG + PIVOT 2M's entries with the bank exit." },
    { book: "ogp5b", title: "OG 👑 + PIVOT 🏦 BANK · 5M", note: "OG + PIVOT 5M's entries with the bank exit." },
    { book: "ogp10b", title: "OG 👑 + PIVOT 🏦 BANK · 10M", note: "OG + PIVOT 10M's entries with the bank exit." },
    { book: "ogp15b", title: "OG 👑 + PIVOT 🏦 BANK · 15M", note: "OG + PIVOT 15M's entries with the bank exit." },
    { book: "ogp2", title: "OG 👑 + PIVOT · 2M", note: "The OG exactly on your session bands, with the 2m CM pivot lines added under the same rules: on a line = in instantly (over long, under short), 1m close through one = the break; no line of either kind between price and the strike; 1.38x+, no cap; Grok gate exits. Paper, $20." },
    { book: "ogp5", title: "OG 👑 + PIVOT · 5M", note: "The OG + your session bands + 5m pivot lines." },
    { book: "ogp10", title: "OG 👑 + PIVOT · 10M", note: "The OG + your session bands + 10m pivot lines." },
    { book: "ogp15", title: "OG 👑 + PIVOT · 15M", note: "The OG + your session bands + 15m pivot lines." },
    { book: "ogh", title: "OG 👑 · YOUR BANDS", note: "The same OG rules on today's session bands. Paper, $20." },
    { book: "grokb", title: "GROK BUILDER", note: "Grok's setup builder exactly (desk-project 2), on the Oct 1 feed, nothing added on top. Grok's gate exits. Paper, $20." },
    { book: "pap247", title: "PAPER · 24/7", note: "The original PAPER book's own trades, every hour, every asset, at $25 tickets. Confirms she's the same." },
    { book: "papbest", title: "PAPER · HER BEST HOURS", note: "PAPER's own trades only at 3 AM, 11 AM, 3 PM, 7 PM, 8 PM, 10 PM PT (green in both halves of Oct 2-11), no silver, $25." },
    { book: "pap20", title: "PAPER · 20% ROAD", note: "PAPER's own trades plus the ones her $40 band rule benched, taken while price is under 80% of the way through the channel (band ahead more than 20% of the gap away). Same side she chose, never flipped. $25." },
    { book: "papwin", title: "PAPER · WINNING SETUPS", note: "PAPER's own trades, only the setups green on both PAPER and PRIME: BTC short off +1.5σ, BTC short off -0.5σ, BTC long off -0.5σ. $25." },
    { book: "piv2", title: "PIVOT 📐 · 2M", note: "CM Pivot Bands (EMA7 pivot ± 7-bar range) on 2m: on a line = in (over long, under short), or a 1m close through one; no pivot line between price and the strike; 1.38-5x. Grok gate exits. Paper, $20." },
    { book: "piv5", title: "PIVOT 📐 · 5M", note: "Same, 5m pivot bands." },
    { book: "piv10", title: "PIVOT 📐 · 10M", note: "Same, 10m pivot bands." },
    { book: "piv15", title: "PIVOT 📐 · 15M", note: "Same, 15m pivot bands." },
    { book: "sp2", title: "SESSION + PIVOT · 2M", note: "2m pivot lines plus her session bands, OG entries, no line of either kind between price and the strike. Paper, $20." },
    { book: "sp5", title: "SESSION + PIVOT · 5M", note: "5m pivot lines plus her session bands." },
    { book: "sp10", title: "SESSION + PIVOT · 10M", note: "10m pivot lines plus her session bands." },
    { book: "sp15", title: "SESSION + PIVOT · 15M", note: "15m pivot lines plus her session bands." },
    { book: "brnw", title: "BRICK · NO PIVOT WALL", note: "BRICK's own paper trades minus any with a 5m pivot line between price and the strike (lab: those won 53% for -$98)." },
    { book: "sqnw", title: "SQUEEZE · NO PIVOT WALL", note: "SQUEEZE's own paper trades minus any with a 5m pivot line between price and the strike." },
    { book: "bank", title: "BANK ⛨", note: "ORIGINAL's DNA-clean entries with her banking exits: after +30%, sells 5% off the highest bid; taps a band and the 1m candle rejects = banks it, breaks through = holds. Never sells at a loss." },
    { book: "hour", title: "BTC HOURLY ⏱", note: "Kalshi's hourly BTC ladder, strike nearest price. Enters when a closed 5m candle rejects or breaks her 1-hour nav band (purple / upper / lower), with her DNA. Hard take profit, else the hour's result. (Kalshi has no hourly gold.)" },
    { book: "tap3x", title: "TAP 3x · $2.50", note: "No position needed: price touches one of her lines and the bounce side is 10x+. A $2.50 ticket, sells at +200%." },
    { book: "taphold", title: "TAP HOLD · $2.50", note: "Same $2.50 band-touch tickets, held to the bell. The replay liked this on BTC (rare 20-100x hits paid for the misses) and not on gold." },
    { book: "snap50", title: "SNAP +50% · $5", note: "Price hits one of her lines and rejects hard (0.15σ back off it); the snap side costs 4x+. A $5 ticket that sells at +50%." },
    { book: "snap100", title: "SNAP +100% · $5", note: "Same band-rejection tickets at 4x+, sells at +100%." },
    { book: "snap200", title: "SNAP +200% · $5", note: "Same band-rejection tickets at 4x+, sells at +200%." },
    { book: "snap300", title: "SNAP +300% · $5", note: "Same band-rejection tickets at 4x+, sells at +300%." },
    { book: "snaphold", title: "SNAP HOLD · $5", note: "Same band-rejection tickets at 4x+, held to the bell. The yardstick for the four take profits." },
    { book: "x16_50", title: "SNAP 16x +50% · $20", note: "A hard band rejection when the snap side costs 6.25c or less (16x+). $20, sells at +50%." },
    { book: "x16_100", title: "SNAP 16x +100% · $20", note: "Same 16x band-rejection tickets, $20, sells at +100%." },
    { book: "x16_200", title: "SNAP 16x +200% · $20", note: "Same 16x band-rejection tickets, $20, sells at +200%." },
    { book: "x16_300", title: "SNAP 16x +300% · $20", note: "Same 16x band-rejection tickets, $20, sells at +300%." },
    { book: "x16hold", title: "SNAP 16x HOLD · $20", note: "Same 16x tickets held to the bell. The yardstick." },
    { book: "rescue", title: "RESCUE · $5 ADD", note: "One of ORIGINAL's trades turns against her, her side gets to 4x+ and price pushes into one of her lines: a $5 add on the same side, held to the bell." },
    { book: "brk", title: "BREAK ⚡ · 24H TEST", note: "Every entry any ledger takes (first one per window). Out the moment the line she entered on breaks with a strong push (1m close through by BTC $20 / gold $0.40, or two closes through). Otherwise a hard take profit." },
    { book: "hold90", title: "HOLD 90 ✦", note: "ORIGINAL's entries, hard take profit. A clear winner (past the strike by BTC $100 / gold $1.50, no line in between) rides for 90% of the max, backstopped at the take-profit line." },
    { book: "bank2", title: "BANK 2 ⛨", note: "Same entries as BANK, gentler bank from the lab: arms at +30% → +40%, gives back 10% of the peak instead of 5%, no band-tap. Being tuned this week." },
    { book: "sole5", title: "5M · SOLE", note: "Every desk setup, judged ONLY by the session bands + the 5m nav (purple, upper, lower): never in the 25% of the channel closest to the line in front. 1.38x+." },
    { book: "squeeze", title: "SQUEEZE ◫ · TWIN", note: "The live books trade for trade, except a bounce boxed in a squeeze (pocket under 0.6 of a 5m candle, or 2+ lines stacked right in front): she waits and trades whichever line a 1-minute candle closes through. Paper; side-by-side test this week." },
    { book: "brickc", title: "BRICK · CLEAN", note: "BRICK exactly, minus her rejections off a nav purple that stands alone. A purple rejection only counts when a session band (VWAP or σ) sits right on it (within 0.08σ, about $4 on BTC)." },
    { book: "brickt", title: "BRICK · TVC GOLD", note: "BRICK's gold logic read from TVC:GOLD. Since Oct 6 ~7:30 AM PT the whole desk reads gold from TVC (Love: \"CHANGE GOLD TO TVC\"), so this now fires with BRICK on gold, most often the same second. Live on Kalshi when its RUN is on." },
    { book: "brickp", title: "BRICK · PUSH", note: "BRICK, but she waits to see how price behaves at the purple (Love, Oct 6 night). A break through a purple or a 5m rejection: in at once. Any other BRICK signal with an unbroken purple just in front (within 0.5 sd): she watches it. A 1m close through it = in with the break; a tap then a 1m close back off it = in on the rejection; neither before the last 2 minutes = no trade. Every BRICK gate re-checked at entry, BRICK's exits. Paper." },
    { book: "bricks", title: "BRICK · SESSION", note: "Claude's pick from the loss lab (Oct 7): BRICK's signals off her SESSION bands only (VWAP and the sigma bands), nothing off the purples or nav bands. Session-band breaks were the best setup across 1,211 paper trades and held up in both halves. Same gates, BRICK's exits. Paper." },
    { book: "brickcr", title: "BRICK · CLEAN · RIDE", note: "BRICK · CLEAN's exact entries with no take-profit gate and no lock the win (Love, Oct 7): 90% of the max then the 1% trail, or the bell. Lab: riding past the gates and locks cost $2,064 on paper over 409 early exits (149 of them lost at the bell). Watching it live. Paper." },
    { book: "brickc75", title: "BRICK · CLEAN · 75%", note: "BRICK · CLEAN's exact entries and exits plus a hard take profit at 75% of the max (Love, Oct 7: \"can we try taking 75% of whats available?\"). Lab: -$973 on paper vs now, because the trades that run to 90%+ get capped. Watching it live. Paper." },
    { book: "brickcf", title: "BRICK · CLEAN · AFTER FEES", note: "BRICK · CLEAN exactly as the desk trades it now (buys at the ask, sells into the bid), with Kalshi's fees taken out: 7% x contracts x price x (1 - price) per fill. The yardstick for MAKER. Paper." },
    { book: "brickcm", title: "BRICK · CLEAN · MAKER", note: "BRICK · CLEAN, but she prices her own entry (Love, Oct 7: \"can she price them to get in at the best multiple she can?\"): a resting buy at the BID the moment the signal fires, which pays no fee and a better multiple. If the ask doesn't come down to it in 45 s, she buys at the ask then (fee) if it's still 1.37x+. Fees taken out, so compare with AFTER FEES. Paper." },
    { book: "brickcpt", title: "BRICK · CLEAN · PATIENT", note: "BRICK · CLEAN exactly, except she won't take an early exit (gate or lock the win) while price is moderately past the strike: gold $0.50-$1.50, BTC $25-$50. In the exit lab those were the early exits that would have paid more riding (+$1,600 over 499 exits). A few weeks on paper first (Love, Oct 7)." },
    { book: "brickcx", title: "BRICK · CLEAN · CUT 2 BANDS", note: "Love's cut-loss rule (Oct 7): BRICK · CLEAN, plus out if a 1-minute candle closes back through the line she entered on AND the next of her lines beyond it, while the bid still pays back at least half the stake. A week on paper next to the live books." },
    { book: "brickcw", title: "BRICK · CLEAN · CUT WALL", note: "Claude's cut-loss rule (Oct 7): BRICK · CLEAN, plus out if price is on the losing side of the strike and one of her unbroken lines now stands between price and the strike (her own entry rule turned into an exit), 2+ minutes in, while the bid still pays back 35%+. Paper." },
    { book: "brickcl", title: "BRICK · CLEAN · CUT LATE", note: "Claude's cut-loss rule (Oct 7): BRICK · CLEAN, plus out with 5 minutes or less left when price is on the losing side of the strike by gold $1 / BTC $50+, while the bid still pays back half the stake. Paper." },
    { book: "brickch", title: "BRICK · CLEAN · HALF AT 75%", note: "Love's scale-out (Oct 7): BRICK · CLEAN, but the first time the bid reaches 75% of the max, half is sold right there; the other half keeps every rule (take profit, gates, lock the win, the bell). Lab: helps the trades that end on a gate (+$155 gold / +$324 BTC) but costs overall (-$400 gold / -$45 BTC) by halving the full winners. Watching it live. Paper." },
    { book: "vine", title: "VINE ✨", note: "Love's hand-picked setups (Oct 8): only the 23 asset + side + setup combos from her SETUPS board, nothing else (Tap-reject at -0.5σ BTC down/up, Open -0.5σ gold up, Break-retest through +1σ gold up, Gold clock up, Tap-reject at -1.5σ gold up/down and BTC down, Fade off -1σ gold up, Tap-reject at -1σ gold up, +1.5σ BTC down, Close above +1σ BTC up, +2σ gold up, Close above +0.5σ gold up, +1σ BTC up/down, Break-retest through -1σ BTC down, +3σ and +2.5σ BTC up, Open -1σ BTC up and gold up). One trade per window, 1.38x+, NEW's exits. Silver ones wait for a silver lane. Paper." },
    { book: "anchor", title: "ANCHOR ⚓", note: "Claude's pick (Oct 8): only the two setups that won in BOTH records we have (this week's paper and the older hit book): BTC short tap-reject at +1.5σ (12/14 and 12-3) and gold short tap-reject at -1.5σ (18/24 and 19-8). Every other 'best' setup flipped between the two. Rare, on purpose. Paper." },
    { book: "rvw", title: "REVERSAL · WORST HOURS", note: "Love's idea (Oct 8): BTC only, only in the hours PRIME HOURS skips (the ones that lost money this week). Waits for price to break through one session line and tap the next, then takes the reversal back the other way at 1.38x+. $30, usual exits. Paper." },
    { book: "snapb", title: "SNAPBACK", note: "The data's answer to Love's candle idea (Oct 8): gold + silver only. When the last 15m window was already decided with 5 minutes left (95c+ either way), she takes the OTHER side at minute 1-2 (30-70c), $30, held to the bell. Look-back Sep 21 - Oct 8: right 56% gold / 58% silver, about +$1,480 together." },
    { book: "snpt", title: "SNAPBACK · TVC LINES", note: "SNAPBACK's twin on TVC's lines (Love, Oct 9: 'snapback set on the chart that respects lines best'). TVC:SILVER held 64% of line touches vs 50-54% on every other silver feed. Same trade, gold + silver, only when TVC shows price tagged a line in the decided candle's direction and closed back, and it isn't stretched 1 sigma+ past VWAP. Look-back Sep 21 - Oct 9: silver 67% (67 trades, +$565), gold 62.5% (80, +$500). Paper only." },
    { book: "b11", title: "BRICK 1:1 · REAL", note: "Love's 'what if she fired together' test, priced like Kalshi really would (Oct 9). Every BRICK trade copied the instant it books, no band waits, $22. Entry walks Kalshi's real order book up to the live limit (never past 72c); if nobody sells there it's a NO FILL. Exits sell into the real bids with the taker fee; the bell pays $1/$0 with no fee. Paper only." },
    { book: "cfol", title: "CANDLE FOLLOW", note: "Love's candle idea as she said it (Oct 8): BTC, gold and silver. When the last 15m window was already decided with 5 minutes left, she follows it into the next window at minute 1-2 (30-70c), $30, held to the bell. Look-back said it loses (42-49% right); running so we can watch it live next to SNAPBACK." },
    { book: "ldc1", title: "LDC · 1M", note: "Love's LDC (Oct 8), straight from her TradingView alerts by webhook. Fires on the 1M Buy/Sell: Buy = up, Sell = down, on the current Kalshi window, $30, normal exits, one per window, 2+ min left, side at 30-73c." },
    { book: "ldc5", title: "LDC · 5M", note: "Love's LDC on the 5M chart, its own book. Same rules as LDC 1M: webhook signal, current window, $30, normal exits, one per window." },
    { book: "ldc15", title: "LDC · 15M", note: "Love's LDC on the 15M chart, its own book. Same rules as LDC 1M: webhook signal, current window, $30, normal exits, one per window." },
    { book: "ldc2", title: "LDC · 2M", note: "Love's LDC on the 2M chart (Oct 8), its own book: webhook signal, current Kalshi window, $30, normal exits, one per window, 2+ min left, side at 30-73c." },
    { book: "ldc10", title: "LDC · 10M", note: "Love's LDC on the 10M chart, her middle ground: webhook signal, current Kalshi window, $30, normal exits, one per window, 2+ min left, side at 30-73c." },
    { book: "ldc20", title: "LDC · 20M", note: "Love's LDC on the 20M chart: webhook signal, current Kalshi window, $30, normal exits, one per window, 2+ min left, side at 30-73c." },
    { book: "ldc30", title: "LDC · 30M", note: "Love's LDC on the 30M chart: webhook signal, current Kalshi window, $30, normal exits, one per window, 2+ min left, side at 30-73c." },
    { book: "vwap1", title: "VWAP SIGNAL · 1M", note: "Her Nav Band script's own VWAP Long/Short signal on the 1M: webhook signal, current Kalshi window, $30, normal exits, one per window, 2+ min left, side at 30-73c." },
    { book: "vwap2", title: "VWAP SIGNAL · 2M", note: "Her Nav Band script's own VWAP Long/Short signal on the 2M: webhook signal, current Kalshi window, $30, normal exits, one per window, 2+ min left, side at 30-73c." },
    { book: "vwap5", title: "VWAP SIGNAL · 5M", note: "Her Nav Band script's own VWAP Long/Short signal on the 5M: webhook signal, current Kalshi window, $30, normal exits, one per window, 2+ min left, side at 30-73c." },
    { book: "vwap10", title: "VWAP SIGNAL · 10M", note: "Her Nav Band script's own VWAP Long/Short signal on the 10M: webhook signal, current Kalshi window, $30, normal exits, one per window, 2+ min left, side at 30-73c." },
    { book: "vwap15", title: "VWAP SIGNAL · 15M", note: "Her Nav Band script's own VWAP Long/Short signal on the 15M: webhook signal, current Kalshi window, $30, normal exits, one per window, 2+ min left, side at 30-73c." },
    { book: "vwap30", title: "VWAP SIGNAL · 30M", note: "Her Nav Band script's own VWAP Long/Short signal on the 30M: webhook signal, current Kalshi window, $30, normal exits, one per window, 2+ min left, side at 30-73c." },
    { book: "vlc", title: "VWAP + LDC", note: "Love's 8 PM gold short, as a book (Oct 8): books the window when a VWAP signal and an LDC signal agree on the same asset and side within 15 minutes (any of her timeframes). $30, normal exits, one per window." },
    { book: "newp", title: "NEW · PATIENT", note: "NEW's exact trades, but she rests a buy 4c under NEW's price for up to 4 minutes instead of paying the ask, and skips the trade if price never comes back. No entry fee. Same exits. The test of entering cheaper (Oct 9)." },
    { book: "diap", title: "DIAMOND · PATIENT", note: "DIAMOND's exact trades, resting 4c under for up to 4 minutes, skipping if never filled. No entry fee. Same exits." },
    { book: "phr", title: "PRIME HOURS", note: "Love's idea (Oct 8): NEW · 24/7's rules, skipping any hour where every-setup paper lost money over the last 7 days (8+ trades). The hour list refreshes itself every 30 minutes. Paper." },
    { book: "w5", title: "WAIT 5", note: "Love's idea (Oct 8): her RUN books' trades, but only the first one that fires 5+ minutes into the window, so price shows its hand first. Compare with COMBINED · PRIME on the DAY tab. Paper." },
    { book: "rt100", title: "RIP & TAP · +100%", note: "Love's idea (Oct 8): gold and silver break through one session line and tap the next in the same window; the side paying 4x+ is taken at $10. Sells at +100%, otherwise the bell. Twins: +200% and 90% of the max. Paper." },
    { book: "rt200", title: "RIP & TAP · +200%", note: "Same RIP & TAP entries ($10, 4x+), sells at +200%, otherwise the bell. Paper." },
    { book: "rt90", title: "RIP & TAP · 90% OF MAX", note: "Same RIP & TAP entries ($10, 4x+), sells at 90% of what the trade can pay, otherwise the bell. Paper." },
    { book: "new24", title: "NEW · 24/7", note: "NEW exactly, with her off-hours lifted (Love, Oct 8): same setups, same 25% channel rule, same clear-road and 1.38x checks, same exits, every hour. Compare with NEW to see what her off-hours have been saving or costing. Paper." },
    { book: "dcd", title: "DECIDED", note: "Love's idea (Oct 8): buy the side that has already made its decision. BTC already $125 past the strike, gold $3, still paying 1.28x or more, no band in front (BTC: none of her lines within $30 ahead; gold: no nav band within $0.50). One per window per asset, 2+ minutes left, same exits as the others. Less profit, fewer losers? Paper." },
    { book: "gclear", title: "GOLD · CLEAR $1.50", note: "Love's test (Oct 8): her live books' gold trades (one per window, the first RUN book to fire), skipping any with a session or nav line within $1.50 of the strike. Compare with GOLD · ALL (the same trades, none skipped) over the week. Paper." },
    { book: "gall", title: "GOLD · ALL", note: "The baseline for GOLD · CLEAR $1.50: every gold trade her live books take (one per window, first RUN book to fire), copied at the same entry with the same exits. Paper." },
    { book: "reent", title: "BTC RE-ENTRY", note: "Love's idea (Oct 8): when last window's live-book trade left early on LOCK THE WIN or a GATE, she takes the same side again in the first 2 minutes of the next BTC window, normal exits. Lab: BTC 57% next-window follow-through (+$275 on 153 at $30 after fees); gold 48% (-$419), so BTC only. Paper." },
    { book: "bank5px", title: "BANK SOLE+ · 5M CLOSE EXIT", note: "BANK · 5M SOLE+ exactly plus Love's exit: the first 5-minute close on the far side of the line she entered on = out, win or lose. The backtest liked it in every version (+$2 to +$85 on $50 stakes)." },
    { book: "claudex", title: "CLAUDE · 5M CLOSE EXIT", note: "CLAUDE exactly plus Love's exit: the first 5-minute close on the far side of the line she entered on = out, win or lose. The backtest liked this one (+$78 to +$120 on $50 stakes)." },
    { book: "trendx", title: "TREND · 5M CLOSE EXIT", note: "CLAUDE · TREND exactly plus Love's exit: the first 5-minute close on the far side of the line she entered on = out, win or lose. The backtest liked this one most (+$81 to +$291 on $50 stakes)." },
    { book: "bank5p", title: "BANK · 5M SOLE+ ⛨", note: "5M SOLE+'s exact entries with BANK's exits: after +30% she sells 5% off the highest bid; a band tap the 1m candle rejects banks it (in profit only). Built to get out before the L. Paper, started Oct 5 ~1 AM." },
    { book: "sole5p", title: "5M · SOLE+", note: "5M SOLE's rules exactly, judging the desk's setups AND BRICK's own signals. If SOLE's rules work as a filter, this keeps BRICK's good calls and drops the wrong-side ones. 1.38x+, no gates or locks." },
    { book: "sole5z", title: "5M · SOLE ZONE", note: "5M SOLE plus Love's lined-up rule: where a session band and a 5m nav line sit together (within 0.08σ, about $4 on BTC), she won't trade into that zone or from inside it until price breaks through all of it." },
    { book: "sole5v", title: "5M · SOLE · VANTAGE", note: "5M SOLE's exact rules judged on Vantage's bands and price instead of Pepperstone's (BTC). Gold uses the desk's own lines." },
    { book: "sole10", title: "10M · SOLE", note: "The same, judged ONLY by the session bands + the 10m nav. The middle point." },
    { book: "sole15", title: "15M · SOLE", note: "The same, judged ONLY by the session bands + the 15m nav." },
    { book: "lastmin", title: "LAST MINUTE ⏳", note: "The last 5 minutes of a window: price on the right side of the strike and that side still pays 1.32x-1.5x. Only when her lines agree: right side of the session VWAP, not in the 25% of the channel by the line in front (session + 5m nav), and far enough past the strike for the time left. Secures the take profit, else the bell." },
    { book: "lastgrant", title: "LAST MINUTE · YOU + GRANT", note: "Your and Grant's rule: 3 minutes or less left, BTC $110+ past the strike, gold $3+ past it with none of her lines between the strike and price (or within $1.50). 1.32x+. Same take profit, else the bell." },
    { book: "confirm", title: "CONFIRM ⇄ · BTC", note: "Love's hunch: a band break on Pepperstone or Vantage, entered only when the OTHER feed breaks the same line the same way within 60 seconds. Her 25% channel rule, 1.38x+." },
    { book: "brk1", title: "FIRST BREAK · BTC", note: "The control: enters the moment either feed breaks one of her lines, no confirmation. Same rules. If CONFIRM beats this, your hunch is right." },
    { book: "diamond", title: "DIAMOND ◆", note: "Her best stretches, reinforced: already through the strike (nothing between her and it), no purple/Bollinger right in front, bands open (BTC σ ≥ $150, gold ≥ $5), no 2–7 PM PT chop." },
    { book: "brick", title: "BRICK ▣", note: "Entry logic rewritten from scratch by Claude. A closed 5m candle rejects or breaks one of her lines; the road to the strike must be clear of every band and nav line, and nothing sits right in front (BTC: purple/Bollinger $100, bands $25 · gold $0.75–2.50)." },
    { book: "cotc", title: "C O T C ♛", note: "Cream of the crop: only the 8 setups that won 75%+ over 15+ trades. Gold long taps at −1.5σ / −2σ / +1.5σ, gold Open −0.5σ, gold retests, BTC short taps at +1σ / +1.5σ, BTC close above +1σ." },
    { book: "trend", title: "CLAUDE · TREND", note: "CLAUDE, but gold follows the trend: under the session VWAP and the 15m purple = shorts only; above both = longs only." },
    { book: "claude", title: "CLAUDE ✦", note: "Claude's pick: gold longs (taps, retests, clock, nav close), BTC short taps, BTC close-above longs. Nav + path guards, her worst hours, no-loss gates." },
    { book: "golden", title: "GOLDEN · OCT 1 12:45–3:30", note: "Her Oct 1 afternoon model on its own feeds (BTC session from 5 PM PT, gold bands on 15m, her TP table) — and since 3:02 PM, her true DNA." },
    { book: "optA", title: "OPTION A", note: "NEW, but BTC entries read the 5 PM-start bands. Her 2 PM bands still run nav / path / hour rules." },
    { book: "optB", title: "OPTION B", note: "NEW, but no BTC entries 2:00–3:59 PM PT, right after the session reset." },
    { book: "refined", title: "REFINED", note: "NEW + morning fixes: no BTC purple-close entries, a gate or lock never sells under breakeven after a gap." },
    { book: "new", title: "NEW", note: "Every rule tonight. Nav skip + nav-close entries, worst hours, TP 50/75% of max, LOCK THE WIN." },
    { book: "original", title: "ORIGINAL", note: "Her table 33/44/50/60/max−15, no hours, no lock. Carries her DNA since 11:55 AM: never a line right in front, never a line between her and the strike." },
  ];
  // TAPS live in their own tab (Love: "not the vibe" to have $2.50 lotto tickets paint the whole ledger red).
  const archSet = new Set<string>(((archQ.data as string[] | undefined) ?? []).filter((b) => !runOn(b as ShiftNight["book"])));
  const ranked = BOOKS.filter((b) => !isTap(b.book) && (b.book === "recon-fresh" || !archSet.has(b.book))).map((b) => ({ ...b, s: side(b.book) })).sort((a, b) => b.s.pnl - a.s.pnl);
  const tapRanked = BOOKS.filter((b) => isTap(b.book)).map((b) => ({ ...b, s: side(b.book) })).sort((a, b) => b.s.pnl - a.s.pnl);
  // CARD TAPS (Oct 13 ~3:25 AM PT, Love: "when i click one it takes a few seconds to open and then i think my click didn't
  // register... when i click again... the second click closes it"). The card says OPENING… the instant it's tapped; taps
  // are ignored while it opens, and for 2.5 s after it opens a tap can't close it.
  const [opening, setOpening] = useState<string | null>(null);
  const openedAtRef = useRef(0);
  useEffect(() => { openedAtRef.current = Date.now(); setOpening(null); }, [pick]);
  useEffect(() => { if (!opening) return; const id = setTimeout(() => setOpening(null), 6000); return () => clearTimeout(id); }, [opening]);
  // DIAMOND classic vs DIAMOND on her 25% logic, toggled inside the DIAMOND card (Love, Oct 3 ~1:30 AM PT).
  const [dFlavor, setDFlavor] = useState<"diamond" | "diamond25">("diamond");
  // ORIGINAL without her band errors (Love: "that's what she looks like"): every ORIGINAL trade whose
  // own review says she entered with a line right above a long / right below a short is set aside.
  const bandErr = (r: ShiftNight) => (r.notes?.better ?? []).some((t) => /right (above|below) her/.test(t));
  const Z_O = { n: 0, pnl: 0, wins: 0, losses: 0 };
  const clean = sumQ.data?.orig?.clean ?? Z_O;
  const errs = sumQ.data?.orig?.errs ?? Z_O;
  const allO = sumQ.data?.orig?.allO ?? Z_O;
  const [limit, setLimit] = useState(40);
  // FAMILIES + FIND (Love, Oct 9 ~4:20 PM PT: "where is bank sole? i can't find any of these, we really need to group them
  // together"). Chips filter the ranked tiers to one family; the find box matches a book's name or card title.
  const [fam, setFam] = useState<string>("ALL");
  const [findQ, setFindQ] = useState("");
  const FAMS: [string, (b: string) => boolean][] = [
    // NEW ONES (Love, Oct 15 ~3:30 PM PT: "place the ones we have running under one roof... make a new tab for NEW ONES").
    // First in the list so these cards live here even when another family's pattern would also match them.
    ["RECONSTRUCTED 🧬", (b) => ["recon-fresh", "recon-all", "recon-dly", "recon-ogp5", "recon-paper", "recon-tog", "recon-top", "recon-rej"].includes(b)],
    ["NEW ONES 🆕", (b) => ["ogp5-sess", "ogp5-c1", "ogp5-c5", "ogp5-hrs", "ogp5-bbsr", "ogp5-dly", "supernova", "ogp5-r15", "ogp5-r30", "ogp5-cb", "ogp5-fast", "ogp5-gw", "ogp5-inv", "ogp5-boll", "ogp5-lock", "ogp5-btco", "ogp5-pv", "brk-sess", "brk-sesspk", "brk-sessrj", "brk5", "brk10", "brk15", "gold-rg"].includes(b)],
    ["HER LINEUP 🪞 TWINS", (b) => /^tw/.test(b) && b !== "twtog"],
    ["BRICK", (b) => /^brick/.test(b) || b === "b11"],
    ["NEW · REFINED · ORIGINAL", (b) => ["new", "new24", "newp", "refined", "original", "golden", "optA", "optB", "hold90", "bank", "bank2", "w5", "phr", "anchor"].includes(b)],
    ["SOLE · BANK SOLE+", (b) => /^sole/.test(b) || b === "bank5p" || b === "bank5px"],
    ["CLAUDE · COTC · DIAMOND", (b) => ["claude", "claudex", "trend", "trendx", "cotc", "diamond", "diamond25", "diap", "vine", "confirm", "brk1", "brk"].includes(b)],
    ["SNAP · CANDLE · RIP", (b) => ["snapb", "snpt", "cfol", "rvw", "rt100", "rt200", "rt90", "reent", "squeeze"].includes(b)],
    ["LDC · VWAP", (b) => /^ldc|^vwap/.test(b) || b === "vlc"],
    ["DECIDED · GOLD", (b) => ["dcd", "gall", "gclear"].includes(b)],
    ["OG 👑 · PIVOT 📐 · PAPER", (b) => ["twtog", "ogg", "ogh", "oggb", "oghb", "grokb", "pap247", "papbest", "papwin", "pap20", "brnw", "sqnw"].includes(b) || /^piv|^sp\d|^ogp/.test(b)],
  ];
  const famOf = (b: string) => (FAMS.find(([, f]) => f(b)) || ["OTHER"])[0];
  const famOk = (b: { book: string; title: string }) => {
    const q = findQ.trim().toLowerCase();
    if (q) return `${b.book} ${b.title} ${LABEL[b.book] || ""}`.toLowerCase().includes(q);
    return fam === "ALL" || famOf(b.book) === fam;
  };
  const LABEL: Record<string, string> = { twtog: "TOGETHER 💞", twhyb: "HYBRID ✨", twtrend: "TREND ASSASSIN 🗡️", twflush: "TWIN NO FLUSH", twrev2: "TWIN REV + 8/10 OFF", twrev: "TWIN REVISED HRS", twrev5: "TWIN REV + $5 SNIPES", twrevsp5: "SP5 REV HRS", twrevogp15: "OGP15 REV HRS", twrevogp5: "OGP5 REV HRS", twlive: "TWIN AS LIVE", twbtc: "TWIN BTC", twgold: "TWIN GOLD", twclean: "TWIN CLEAN", twno45: "TWIN NO <45c", twnocs: "TWIN NO CLOSE-σ", twsp5b: "SP5 BTC TWIN", twogp15b: "OGP15 BTC TWIN", twogp5b: "OGP5 BTC TWIN", pap20: "PAPER 20%", oggb: "OG BANK OCT1", oghb: "OG BANK", ogp2b: "OG+PIV BANK 2M", ogp5b: "OG+PIV BANK 5M", ogp10b: "OG+PIV BANK 10M", ogp15b: "OG+PIV BANK 15M", ogp2: "OG+PIV 2M", ogp5: "OG+PIV 5M", ogp10: "OG+PIV 10M", ogp15: "OG+PIV 15M", ogg: "OG · OCT 1", ogh: "OG · YOURS", grokb: "GROK", pap247: "PAPER 24/7", papbest: "PAPER BEST HRS", papwin: "PAPER WINNERS", piv2: "PIVOT 2M", piv5: "PIVOT 5M", piv10: "PIVOT 10M", piv15: "PIVOT 15M", sp2: "SESS+PIV 2M", sp5: "SESS+PIV 5M", sp10: "SESS+PIV 10M", sp15: "SESS+PIV 15M", brnw: "BRICK NO-WALL", sqnw: "SQUEEZE NO-WALL", original: "ORIG", new: "NEW", refined: "REFINED", golden: "GOLDEN", optA: "OPT A", optB: "OPT B", claude: "CLAUDE", trend: "TREND", brick: "BRICK", cotc: "COTC", diamond: "DIAMOND", diamond25: "DIAMOND 25%", confirm: "CONFIRM", brk1: "1ST BREAK", sole5: "5M SOLE", sole10: "10M SOLE", sole15: "15M SOLE", sole5p: "5M SOLE+", sole5z: "5M ZONE", sole5v: "5M VANTAGE", brickc: "BRICK CLEAN", lastmin: "LAST MIN", lastgrant: "YOU+GRANT", bank: "BANK", bank2: "BANK 2", bank5p: "BANK SOLE+", brickx: "BRICK 5M-X", bank5px: "BANK SOLE+ 5M-X", brickt: "BRICK TVC", brickp: "BRICK PUSH", claudex: "CLAUDE 5M-X", trendx: "TREND 5M-X", brk: "BREAK", hold90: "HOLD 90", tap3x: "TAP 3x", taphold: "TAP HOLD", rescue: "RESCUE", hour: "HOURLY", snap50: "SNAP +50", snap100: "SNAP +100", snap200: "SNAP +200", snap300: "SNAP +300", snaphold: "SNAP HOLD", x16_50: "16x +50", x16_100: "16x +100", x16_200: "16x +200", x16_300: "16x +300", x16hold: "16x HOLD", squeeze: "SQUEEZE", bricks: "BRICK SESSION", brickcr: "CLEAN RIDE", brickc75: "CLEAN 75%", brickcf: "CLEAN FEES", brickcm: "CLEAN MAKER", brickcpt: "CLEAN PATIENT", brickcx: "CUT 2 BANDS", brickcw: "CUT WALL", brickcl: "CUT LATE", brickch: "HALF 75%", reent: "RE-ENTRY", vine: "VINE", gall: "GOLD ALL", gclear: "GOLD CLEAR", dcd: "DECIDED", new24: "NEW 24/7", rt100: "RIP&TAP 100", rt200: "RIP&TAP 200", rt90: "RIP&TAP 90%", w5: "WAIT 5", anchor: "ANCHOR", phr: "PRIME HRS", rvw: "REVERSAL", snapb: "SNAPBACK", snpt: "SNAP TVC", b11: "BRICK 1:1 REAL", cfol: "CANDLE FOLLOW", ldc1: "LDC 1M", ldc5: "LDC 5M", ldc15: "LDC 15M", ldc2: "LDC 2M", ldc10: "LDC 10M", ldc20: "LDC 20M", ldc30: "LDC 30M", vwap1: "VWAP 1M", vwap2: "VWAP 2M", vwap5: "VWAP 5M", vwap10: "VWAP 10M", vwap15: "VWAP 15M", vwap30: "VWAP 30M", vlc: "VWAP+LDC", newp: "NEW PATIENT", diap: "DIAMOND PATIENT" };
  // A book's whole record, every row it ever booked (not only head to head).
  const record = (book: ShiftNight["book"]) => sumQ.data?.books?.[book]?.rec ?? { n: 0, pnl: 0, wins: 0, losses: 0, from: "9999" };
  // OFF HOURS on each card (Love, Oct 3: "if any books have off hours can you include them in their cards"). Pacific time.
  const HOURS: Partial<Record<ShiftNight["book"], string>> = {
    new: "OFF · BTC 9–10a, 4–5p, 6–7p, 8–10p · GOLD 1–2a, 7–8a, 12–1p, 4–6p",
    refined: "OFF · BTC 9–10a, 4–5p, 6–7p, 8–10p · GOLD 1–2a, 7–8a, 12–1p, 4–6p",
    optA: "OFF · BTC 9–10a, 4–5p, 6–7p, 8–10p · GOLD 1–2a, 7–8a, 12–1p, 4–6p",
    optB: "OFF · BTC 9–10a, 2–5p, 6–7p, 8–10p · GOLD 1–2a, 7–8a, 12–1p, 4–6p",
    claude: "OFF · BTC 9–10a, 12–1p, 4–5p, 7–8p, 9–10p · GOLD 6–7a, 12–1p, 4–5p, 11p–12a",
    trend: "OFF · BTC 9–10a, 12–1p, 4–5p, 7–8p, 9–10p · GOLD 6–7a, 12–1p, 4–5p, 11p–12a",
    // Oct 11 (Love: "can you throw her on & off hours on her cards too"): Kalshi sits these hours out; paper runs 24/7.
    pap247: "KALSHI OFF · 12–1a, 2–3a, 4–6a, 12–2p, 6–7p PT · PAPER RUNS 24/7",
    papwin: "KALSHI OFF · 12–1a, 2–3a, 4–6a, 12–2p, 6–7p PT · PAPER RUNS 24/7",
    pap20: "KALSHI OFF · 12–1a, 2–3a, 4–6a, 12–2p, 6–7p PT · PAPER RUNS 24/7",
    grokb: "KALSHI OFF · 12–2a, 6–7a, 11a–12p, 1–3p, 5–6p, 9p–12a PT · PAPER RUNS 24/7",
    ogp5: "KALSHI OFF · 12–1a, 3–4a, 10–11a, 4–6p PT · PAPER RUNS 24/7",
    diamond: "OFF · 2–8p (chop after the 2 PM reset)",
    diamond25: "OFF · 2–8p (chop after the 2 PM reset)",
  };
  // Oct 12 (Love): books live on Kalshi show their real off hours, read from live-switch (the same rules the copier uses).
  const liveHours = (book: string): string | null => {
    const r = ((schedQ.data as any)?.rows ?? []).find((x: any) => x.book === book);
    if (!r) return null;
    const pt = (x: string) => (x === "none" ? "none" : `${x} PT`);
    const off = r.offBtc === r.offGold ? `KALSHI OFF · ${pt(r.offBtc)}` : `KALSHI OFF · BTC ${pt(r.offBtc)} · GOLD ${pt(r.offGold)}`;
    return `${off} · PAPER RUNS 24/7`;
  };
  const Col = ({ book, title, note, s }: { book: ShiftNight["book"]; title: string; note: string; s: ReturnType<typeof side> }) => {
    const c = s.pnl >= 0 ? SHIFT_UP : SHIFT_DOWN;
    const on = pick === book;
    // RUNNING glow (Love, Oct 8 ~4:30 PM PT: "a green highlight to whatever books are currently running").
    const running = runOn(book);
    return (
      <button
        key={book}
        type="button"
        onClick={() => {
          // Oct 12 (Love: "if i click it takes a few seconds... so i click again and then they go away"): a second tap within
          // 1.2 s is ignored, and the switch is a background update so the page answers the tap at once.
          if (opening) return;
          if (on && Date.now() - openedAtRef.current < 2500) return;
          setOpening(book);
          startTransition(() => {
            setPick(on ? "all" : book);
            setLimit(40);
          });
        }}
        className="flex flex-1 flex-col gap-1 rounded-2xl border px-4 py-3 text-left transition-shadow"
        style={{ borderColor: opening === book ? "#ffd479" : on ? c : running ? "#3ddc84" : "rgba(255,255,255,0.2)", boxShadow: opening === book ? "0 0 16px rgba(255,212,121,0.45)" : on ? `0 0 16px ${c}55` : running ? "0 0 12px rgba(61,220,132,0.35)" : "none", contentVisibility: "auto", containIntrinsicSize: "auto 260px" } as any}
      >
        <p className="flex items-center gap-1.5 text-[10px] tracking-[0.26em] text-white">
          {running ? <span className="inline-block h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: "#3ddc84", boxShadow: "0 0 6px #3ddc84" }} /> : null}
          {title}
          {running ? <span className="text-[8px] tracking-[0.2em]" style={{ color: "#3ddc84" }}>RUNNING</span> : null}
        </p>
        <p className="text-[9px] leading-snug text-white/55">{note}</p>
        <p className="font-mono text-[9px] tracking-[0.12em] text-white/80">{liveHours(book) ?? HOURS[book] ?? "ON · ALL HOURS"}</p>
        <p className="mt-1 font-mono text-2xl tabular-nums" style={{ color: c, textShadow: `0 0 10px ${c}` }}>{shiftMoney(s.pnl)}</p>
        {liveQ2.data?.[book] && (runOn(book) || liveQ2.data[book].todayN > 0) ? (
          <p className="font-mono text-[10px] tabular-nums tracking-[0.08em]" style={{ color: liveQ2.data[book].today >= 0 ? "#3ddc84" : "#ff5c5c" }}>
            LIVE · KALSHI TODAY {liveQ2.data[book].today >= 0 ? "+" : "−"}${Math.abs(liveQ2.data[book].today).toFixed(2)} · {liveQ2.data[book].todayN} trade{liveQ2.data[book].todayN === 1 ? "" : "s"}
            <span className="text-white/45"> · ALL {liveQ2.data[book].all >= 0 ? "+" : "−"}${Math.abs(liveQ2.data[book].all).toFixed(2)}</span>
          </p>
        ) : null}
        {(() => {
          const k = kTrue(book);
          if (!k.live && !k.held) return null;
          return (
            <p className="font-mono text-[10px] tabular-nums tracking-[0.08em]" style={{ color: k.pnl >= 0 ? "#3ddc84" : "#ff5c5c" }}>
              KALSHI-TRUE {k.pnl >= 0 ? "+" : "−"}${Math.abs(k.pnl).toFixed(2)}
              <span className="text-white/45"> · {k.live} of its calls traded on Kalshi ({k.wins}W {k.losses}L, shared with twins)</span>
              {k.held ? (
                <span className="block text-[9px] text-white/45">
                  held:{" "}
                  {Object.entries(k.why)
                    .map(([w, c]) => `${c.n} ${({ stop: "daily stop", bench: "benched", ran: "price ran first", taken: "window taken", band: "band rules", other: "other" } as Record<string, string>)[w] ?? w} (paper ${c.p >= 0 ? "+" : "−"}$${Math.abs(c.p).toFixed(0)})`)
                    .join(" · ")}
                </span>
              ) : null}
            </p>
          );
        })()}
        <p className="font-mono text-[11px] tabular-nums text-white/80">
          {s.wins}W · {s.losses}L{s.wins + s.losses ? ` · ${Math.round((s.wins / (s.wins + s.losses)) * 100)}% wins` : ""}{s.open ? ` · ${s.open} open` : ""}
        </p>
        {!isTap(book) && book !== "supernova" && book !== "recon-fresh" && book !== "recon-all" && (
          <div className="mt-auto flex justify-end pt-1">
            <span
              role="button"
              tabIndex={0}
              title={runOn(book) ? "Running on Kalshi. Tap to stop" : "Paper only. Tap to run on Kalshi"}
              onClick={(e) => {
                e.stopPropagation();
                flipRun(book);
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.stopPropagation();
                  flipRun(book);
                }
              }}
              className="flex items-center gap-1.5 rounded-[5px] px-2 py-1 font-mono text-[10px] font-semibold leading-none tracking-[0.2em]"
              style={{
                opacity: runBusy === book ? 0.5 : 1,
                color: runOn(book) ? "#3ddc84" : "#ff5c5c",
                border: `1px solid ${runOn(book) ? "#3ddc84" : "#ff5c5c"}`,
                background: runOn(book) ? "rgba(61,220,132,0.14)" : "rgba(255,92,92,0.10)",
                boxShadow: runOn(book) ? "0 0 10px rgba(61,220,132,0.45)" : "none",
              }}
            >
              <span className="inline-block h-1.5 w-1.5 rounded-full" style={{ background: runOn(book) ? "#3ddc84" : "#ff5c5c" }} />
              RUN{runQ.data?.auto === book ? " · AUTO" : ""}{runOn(book) && runQ.data && !runQ.data.live ? " · KALSHI OFF" : ""}{runOn(book) && runQ.data?.risk?.benched?.[book] ? ` · BENCHED TO ${new Date(runQ.data.risk.benched[book].until).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}` : ""}{runOn(book) && runQ.data?.risk?.stopped ? " · DAILY STOP" : ""}
            </span>
          </div>
        )}
        <div className={cn("flex items-end justify-between gap-2 pt-1", isTap(book) && "mt-auto")}>
          <p className="text-[9px] tracking-[0.18em]" style={{ color: opening === book ? "#ffd479" : "rgba(255,255,255,0.45)" }}>{opening === book ? (on ? "CLOSING…" : "OPENING… ONE TAP IS ENOUGH") : on ? "SHOWING ITS TRADES · TAP AGAIN TO CLOSE" : "TAP FOR ITS TRADES"}</p>
          <span className="flex shrink-0 gap-1">
            {(["4h", "12h", "24h", "all"] as const).map((k) => (
              <span
                key={k}
                role="button"
                tabIndex={0}
                onClick={(e) => {
                  e.stopPropagation();
                  setSpan(k);
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.stopPropagation();
                    setSpan(k);
                  }
                }}
                className="rounded-[4px] px-1.5 py-0.5 font-mono text-[9px] leading-none"
                style={{ border: `1px solid rgba(255,255,255,${span === k ? 0.9 : 0.3})`, color: span === k ? "#fff" : "rgba(255,255,255,0.55)" }}
              >
                {k === "all" ? "ALL" : k.toUpperCase()}
              </span>
            ))}
          </span>
        </div>
      </button>
    );
  };
  // ALWAYS RED (Love, Oct 11 ~9:20 AM PT: "can we put all of the perpetually red books in a different spot?... not the ones
  // that are green most of the time and red for that day, just all the red ones we never use"). All-time record (every
  // night row + the exit ledger, ignoring the 4H/12H/24H span): red overall AND red on at least 60% of the Pacific days it
  // traded (2+ days). A book on RUN never moves there.
  // Oct 11 ~4:40 PM PT (Love: "if i click [4H / 24H] it keeps crashing the page"): this ran on every render and built a
  // new date formatter for every one of ~30k rows (seconds of frozen page per click). Memoized, one formatter, cached days.
  const redBooks = useMemo(() => new Set<string>((sumQ.data?.red ?? []).filter((b) => !(runQ.data?.books ?? []).includes(b))), [sumQ.data, runQ.data]);
  const [showRed, setShowRed] = useState(false);
  // Oct 12 (Love: "see all trades when i tap the cards... not just the last 15"): 15 first, then 50 more or all.
  const [inlineN, setInlineN] = useState(15);
  // SHOW ALL fills in 150 rows at a time (Oct 13, Love: "it won't let me open all trades on them"): thousands of rows at once
  // froze / reloaded the page.
  const [growTo, setGrowTo] = useState(0);
  useEffect(() => { setInlineN(15); setGrowTo(0); }, [pick]);
  useEffect(() => {
    if (!growTo) return;
    if (inlineN >= growTo) { setGrowTo(0); return; }
    const id = setTimeout(() => setInlineN((n) => Math.min(growTo, n + 150)), 50);
    return () => clearTimeout(id);
  }, [growTo, inlineN]);
  // Frozen-feed rows (Fri 2:01-5:16 PM PT, OANDA BTC frozen for the weekend) fold away by default (Love: "everything
  // says frozen feed?"): they sat on top of the list once the taps moved to their own tab.
  const pickBook = pick !== "all" && pick !== "taps" && pick !== "origClean" ? pick : "";
  // HISTORY FROM THE FILE ON TAP (LIGHT SHIFT, Oct 17): a card's older trades are read from the exit ledger only when she asks.
  const [histFor, setHistFor] = useState("");
  const bookHistQ = useQuery({ queryKey: ["book-history", pickBook], queryFn: () => getBookHistory({ data: { book: pickBook } }), enabled: !!pickBook && histFor === pickBook, refetchInterval: 120000 });
  const list0 = pick === "all" ? rowsAll.filter((r) => !isTap(r.book)) : pick === "taps" ? rowsAll.filter((r) => isTap(r.book)) : pick === "origClean" ? rows.filter((r) => r.book === "original" && !bandErr(r)) : [...rowsAll.filter((r) => r.book === pick), ...((bookHistQ.data ?? []) as unknown as ShiftNight[]).map((r) => ({ ...r, stake: (r.stake ?? 30) * scale, pnl: r.pnl == null ? null : r.pnl * scale }))];
  // Love, Oct 3 ~12:50 AM PT: "she looks like she's erroring out" -> frozen-feed rows are never shown (never counted).
  const list = list0.filter((r) => !r.stale);
  const Inline = ({ book }: { book: string }) => {
    if (pick !== book) return null;
    const sorted = [...list].sort((a, b) => (a.at < b.at ? 1 : -1));
    const xs = sorted.slice(0, inlineN);
    return (
      <div key={`inline-${book}`} className="rounded-2xl px-3 py-2 sm:col-span-2" style={{ border: "1px solid rgba(255,255,255,0.25)", boxShadow: "0 0 12px rgba(255,255,255,0.06)" }}>
        <p className="mb-1.5 text-[9px] tracking-[0.24em] text-white/60">{(LABEL[book] ?? book).toUpperCase()} · {xs.length < sorted.length ? `LATEST ${xs.length} OF ${sorted.length}` : `ALL ${sorted.length}`} TRADES · TAP THE CARD AGAIN TO CLOSE</p>
        {xs.length ? xs.map((r) => {
          const open = r.result === "open" || r.pnl == null;
          // OPEN = ON KALSHI (Oct 15, Love's no-exceptions law): an open row the door did not FILL shows NOT ON KALSHI
          // plus the door's own words (e.g. the 05:01:18 pulled rest after her hand took the window).
          const ck = (copyQ.data ?? {})[r.id];
          const kOpen = r.result === "open" && !(ck == null || ck === "live");
          const c = open ? "rgba(255,255,255,0.7)" : (r.pnl ?? 0) >= 0 ? "#3ddc84" : "#ff5c5c";
          return (
            <div key={r.id} className="flex items-baseline justify-between gap-2 border-t border-white/10 py-1 font-mono text-[10px]" style={{ contentVisibility: "auto", containIntrinsicSize: "auto 22px" } as any}>
              <span className="text-white/80">
                {INLINE_FMT.format(new Date(r.at))} · {String(r.asset).toUpperCase()} {r.side === "up" ? "LONG" : "SHORT"} · {r.setup}{r.multiple ? ` · ${Number(r.multiple).toFixed(2)}x` : ""}
                {r.exit ? <span className="block text-[9px] text-white/45">{r.exit}</span> : null}
                {kOpen && ck ? <span className="block text-[9px]" style={{ color: "#ffb86b" }}>{String(ck)}</span> : null}
              </span>
              <span className="shrink-0 tabular-nums" style={{ color: kOpen ? "#ffb86b" : c }}>{r.result === "open" ? (kOpen ? "NOT ON KALSHI" : "OPEN") : r.pnl == null ? String(r.result || "open").toUpperCase() : `${(r.pnl ?? 0) >= 0 ? "+" : "−"}$${Math.abs(r.pnl ?? 0).toFixed(2)}`}</span>
            </div>
          );
        }) : <p className="font-mono text-[10px] text-white/50">{rowsQ.isLoading || bookHistQ.isFetching ? "loading…" : "no trades yet"}</p>}
        {xs.length < sorted.length ? (
          <div className="mt-1.5 flex gap-2 font-mono text-[9px]">
            <button type="button" onClick={(e) => { e.stopPropagation(); setInlineN((n) => n + 50); }} className="rounded-full border border-white/40 px-2.5 py-0.5 text-white/80">SHOW 50 MORE</button>
            <button type="button" onClick={(e) => { e.stopPropagation(); setGrowTo(sorted.length); }} className="rounded-full border border-white/40 px-2.5 py-0.5 text-white/80">{growTo ? `LOADING ${xs.length} / ${sorted.length}…` : `SHOW ALL ${sorted.length}`}</button>
          </div>
        ) : null}
        <div className="mt-1.5 flex gap-2 font-mono text-[9px]">
          {histFor === book ? (
            <span className="text-white/50">{bookHistQ.isFetching ? "LOADING HISTORY FROM FILE…" : `HISTORY LOADED · ${((bookHistQ.data ?? []) as unknown[]).length} OLDER TRADES`}</span>
          ) : (
            <button type="button" onClick={(e) => { e.stopPropagation(); setHistFor(book); }} className="rounded-full border border-white/40 px-2.5 py-0.5 text-white/80">LOAD TRADE HISTORY FROM FILE</button>
          )}
        </div>
      </div>
    );
  };
  // TAKE-PROFIT TRY BOX (Love, Oct 3 ~12:45 AM PT: "a percentage box for me to type in that will show me which trades
  // went above that percentage and would have been wins had she taken profits"). Uses each trade's recorded peak.
  const [tryPct, setTryPct] = useState("");
  // The settings "Default exit" slider (35-200%) drives this what-if too (Love, Oct 3 ~2:15 PM PT).
  // Oct 11 (Love: "it autopopulates 64 into the 'did it hit' box and it makes all the trades red... let's keep the box,
  // just want it to not fill in"): the box no longer copies the settings slider; it stays empty until she types.
  void whatIf;
  const tp = Number(tryPct);
  const tpOk = tp > 0 && tp < 2000;
  // Love thinks in "% of the max" (like her 75% pill): 85 = sell at 85% of what the trade can pay. 100+ = the bell.
  const [ofMax, setOfMax] = useState(true);
  const lvl = (r: ShiftNight) => (ofMax ? (Math.min(tp, 100) / 100) * (Number(r.multiple) - 1) * 100 : tp);
  const done = list.filter((r) => r.result !== "open" && r.pnl != null);
  const hit = (r: ShiftNight) => (r.peakPct ?? 0) + 1e-9 >= lvl(r);
  const reachedAll = tpOk ? done.filter(hit) : [];
  const savedRed = reachedAll.filter((r) => (r.pnl ?? 0) < -0.05);
  const actual = done.reduce((t, r) => t + (r.pnl ?? 0), 0);
  // What each trade would have done at that take profit (Love: "show what the trades would have closed at, or whether
  // they would have closed at all"): winners at the bell close at the line (or pay the full max if the line is past it);
  // losers that peaked past the line are saved there; the rest lose the stake at the bell.
  const bellWin = (r: ShiftNight) => (r.bell === "yes" || r.bell === "no" ? (r.bell === "yes") === (r.side === "up") : null);
  const maxP = (r: ShiftNight) => (Number(r.multiple) - 1) * 100;
  const atX = (r: ShiftNight): { pnl: number; how: string } => {
    const bw = bellWin(r);
    if (bw === null) return { pnl: r.pnl ?? 0, how: "not settled" };
    const L = lvl(r);
    if (bw) return L >= maxP(r) - 1e-9 ? { pnl: (r.stake * maxP(r)) / 100, how: "rides to the bell · WIN" } : { pnl: (r.stake * L) / 100, how: `closes at +${Math.round(L)}%` };
    if ((r.peakPct ?? 0) + 1e-9 >= L) return { pnl: (r.stake * L) / 100, how: `closes at +${Math.round(L)}% · saved a loser` };
    return { pnl: -r.stake, how: "never got there · LOSS at the bell" };
  };
  const atTp = done.reduce((t, r) => t + atX(r).pnl, 0);
  // OUTCOME ENDED (Love, Oct 3 ~8:35 PM PT: "track whether the exit was right or not... include that in the trade tabs,
  // outcome ended"). Holding to the bell vs what the exit got: right = the exit made at least what holding would have.
  const holdPnl = (r: ShiftNight) => {
    const bw = bellWin(r);
    if (bw === null) return null;
    return bw ? r.stake * (Number(r.multiple) - 1) : -r.stake;
  };
  const ended = (r: ShiftNight): { text: string; good: boolean; diff: number } | null => {
    if (r.result === "open" || r.pnl == null) return null;
    const h = holdPnl(r);
    const bw = bellWin(r);
    if (h == null || bw === null) return null;
    const bell = `ENDED ${bw ? "A WIN" : "A LOSS"} AT THE BELL`;
    if (r.result !== "sold") return { text: `${bell} · HELD TO THE BELL`, good: bw, diff: 0 };
    const diff = (r.pnl ?? 0) - h;
    return diff >= -0.01
      ? { text: `${bell} · EXIT WAS RIGHT${diff > 0.01 ? ` · SAVED ${shiftMoney(diff)}` : ""}`, good: true, diff }
      : { text: `${bell} · EXIT WAS EARLY · HOLDING PAID ${shiftMoney(h)} (${shiftMoney(diff)})`, good: false, diff };
  };
  // BREAK EXIT LEARNING: every BREAK sale graded against the bell, split every way the desk can see, so the
  // rule learns when its exit earns its keep. Grows with every settled window.
  const brkLearn = (() => {
    const rs = rowsAll.filter((r) => r.book === "brk" && !r.stale && r.result === "sold" && ended(r));
    const kind = (r: ShiftNight) => {
      const e = (r.exit || "").toLowerCase();
      return e.startsWith("take profit") ? "take profit" : e.includes("strong break") ? "strong break" : e.includes("two closes") ? "two closes through" : "other exit";
    };
    const lineOf = (r: ShiftNight) => {
      const e = r.exit || "";
      return /σ|VWAP/i.test(e) ? "a session line" : /purple|upper|lower/i.test(e) ? "a nav line" : "";
    };
    const minsLeft = (r: ShiftNight) => {
      if (!r.soldAt) return "";
      const t0 = Date.parse(r.at);
      const close = Math.ceil((t0 + 1) / 900000) * 900000;
      const m = (close - Date.parse(r.soldAt)) / 60000;
      return m > 10 ? "10+ min left" : m > 5 ? "5-10 min left" : "under 5 min left";
    };
    const buckets = new Map<string, { n: number; right: number; diff: number }>();
    const add = (k: string, r: ShiftNight) => {
      if (!k) return;
      const e = ended(r)!;
      const b = buckets.get(k) ?? { n: 0, right: 0, diff: 0 };
      b.n += 1;
      if (e.good) b.right += 1;
      b.diff += e.diff;
      buckets.set(k, b);
    };
    for (const r of rs) {
      const k = kind(r);
      add(k, r);
      add(`${k} · ${r.asset.toUpperCase()}`, r);
      add(`${k} · ${r.side === "up" ? "longs" : "shorts"}`, r);
      if (k !== "take profit" && lineOf(r)) add(`break of ${lineOf(r)}`, r);
      if (k !== "take profit" && minsLeft(r)) add(`break exit · ${minsLeft(r)}`, r);
    }
    const all = [...buckets.entries()].map(([k, b]) => ({ k, ...b, rate: b.n ? b.right / b.n : 0 })).sort((a, b) => b.n - a.n);
    const lessons = all
      .filter((b) => b.n >= 5 && (b.rate >= 0.6 || b.rate <= 0.4))
      .slice(0, 5)
      .map((b) => (b.rate >= 0.6 ? { good: true, t: `KEEP: ${b.k} exits are right ${Math.round(b.rate * 100)}% of the time (${b.n}), ${shiftMoney(b.diff)} vs holding` } : { good: false, t: `HOLD INSTEAD: ${b.k} exits were early ${Math.round((1 - b.rate) * 100)}% of the time (${b.n}), ${shiftMoney(b.diff)} vs holding` }));
    return { n: rs.length, right: rs.filter((r) => ended(r)!.good).length, net: rs.reduce((t, r) => t + ended(r)!.diff, 0), all, lessons };
  })();
  // BOOKS BY TIME OF DAY (Love, Oct 3 ~8:35 PM PT: "track if certain books/strategies do better than others at certain
  // times"). Pacific time, six 4-hour blocks, every settled trade in the current view.
  const BLOCKS = ["12-4a", "4-8a", "8a-12p", "12-4p", "4-8p", "8p-12a"];
  const hourPT = (iso: string) => Number(new Intl.DateTimeFormat("en-US", { timeZone: "America/Los_Angeles", hour: "2-digit", hourCycle: "h23" }).format(new Date(iso)));
  void hourPT;
  const tod = sumQ.data?.tod ?? [];
  // WITH THE NET (Love, Oct 3 ~5:25 PM PT: "where it would have ended had i been at the percentage i put in" + her net:
  // line at T% of max, catches at T-15 and T-10 if a trade got past them and fell back). Same model as atX.
  const netAt = (r: ShiftNight): { pnl: number; caught: boolean } => {
    const bw = bellWin(r);
    if (bw === null) return { pnl: r.pnl ?? 0, caught: false };
    const mx = maxP(r);
    if (!(mx > 0)) return { pnl: r.pnl ?? 0, caught: false };
    const T = ofMax ? Math.min(tp, 100) : Math.min(100, (tp / mx) * 100);
    const L = (T / 100) * mx;
    if (bw) return { pnl: (r.stake * L) / 100, caught: false };
    const pkOfMax = ((r.peakPct ?? 0) / mx) * 100;
    if (pkOfMax + 1e-9 >= T) return { pnl: (r.stake * L) / 100, caught: false };
    const steps = [T - 15, T - 10].filter((x) => x > 0 && pkOfMax >= x + 0.5);
    if (steps.length) return { pnl: (r.stake * Math.max(...steps) * mx) / 1e4, caught: true };
    return { pnl: -r.stake, caught: false };
  };
  const withNet = done.reduce((t, r) => t + netAt(r).pnl, 0);
  const netCaught = tpOk ? done.filter((r) => netAt(r).caught).length : 0;
  const netT = ofMax ? Math.min(tp, 100) : 0;
  // SWEET SPOT (Love, Oct 3 ~5:20 PM PT: "YES"): sweep every take-profit level in the current mode across every finished
  // trade and find the one that would have paid the most in total dollars. Same math as atX, just at each level.
  const sweep = (() => {
    const levels: number[] = [];
    if (ofMax) for (let t = 30; t <= 100; t += 5) levels.push(t);
    else for (let t = 10; t <= 200; t += 5) levels.push(t);
    const rows = levels.map((t) => {
      let total = 0, gaveUp = 0, saved = 0;
      for (const r of done) {
        const bw = bellWin(r);
        if (bw === null) { total += r.pnl ?? 0; continue; }
        const mx = maxP(r);
        const L = ofMax ? (Math.min(t, 100) / 100) * mx : t;
        if (bw) {
          if (L >= mx - 1e-9) total += (r.stake * mx) / 100;
          else { total += (r.stake * L) / 100; gaveUp += (r.stake * (mx - L)) / 100; } // a winner crosses the line on its way to the bell
        } else if ((r.peakPct ?? 0) + 1e-9 >= L) { total += (r.stake * L) / 100; saved += r.stake + (r.stake * L) / 100; }
        else total -= r.stake;
      }
      return { t, total, gaveUp, saved };
    });
    const bell = done.reduce((t, r) => {
      const bw = bellWin(r);
      return t + (bw === null ? r.pnl ?? 0 : bw ? (r.stake * maxP(r)) / 100 : -r.stake);
    }, 0);
    const best = rows.reduce((a, b) => (b.total > a.total ? b : a), rows[0]);
    const lo = Math.min(...rows.map((x) => x.total), 0), hi = Math.max(...rows.map((x) => x.total), 0);
    return { rows, best, bell, lo, hi };
  })();
  // REAL KALSHI PATHS (Love, Oct 3 ~5:40 PM PT): the same levels replayed on the recorded bid paths, with and without
  // the safety net, so whipsaws through a step count against it.
  const pathLevels = Array.from(new Set([...sweep.rows.map((x) => x.t), ...(tpOk ? [tp] : [])]));
  const pathQ = useQuery({
    queryKey: ["path-exits", ofMax, done.length, done[0]?.id ?? "", pathLevels.join(",")],
    queryFn: () => getPathExits({ data: { ids: done.map((r) => r.id), ofMax, levels: pathLevels } }),
    enabled: done.length > 0,
    staleTime: 60_000,
  });
  const pathBest = (pathQ.data?.levels ?? []).filter((x) => sweep.rows.some((y) => y.t === x.t)).reduce<null | NonNullable<typeof pathQ.data>["levels"][number]>((a, b) => (!a || Math.max(b.none.total, b.net.total) > Math.max(a.none.total, a.net.total) ? b : a), null);
  const pathTyped = tpOk ? (pathQ.data?.levels ?? []).find((x) => x.t === tp) ?? null : null;
  // Love, Oct 3 ~5 PM PT: "only have it count the winners" -> the headline counts WINNERS only (won at the bell; if the
  // bell isn't in yet, finished green). Losers that peaked past the line are shown separately as "saved".
  const isWinner = (r: ShiftNight) => bellWin(r) ?? (r.pnl ?? 0) > 0.05;
  const winners = done.filter(isWinner);
  // Love, Oct 3 ~5:10 PM PT: "i only want to know if it got there on the trades that actually have it" -> the count only
  // includes winners whose max payout can reach the line (a 1.46x pays +46% max, so it can't reach +90%).
  const canReach = (r: ShiftNight) => maxP(r) + 1e-9 >= lvl(r);
  const able = tpOk ? winners.filter(canReach) : [];
  const cant = tpOk ? winners.length - able.length : 0;
  const reached = able.filter(hit);
  const soldEarly = done.filter((r) => r.result === "sold" && bellWin(r) !== null);
  const soldWouldWin = soldEarly.filter((r) => bellWin(r)).length;
  const [paperTp, setPaperTpState] = useState<number | null>(null);
  useEffect(() => {
    getPaperTp().then((v) => setPaperTpState(v)).catch(() => {});
  }, []);
  const soldPct = (r: ShiftNight) => (r.pnl != null && r.stake > 0 ? Math.round((r.pnl / r.stake) * 100) : null);
  const rec = pick === "all" || pick === "origClean" || pick === "taps" ? null : record(pick);
  const chip = (b: ShiftNight["book"] | "all" | "origClean" | "taps", label: string, wide = false) => (
    <button
      key={b}
      type="button"
      onClick={() => {
        setPick(b);
        setLimit(40);
      }}
      className={`rounded-full border px-3 py-1 text-[9px] tracking-[0.2em]${wide ? " w-full truncate text-center" : ""}`}
      style={{ borderColor: pick === b ? "#ffffff" : "rgba(255,255,255,0.22)", color: "#ffffff", textShadow: pick === b ? "0 0 8px rgba(255,255,255,0.6)" : "0 0 6px rgba(255,255,255,0.35)" }}
    >
      {label}
    </button>
  );
  return (
    <section className="rounded-[22px] border border-white/25 px-5 py-4 shadow-[0_0_18px_rgba(255,255,255,0.06)]">
      <div className="flex items-baseline justify-between gap-3">
        <div className="flex items-center justify-between gap-2">
          <p className="text-[10px] tracking-[0.28em] text-white/90">PAPER · {ranked.length} LEDGERS · RANKED{h2h ? ` · SINCE ${shiftClock(since)}` : ""}</p>
          <button
            type="button"
            onClick={flipAuto}
            title="AUTO ROLL: the best paper book of the last few hours rides on Kalshi next to the books you RUN"
            className="shrink-0 rounded-[5px] px-2 py-1 font-mono text-[9px] tracking-[0.18em]"
            style={{ color: runQ.data?.autoOn ? "#3ddc84" : "rgba(255,255,255,0.6)", border: `1px solid ${runQ.data?.autoOn ? "#3ddc84" : "rgba(255,255,255,0.35)"}` }}
          >
            AUTO ROLL · {runQ.data?.autoOn ? `ON · ${runQ.data.autoHours ?? 4}H` : "OFF"}
          </button>
          {(runQ.data?.presets ?? []).map((p) => {
            const on = sameSet(p.books, runQ.data?.books ?? []);
            return (
              <button
                key={p.name}
                type="button"
                onClick={() => useSet(p.name)}
                title={`SET: ${p.books.map((b) => b.toUpperCase()).join(" · ")}. Tap to put exactly these books on RUN.`}
                className="shrink-0 rounded-[5px] px-2 py-1 font-mono text-[9px] tracking-[0.18em]"
                style={{ color: on ? "#3ddc84" : "rgba(255,255,255,0.75)", border: `1px solid ${on ? "#3ddc84" : "rgba(255,255,255,0.35)"}`, boxShadow: on ? "0 0 10px rgba(61,220,132,0.35)" : "none" }}
              >
                {p.name}
              </button>
            );
          })}
          <button type="button" onClick={saveSet} title="Save the books on RUN right now as a set" className="shrink-0 rounded-[5px] px-2 py-1 font-mono text-[9px] tracking-[0.18em]" style={{ color: "rgba(255,255,255,0.6)", border: "1px dashed rgba(255,255,255,0.35)" }}>
            + SAVE SET
          </button>
          <button
            type="button"
            onClick={flipStep}
            title={runQ.data?.stepped ? "You stepped out. Tap to step back in: Kalshi LIVE comes back on for new trades." : "STEP OUT: your call to walk away. Kalshi LIVE goes off (open trades keep their exits) and the call is logged so we can score it."}
            className="shrink-0 rounded-[5px] px-2 py-1 font-mono text-[9px] tracking-[0.18em]"
            style={{ color: runQ.data?.stepped ? "#c9a7ff" : "rgba(255,255,255,0.85)", border: `1px solid ${runQ.data?.stepped ? "#c9a7ff" : "rgba(255,255,255,0.45)"}`, boxShadow: runQ.data?.stepped ? "0 0 10px rgba(201,167,255,0.35)" : "none" }}
          >
            {runQ.data?.stepped ? "STEPPED OUT 🧘 · STEP BACK IN" : "STEP OUT 🧘"}
          </button>
          {runQ.data?.risk && runQ.data.risk.limit > 0 && (
            <span
              title="DAILY STOP: when the live books are down this much on Kalshi today (Pacific day), no new live entries until midnight PT. Open trades keep their exits."
              className="shrink-0 rounded-[5px] px-2 py-1 font-mono text-[9px] tracking-[0.18em]"
              style={{ color: runQ.data.risk.stopped ? "#ff5c5c" : "rgba(255,255,255,0.75)", border: `1px solid ${runQ.data.risk.stopped ? "#ff5c5c" : "rgba(255,255,255,0.35)"}` }}
            >
              {runQ.data.risk.stopped ? "DAILY STOP HIT" : "DAILY STOP"} · -${runQ.data.risk.limit} · TODAY {runQ.data.risk.todayPnl >= 0 ? "+" : "-"}${Math.abs(runQ.data.risk.todayPnl).toFixed(0)}
            </span>
          )}
        </div>
        <p className="text-[9px] tracking-[0.2em] text-white/50">SHOWN AT ${Math.round(size)} A TRADE · NO ORDERS SENT</p>
      </div>
      <SchedulePill />
      {/* TRADES UNDER THE CARD (Love, Oct 11 ~9:20 AM PT: "could we just make it populate the trades for that card when
          clicked? it would be sooo much easier than scrolling thru all of it"). Tapping a card opens its latest trades right
          under it (newest first); the full list further down still works too. */}
      {/* RUNNING (Love, Oct 8 ~4:30 PM PT: "a RUNNING section above the BEST section... still in their order of best to
          worst"): the books on RUN right now, in their ranking order. They also stay in their tiers below, glowing green. */}
      {(() => {
        // TOGETHER 💞 rides at the top of RUNNING whenever both of its books are on RUN (Oct 13 ~8:55 PM PT, Love: "could you add
        // the together card to our running table? so they're together").
        const togOn = runOn("pap247") && runOn("ogp5");
        // HER CLEAN SLATE ON TOP (Oct 20 ~7:26 PM PT, Love: "can you give her record a fresh start hun? a fresh card since your fixes this morning... i didnt see it"):
        // the FRESH SLATE card rides first in RUNNING whenever TOGETHER is live.
        const freshOn = runOn("recon-tog");
        const runRows = ranked.map((b, i) => ({ ...b, i })).filter((b) => runOn(b.book) || (togOn && b.book === "twtog") || (freshOn && b.book === "recon-fresh")).sort((a, b) => (a.book === "recon-fresh" ? -1 : b.book === "recon-fresh" ? 1 : a.book === "twtog" ? -1 : b.book === "twtog" ? 1 : 0));
        if (!runRows.length) return null;
        return (
          <div className="mt-3 rounded-2xl px-2 pb-2 pt-2" style={{ border: "1px solid rgba(61,220,132,0.45)", boxShadow: "0 0 18px rgba(61,220,132,0.12)" }}>
            <p className="mb-2 px-1 text-[9px] tracking-[0.28em]" style={{ color: "#3ddc84" }}>
              ● RUNNING ON KALSHI · {runRows.length}
              {liveQ2.data?.__lineup ? (
                <span style={{ color: liveQ2.data.__lineup.today >= 0 ? "#3ddc84" : "#ff5c5c" }}>
                  {" "}· LINEUP TODAY {liveQ2.data.__lineup.today >= 0 ? "+" : "−"}${Math.abs(liveQ2.data.__lineup.today).toFixed(2)} ({liveQ2.data.__lineup.todayN} trades) · SINCE THIS LINEUP {liveQ2.data.__lineup.all >= 0 ? "+" : "−"}${Math.abs(liveQ2.data.__lineup.all).toFixed(2)}
                </span>
              ) : null}
            </p>
            <LineupModeChips />
            <div className="mb-2 rounded-xl px-2 py-1.5" style={{ border: "1px solid rgba(255,255,255,0.3)" }}>
              <p className="mb-1 text-[9px] tracking-[0.24em] text-white/70">OPEN NOW · MAIN BOOK + DELAYED · {openNow.length}</p>
              {openNow.length ? openNow.map((r: any) => { const on = (copyQ.data ?? {})[r.id] === "live"; return (
                <div key={r.id} className="flex items-baseline justify-between gap-2 border-t border-white/10 py-1 font-mono text-[10px]">
                  <span className="text-white/85">{INLINE_FMT.format(new Date(r.at))} · {r.book === "recon-dly" ? "DELAYED ⏳" : "MAIN 💞"} · {String(r.asset).toUpperCase()} {r.side === "up" ? "LONG" : "SHORT"} · {r.setup}{r.multiple ? ` · ${Number(r.multiple).toFixed(2)}x` : ""}</span>
                  <span className="shrink-0 tabular-nums" style={{ color: on ? "#3ddc84" : "#ffb86b" }}>{on ? "ON KALSHI" : "PAPER"}</span>
                </div>); }) : <p className="font-mono text-[10px] text-white/50">{openQ.isLoading ? "loading…" : "no open trades right now"}</p>}
            </div>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">{runRows.map((b) => [Col({ book: b.book, title: `${b.i + 1}. ${b.title}`, note: b.note, s: b.s }), Inline({ book: b.book })])}</div>
          </div>
        );
      })()}
      {/* FAMILIES + FIND (Oct 9). */}
      <div className="mt-3 rounded-2xl px-2 py-2" style={{ border: "1px solid rgba(255,255,255,0.18)" }}>
        <input
          value={findQ}
          onChange={(e) => setFindQ(e.target.value)}
          placeholder="FIND A BOOK · e.g. bank sole, refined, snap"
          className="w-full rounded-lg bg-transparent px-2 py-1.5 font-mono text-[10px] tracking-[0.12em] text-white outline-none placeholder:text-white/35"
          style={{ border: "1px solid rgba(255,255,255,0.2)" }}
        />
        <div className="mt-2 flex flex-wrap gap-1.5">
          {["ALL", ...FAMS.map(([n]) => n), "OTHER"].map((n) => {
            const count = n === "ALL" ? ranked.length : ranked.filter((b) => famOf(b.book) === n).length;
            const on = fam === n && !findQ.trim();
            return (
              <button
                key={n}
                type="button"
                onClick={() => {
                  setFam(n);
                  setFindQ("");
                }}
                className="rounded-full border px-2.5 py-1 text-[9px] tracking-[0.16em]"
                style={{ borderColor: on ? "#3ddc84" : "rgba(255,255,255,0.25)", color: on ? "#3ddc84" : "rgba(255,255,255,0.8)" }}
              >
                {n} · {count}
              </button>
            );
          })}
        </div>
        {archSet.size ? (
          <div className="mt-2 px-1">
            <button type="button" onClick={() => setShowArch((v) => !v)} className="rounded-full border border-white/25 px-2.5 py-1 font-mono text-[9px] tracking-[0.16em] text-white/60">
              🗄 ARCHIVED · {archSet.size} {showArch ? "· HIDE" : "· SHOW"}
            </button>
            {showArch ? (
              <div className="mt-1.5 flex flex-wrap gap-1">
                <p className="w-full font-mono text-[9px] text-white/45">Red or unproven books, not running. Paper keeps recording them in the background; tap one to bring its card back.</p>
                {[...archSet].map((b) => (
                  <button key={b} type="button" onClick={() => void setArchived({ data: { book: b, archived: false } }).then(() => archQ.refetch())} className="rounded-full border border-white/20 px-2 py-0.5 font-mono text-[9px] text-white/70">
                    {(LABEL[b] ?? b).toUpperCase()} ↺
                  </button>
                ))}
              </div>
            ) : null}
          </div>
        ) : null}
        {findQ.trim() || fam !== "ALL" ? (
          <p className="mt-2 px-1 font-mono text-[9px] text-white/55">
            Showing {ranked.filter(famOk).length} of {ranked.length} · still in their BEST / MEAN / BELOW / WORST tiers below, numbered by overall rank
          </p>
        ) : null}
      </div>
      {/* TIERS (Love, Oct 7: "organized in 4 even rows - thin borders between... Best | Mean | Below Mean | Worst"). */}
      {[0, 1, 2, 3].map((tier) => {
        const keep = ranked.map((b, i) => ({ ...b, i })).filter((b) => !redBooks.has(b.book));
        const size = Math.ceil(keep.length / 4);
        const tierRows = keep.slice(tier * size, (tier + 1) * size).filter(famOk);
        if (!tierRows.length) return null;
        return (
          <div key={`tier${tier}`} className="mt-3 pt-2" style={{ borderTop: "1px solid rgba(255,255,255,0.15)" }}>
            <p className="mb-2 text-[9px] tracking-[0.28em]" style={{ color: tier === 0 ? "#3ddc84" : tier === 3 ? "#ff5c5c" : "rgba(255,255,255,0.6)" }}>{["BEST", "MEAN", "BELOW MEAN", "WORST"][tier]}</p>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        {tierRows.map((b) => { const i = b.i; return (
          b.book === "diamond" ? ([
            <div key="diamond" className="relative flex">
              <Col
                book={dFlavor}
                title={`${i + 1}. ${dFlavor === "diamond25" ? "DIAMOND ◆ · 25%" : b.title}`}
                note={dFlavor === "diamond25" ? "Same diamond, on your 25% logic: never in the 25% of the channel closest to the line in front. No σ ≥ $150 gate, no $100 nav check. Still: already through the strike, no 2–7 PM chop, 1.38–2.5x." : b.note}
                s={side(dFlavor)}
              />
              <button
                type="button"
                onClick={() => {
                  setDFlavor((f) => (f === "diamond" ? "diamond25" : "diamond"));
                  setPick("all");
                }}
                className="absolute right-2 top-2 rounded-md border border-white/60 px-2 py-0.5 text-[9px] tracking-[0.18em] text-white"
                style={{ textShadow: "0 0 6px rgba(255,255,255,0.4)" }}
              >
                {dFlavor === "diamond" ? "CLASSIC · TAP FOR 25%" : "25% · TAP FOR CLASSIC"}
              </button>
            </div>,
            // the card's trades open under it like every other card (Oct 19 ~2:13 PM PT, Love: "the trades aren't coming up when i click some of the cards")
            Inline({ book: dFlavor }),
          ]) : (
            [Col({ book: b.book, title: `${i + 1}. ${b.title}`, note: b.note, s: b.s }), Inline({ book: b.book })]
          )
        ); })}
            </div>
          </div>
        );
      })}
      {/* ALWAYS RED section (Oct 11): folded by default. */}
      {(() => {
        const reds = ranked.map((b, i) => ({ ...b, i })).filter((b) => redBooks.has(b.book) && famOk(b));
        if (!reds.length) return null;
        return (
          <div className="mt-3 rounded-2xl px-2 pb-2 pt-2" style={{ border: "1px solid rgba(255,92,92,0.45)", boxShadow: "0 0 14px rgba(255,92,92,0.10)" }}>
            <button type="button" onClick={() => setShowRed((v) => !v)} className="w-full px-1 text-left text-[9px] tracking-[0.28em]" style={{ color: "#ff5c5c" }}>
              ● ALWAYS RED · {reds.length} BOOKS · RED OVERALL AND ON MOST DAYS THEY TRADED · {showRed ? "TAP TO FOLD" : "TAP TO OPEN"}
            </button>
            {showRed ? <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">{reds.map((b) => [Col({ book: b.book, title: `${b.i + 1}. ${b.title}`, note: b.note, s: b.s }), Inline({ book: b.book })])}</div> : null}
          </div>
        );
      })()}
      <button
        type="button"
        onClick={() => {
          setPick(pick === "origClean" ? "all" : "origClean");
          setLimit(40);
        }}
        className="mt-3 flex w-full flex-col gap-1 rounded-2xl border px-4 py-3 text-left"
        style={{ borderColor: pick === "origClean" ? SHIFT_UP : "rgba(255,255,255,0.35)", boxShadow: `0 0 18px ${SHIFT_UP}33` }}
      >
        <p className="text-[10px] tracking-[0.26em] text-white">ORIGINAL ✦ WITHOUT BAND ERRORS · WHOLE RECORD</p>
        <p className="text-[9px] leading-snug text-white/55">Every ORIGINAL trade except the ones her own notes flagged: a line right above a long or right below a short. This is her with the DNA.</p>
        <div className="mt-1 flex flex-wrap items-baseline gap-x-4 gap-y-1">
          <p className="font-mono text-2xl tabular-nums" style={{ color: clean.pnl >= 0 ? SHIFT_UP : SHIFT_DOWN, textShadow: `0 0 10px ${clean.pnl >= 0 ? SHIFT_UP : SHIFT_DOWN}` }}>{shiftMoney(clean.pnl)}</p>
          <p className="font-mono text-[11px] tabular-nums text-white/80">{clean.wins}W · {clean.losses}L{clean.n ? ` · ${Math.round((clean.wins / clean.n) * 100)}% wins` : ""}</p>
        </div>
        <p className="font-mono text-[10px] tabular-nums text-white/60">
          ALL ORIGINAL {shiftMoney(allO.pnl)} ({allO.wins}W · {allO.losses}L) · BAND ERRORS {shiftMoney(errs.pnl)} ({errs.wins}W · {errs.losses}L)
        </p>
        <p className="text-[9px] tracking-[0.18em] text-white/45">{pick === "origClean" ? "SHOWING HER CLEAN TRADES · TAP FOR ALL" : "TAP FOR HER CLEAN TRADES"}</p>
      </button>
      {/* PILL LAYOUT (Love, Oct 11 ~5:40 AM PT: "separate these into a cleaner layout with the same divisions... best, mean,
          below mean etc... thin glowing white line between them, vertical, two next to each other in clean rows... they're
          hard to find"). Same BEST / MEAN / BELOW MEAN / WORST split as the cards (same ranking, same family / find filter),
          two pills per row with a thin glowing white line between them. Counts are all-time (night rows + exit ledger). */}
      <div className="mt-4 flex flex-wrap gap-1.5">
        {chip("all", `ALL · ${sumQ.data?.counts?.all ?? 0}`)}
        {chip("origClean", `ORIG ✦ CLEAN · ${sumQ.data?.counts?.origClean ?? 0}`)}
        {chip("diamond25", `DIAMOND 25% · ${sumQ.data?.counts?.diamond25 ?? 0}`)}
        {chip("taps", `TAPS ◌ · ${sumQ.data?.counts?.taps ?? 0}`)}
      </div>
      {[0, 1, 2, 3].map((tier) => {
        const size = Math.ceil(ranked.length / 4);
        const inTier = ranked.slice(tier * size, (tier + 1) * size).filter(famOk);
        if (!inTier.length) return null;
        const cnt = (book: string) => sumQ.data?.books?.[book]?.cnt ?? 0;
        const pairs: (typeof inTier)[] = [];
        for (let k = 0; k < inTier.length; k += 2) pairs.push(inTier.slice(k, k + 2));
        const col = tier === 0 ? "#3ddc84" : tier === 3 ? "#ff5c5c" : "rgba(255,255,255,0.7)";
        return (
          <div key={`pills${tier}`} className="mt-3">
            <p className="mb-1.5 text-[9px] tracking-[0.28em]" style={{ color: col, textShadow: `0 0 8px ${col}` }}>{["BEST", "MEAN", "BELOW MEAN", "WORST"][tier]}</p>
            <div className="grid items-center gap-y-1.5" style={{ gridTemplateColumns: "minmax(0,1fr) 1px minmax(0,1fr)", columnGap: "10px" }}>
              {pairs.map((pr) => [
                <div key={`${pr[0].book}-l`} className="min-w-0">{chip(pr[0].book, `${LABEL[pr[0].book] ?? pr[0].title} · ${cnt(pr[0].book)}`, true)}</div>,
                <div key={`${pr[0].book}-bar`} className="h-full min-h-[22px] w-px self-stretch" style={{ background: "rgba(255,255,255,0.9)", boxShadow: "0 0 6px rgba(255,255,255,0.85), 0 0 12px rgba(255,255,255,0.35)" }} />,
                <div key={`${pr[0].book}-r`} className="min-w-0">{pr[1] ? chip(pr[1].book, `${LABEL[pr[1].book] ?? pr[1].title} · ${cnt(pr[1].book)}`, true) : null}</div>,
              ])}
            </div>
          </div>
        );
      })}
      {pick === "taps" || isTap(pick) ? (
        <div className="mt-3 flex flex-col gap-2">
          <p className="text-[9px] tracking-[0.22em] text-white/50">TAPS · THEIR OWN TAB · $2.50 BAND-TOUCH TICKETS + $5 RESCUE ADDS · NEVER COUNTED IN THE LEDGERS ABOVE</p>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
            {tapRanked.map((b) => (
              Col({ book: b.book, title: b.title, note: b.note, s: b.s })
            ))}
          </div>
        </div>
      ) : null}
      {rec ? (
        <p className="mt-2 font-mono text-[11px] tabular-nums text-white/80">
          {LABEL[pick as string]} WHOLE RECORD{rec.from !== "9999" ? ` SINCE ${shiftClock(rec.from)}` : ""} ·{" "}
          <span style={{ color: rec.pnl >= 0 ? SHIFT_UP : SHIFT_DOWN }}>{shiftMoney(rec.pnl)}</span> · {rec.wins}W · {rec.losses}L
        </p>
      ) : null}
      <div className="mt-3 rounded-2xl border border-white/25 px-4 py-2">
        <div className="flex items-center gap-2">
          <p className="text-[10px] tracking-[0.2em] text-white" style={{ textShadow: "0 0 6px rgba(255,255,255,0.35)" }}>TAKE PROFIT AT</p>
          <input
            value={tryPct}
            onChange={(e) => setTryPct(e.target.value.replace(/[^0-9.]/g, ""))}
            inputMode="decimal"
            placeholder="40"
            className="w-16 rounded-md border border-white/40 bg-transparent px-2 py-0.5 text-right font-mono text-[12px] text-white outline-none"
          />
          <button
            type="button"
            onClick={() => setOfMax((v) => !v)}
            className="rounded-md border border-white/60 px-2 py-0.5 text-[9px] tracking-[0.18em] text-white"
          >
            {ofMax ? "% OF THE MAX" : "% PROFIT"} · TAP TO SWITCH
          </button>
          {/* what-if only (Love: "I just wanted to see how the trades looked closing at different numbers") */}
        </div>
        <p className="mt-1 text-[9px] tracking-[0.16em] text-white/60">
          WHAT-IF ONLY · THE BOOKS KEEP THEIR OWN EXITS{paperTp ? ` (PAPER OVERRIDE +${paperTp}%)` : ""} · SOLD EARLY SO FAR: {soldEarly.length}, AND {soldWouldWin} OF THEM WOULD HAVE WON AT THE BELL
        </p>
        {tpOk ? (
          <p className="mt-1.5 font-mono text-[11px] leading-snug tabular-nums text-white/85">
            {reached.length} of {able.length} winners that can pay {ofMax ? `${tp}% of their max` : `+${tp}%`} got there ({able.length ? Math.round((reached.length / able.length) * 100) : 0}%){cant ? ` · ${cant} winners max out below +${tp}%, left out` : ""} · {savedRed.length} losers also got there and would have been saved ·
            {" "}at {ofMax ? `${tp}% of the max` : `+${tp}%`} (bell for the rest): <span style={{ color: atTp >= 0 ? SHIFT_UP : SHIFT_DOWN }}>{shiftMoney(atTp)}</span> vs actual{" "}
            <span style={{ color: actual >= 0 ? SHIFT_UP : SHIFT_DOWN }}>{shiftMoney(actual)}</span>
          </p>
        ) : null}
        {tpOk ? (
          <p className="mt-1 font-mono text-[11px] leading-snug tabular-nums text-white/85">
            <span className="tracking-[0.16em] text-white/60">WITH YOUR NET · </span>
            line {ofMax ? `${netT}% of max` : `+${tp}%`}, catches at {ofMax ? `${Math.max(0, netT - 15)}% / ${Math.max(0, netT - 10)}% of max` : "line −15 / −10 (of max)"}: ended{" "}
            <span style={{ color: withNet >= 0 ? SHIFT_UP : SHIFT_DOWN }}>{shiftMoney(withNet)}</span> · the net caught {netCaught} that almost made it
            {" "}({shiftMoney(withNet - atTp)} vs no net)
          </p>
        ) : null}
        {tpOk ? null : (
          <p className="mt-1.5 text-[9px] tracking-[0.16em] text-white/50">TYPE A PERCENT: EVERY TRADE THAT PEAKED THERE GETS A ✓, AND YOU SEE WHAT SELLING THERE WOULD HAVE MADE</p>
        )}
        {done.length > 0 && sweep.best ? (
          <div className="mt-2 border-t border-white/10 pt-2">
            <button type="button" onClick={() => setTryPct(String(sweep.best.t))} className="w-full text-left">
              <p className="font-mono text-[11px] leading-snug tabular-nums text-white/90">
                <span className="tracking-[0.16em] text-white/60">SWEET SPOT · </span>
                {ofMax ? `${sweep.best.t}% OF THE MAX` : `+${sweep.best.t}%`}{" "}→{" "}
                <span style={{ color: sweep.best.total >= 0 ? SHIFT_UP : SHIFT_DOWN }}>{shiftMoney(sweep.best.total)}</span>
                {" "}· gives up {shiftMoney(sweep.best.gaveUp)} on winners · saves {shiftMoney(sweep.best.saved)} on losers · hold to the bell{" "}
                <span style={{ color: sweep.bell >= 0 ? SHIFT_UP : SHIFT_DOWN }}>{shiftMoney(sweep.bell)}</span> · actual{" "}
                <span style={{ color: actual >= 0 ? SHIFT_UP : SHIFT_DOWN }}>{shiftMoney(actual)}</span>
              </p>
              <div className="mt-1.5 flex h-6 items-end gap-[2px]">
                {sweep.rows.map((x) => {
                  const span = sweep.hi - sweep.lo || 1;
                  const h = Math.max(2, Math.round((Math.abs(x.total) / span) * 24));
                  const isBest = x.t === sweep.best.t, isNow = tpOk && x.t === tp;
                  return (
                    <span
                      key={x.t}
                      title={`${ofMax ? `${x.t}% of max` : `+${x.t}%`}: ${shiftMoney(x.total)}`}
                      className="flex-1 rounded-[1px]"
                      style={{ height: h, background: x.total >= 0 ? SHIFT_UP : SHIFT_DOWN, opacity: isBest ? 1 : isNow ? 0.85 : 0.4, outline: isBest ? "1px solid rgba(255,255,255,0.78)" : undefined }}
                    />
                  );
                })}
              </div>
              <p className="mt-1 text-[9px] tracking-[0.16em] text-white/50">
                EVERY LEVEL {ofMax ? "30–100% OF MAX" : "+10–200%"} TESTED ON {done.length} TRADES · BRIGHT BAR = BEST · TAP TO LOAD IT INTO THE BOX
              </p>
            </button>
            {pathQ.data && pathQ.data.n > 0 ? (
              <div className="mt-2 font-mono text-[10.5px] leading-snug tabular-nums text-white/85">
                <p className="text-[9px] tracking-[0.16em] text-white/60">
                  REAL KALSHI PATHS · {pathQ.data.n} TRADES · NET = LINE −{pathQ.data.netBelow.join(" / −")} OF MAX{pathQ.data.netLive ? " (LIVE NOW)" : ""} · WHIPSAWS COUNT
                </p>
                {[pathTyped ? { label: "YOURS", x: pathTyped } : null, pathBest ? { label: "BEST", x: pathBest } : null]
                  .filter((v): v is { label: string; x: NonNullable<typeof pathBest> } => !!v && !!v.x)
                  .map(({ label, x }) => (
                    <p key={label} className="mt-1">
                      <span className="text-white/60">{label} {ofMax ? `${x.t}% OF MAX` : `+${x.t}%`} · </span>
                      no net <span style={{ color: x.none.total >= 0 ? SHIFT_UP : SHIFT_DOWN }}>{shiftMoney(x.none.total)}</span>, gives up {shiftMoney(x.none.gaveUp)} on winners
                      {" "}· with net <span style={{ color: x.net.total >= 0 ? SHIFT_UP : SHIFT_DOWN }}>{shiftMoney(x.net.total)}</span>, gives up {shiftMoney(x.net.gaveUp)} on winners, saves {shiftMoney(x.net.saved)} on {x.net.soldL} losers, sold {x.net.soldW} winners early
                    </p>
                  ))}
              </div>
            ) : pathQ.isFetching ? (
              <p className="mt-2 text-[9px] tracking-[0.16em] text-white/50">REPLAYING ON REAL KALSHI PATHS…</p>
            ) : null}
          </div>
        ) : null}
      </div>
      {tod.length ? (
        <details className="mt-3 rounded-2xl border border-white/15 px-3 py-2">
          <summary className="cursor-pointer list-none text-[10px] tracking-[0.2em] text-white/80">BOOKS BY TIME OF DAY · PT · TAP TO OPEN</summary>
          <div className="mt-2 overflow-x-auto">
            <table className="w-full font-mono text-[9px] tabular-nums text-white">
              <thead>
                <tr className="text-white/50">
                  <th className="pr-2 text-left font-normal">BOOK</th>
                  {BLOCKS.map((b) => <th key={b} className="px-1 text-right font-normal">{b}</th>)}
                </tr>
              </thead>
              <tbody>
                {tod.map((row) => {
                  const best = row.b.reduce((bi, c, i, arr) => (c.n >= 2 && (bi < 0 || c.p > arr[bi].p) ? i : bi), -1);
                  return (
                    <tr key={row.book}>
                      <td className="whitespace-nowrap pr-2 text-left text-white/80">{LABEL[row.book] ?? row.book.toUpperCase()}</td>
                      {row.b.map((c, i) => (
                        <td key={i} className="px-1 text-right" style={{ color: c.n ? (c.p >= 0 ? SHIFT_UP : SHIFT_DOWN) : "rgba(255,255,255,0.25)", fontWeight: i === best ? 700 : 400 }}>
                          {c.n ? <>{c.p >= 0 ? "+" : "−"}{Math.abs(Math.round(c.p))}<span className="text-white/40"> {c.w}/{c.n}</span></> : "·"}
                        </td>
                      ))}
                    </tr>
                  );
                })}
              </tbody>
            </table>
            <p className="mt-1 text-[9px] tracking-[0.12em] text-white/50">$ P&L · WINS/TRADES · BOLD = THAT BOOK'S BEST BLOCK (2+ TRADES)</p>
          </div>
        </details>
      ) : null}
      {pick === "brk" ? (
        <div className="mt-3 rounded-2xl border border-white/15 px-3 py-2">
          <p className="text-[10px] tracking-[0.2em] text-white/80">BREAK EXIT · LEARNING</p>
          {brkLearn.n ? (
            <>
              <p className="mt-1 font-mono text-[11px] tabular-nums text-white">
                {brkLearn.right} of {brkLearn.n} exits were right · <span style={{ color: brkLearn.net >= 0 ? SHIFT_UP : SHIFT_DOWN }}>{shiftMoney(brkLearn.net)}</span> vs holding every one to the bell
              </p>
              {brkLearn.lessons.length ? brkLearn.lessons.map((l, i) => (
                <p key={i} className="mt-1 font-mono text-[10px] leading-snug" style={{ color: l.good ? SHIFT_UP : SHIFT_DOWN }}>{l.t}</p>
              )) : <p className="mt-1 text-[9px] tracking-[0.12em] text-white/50">LESSONS APPEAR ONCE A KIND OF EXIT HAS 5+ GRADED SALES</p>}
              <details className="mt-1">
                <summary className="cursor-pointer list-none text-[9px] tracking-[0.16em] text-white/50">EVERY SPLIT</summary>
                {brkLearn.all.map((b) => (
                  <p key={b.k} className="font-mono text-[10px] tabular-nums text-white/80">
                    {b.k}: {b.right}/{b.n} right · <span style={{ color: b.diff >= 0 ? SHIFT_UP : SHIFT_DOWN }}>{shiftMoney(b.diff)}</span>
                  </p>
                ))}
              </details>
            </>
          ) : (
            <p className="mt-1 text-[9px] tracking-[0.12em] text-white/50">GRADES LAND AS KALSHI SETTLES EACH WINDOW</p>
          )}
        </div>
      ) : null}
      <div className="mt-3 flex flex-col gap-1.5">
        {list.slice(0, limit).map((r) => {
          const c = r.pnl == null ? "#ffffff" : r.pnl >= 0 ? SHIFT_UP : SHIFT_DOWN;
          return (
            <details key={r.id} className="group rounded-2xl border border-white/15 px-4 py-1.5">
              <summary className="flex cursor-pointer list-none items-start justify-between gap-3">
                <span className="flex min-w-0 flex-col gap-0.5 text-[10px] tracking-[0.14em] text-white" style={{ textShadow: "0 0 6px rgba(255,255,255,0.35)" }}>
                  <span>{shiftClock(r.at)} · {LABEL[r.book] ?? r.book.toUpperCase()} · {r.asset.toUpperCase()} {r.side === "up" ? "LONG" : "SHORT"} · {Number(r.multiple).toFixed(2)}x{r.notes ? " · NOTES" : ""}</span>
                  <span className="whitespace-normal font-mono text-[10px] tracking-[0.06em] text-white/80">MAX +{Math.round((Number(r.multiple) - 1) * 100)}% ({shiftMoney(r.stake * (Number(r.multiple) - 1))}) · PEAK {r.peakPct > 0 ? "+" : ""}{Math.round(r.peakPct ?? 0)}%{r.result !== "open" && soldPct(r) != null ? ` · SOLD ${soldPct(r)! > 0 ? "+" : ""}${soldPct(r)}%` : ""}{tpOk && isWinner(r) && canReach(r) && hit(r) ? ` · ✓ ${ofMax ? `${tp}% OF MAX` : `${tp}%`}` : ""}{tpOk && isWinner(r) && !canReach(r) ? ` · CAN'T PAY +${tp}%` : ""}</span>
                  {ended(r) ? (
                    <span className="whitespace-normal font-mono text-[10px] tracking-[0.06em] text-white/90">
                      {ended(r)!.text}
                    </span>
                  ) : null}
                  {tpOk && r.result !== "open" ? (
                    <span className="whitespace-normal font-mono text-[10px] tracking-[0.06em]" style={{ color: atX(r).pnl >= 0 ? SHIFT_UP : SHIFT_DOWN }}>
                      AT {ofMax ? `${tp}% OF MAX (+${Math.round(lvl(r))}%)` : `+${tp}%`}: {atX(r).how} · {shiftMoney(atX(r).pnl)}
                    </span>
                  ) : null}
                </span>
                <span className="shrink-0 font-mono text-[11px] tabular-nums" style={{ color: c }}>
                  {r.result === "open" ? (windowDone(r.ticker ?? "") ? "CLOSED · SETTLING" : `OPEN · PEAK ${r.peakPct > 0 ? "+" : ""}${r.peakPct}%`) : shiftMoney(r.pnl ?? 0)}
                </span>
              </summary>
              <div className="mt-1.5 flex flex-col gap-1 pb-1 text-[11px] leading-snug">
                {r.exit ? <p className="text-white/60">{r.setup} · {r.exit}</p> : <p className="text-white/60">{r.setup}</p>}
                {(r.notes?.worked ?? []).map((t, i) => <p key={`w${i}`} style={{ color: SHIFT_UP }}>✓ {t}</p>)}
                {(r.notes?.better ?? []).map((t, i) => <p key={`b${i}`} style={{ color: SHIFT_DOWN }}>△ {t}</p>)}
                {(r.notes?.keep ?? []).map((t, i) => <p key={`k${i}`} className="text-white/80">→ {t}</p>)}
                {!r.notes && r.result !== "open" ? <p className="text-white/50">Review lands once Kalshi settles the window.</p> : null}
              </div>
            </details>
          );
        })}
        {list.length > limit ? (
          <div className="flex gap-2 pt-1">
            <button type="button" onClick={() => setLimit((n) => n + 60)} className="flex-1 rounded-2xl border border-white/25 py-2 text-[10px] tracking-[0.22em] text-white/80">
              SHOW 60 MORE · {list.length - limit} LEFT
            </button>
            <button type="button" onClick={() => setLimit(list.length)} className="flex-1 rounded-2xl border border-white/25 py-2 text-[10px] tracking-[0.22em] text-white/80">
              SHOW ALL {list.length}
            </button>
          </div>
        ) : null}
        {!list.length ? <p className="py-2 text-center text-[10px] tracking-[0.22em] text-white/55">{pick === "all" ? "TAP A CARD TO LOAD ITS TRADES" : rowsQ.isLoading ? "LOADING ITS TRADES…" : "WAITING FOR THE NEXT SETUP"}</p> : null}
      </div>
    </section>
  );
}

type ClaudeBtRow = { ticker: string; at: string; asset: string; side: string; setup: string; multiple: number; hourPT: number; claude: boolean; why: string | null; claudePnl: number | null; claudeExit: string | null; newPnl: number | null; newExit: string | null; origPnl: number | null; bell: string | null; cat: string };
type ClaudeBt = { at: string; night: ClaudeBtRow[]; week: { half: string; group: string; n: number; winPct: number; roiPct: number; pnl10: number }[] } | null;

// CLAUDE BACKTEST: which setups CLAUDE would have taken that the others didn't (and the reverse).
function ClaudeBacktestCard({ bt: btIn, scale = 1 }: { bt: ClaudeBt; scale?: number }) {
  const bt = useMemo(
    () => (btIn ? { ...btIn, night: btIn.night.map((r) => ({ ...r, claudePnl: r.claudePnl == null ? null : r.claudePnl * scale, newPnl: r.newPnl == null ? null : r.newPnl * scale, origPnl: r.origPnl == null ? null : r.origPnl * scale })), week: btIn.week.map((w) => ({ ...w, pnl10: w.pnl10 * scale })) } : null),
    [btIn, scale],
  );
  const [cat, setCat] = useState<"claude-only" | "both" | "others-only" | "all">("claude-only");
  const [limit, setLimit] = useState(30);
  if (!bt) return null;
  const sum = (xs: ClaudeBtRow[], k: "claudePnl" | "newPnl" | "origPnl") => xs.reduce((t, r) => t + (Number(r[k]) || 0), 0);
  const by = (c: string) => bt.night.filter((r) => r.cat === c);
  const took = bt.night.filter((r) => r.claude);
  const tiles = [
    { c: "claude-only", title: "ONLY CLAUDE TOOK", xs: by("claude-only"), main: "claudePnl" as const, sub: "NEW didn't take these" },
    { c: "both", title: "CLAUDE + NEW BOTH TOOK", xs: by("both"), main: "claudePnl" as const, sub: `NEW made ${shiftMoney(sum(by("both"), "newPnl"))} on the same trades` },
    { c: "others-only", title: "CLAUDE PASSED", xs: by("others-only"), main: "newPnl" as const, sub: `what NEW made on them · ORIGINAL ${shiftMoney(sum(by("others-only"), "origPnl"))}` },
  ];
  const list = cat === "all" ? bt.night : bt.night.filter((r) => r.cat === cat);
  const money = (v: number | null) => (v == null ? "—" : shiftMoney(v));
  const col = (v: number | null) => (v == null ? "rgba(255,255,255,0.45)" : v >= 0 ? SHIFT_UP : SHIFT_DOWN);
  return (
    <section className="rounded-[22px] border border-white/25 px-5 py-4 shadow-[0_0_18px_rgba(255,255,255,0.06)]">
      <div className="flex items-baseline justify-between gap-3">
        <p className="text-[10px] tracking-[0.28em] text-white/90">CLAUDE ✦ BACKTEST</p>
        <p className="text-[9px] tracking-[0.2em] text-white/50">AS OF {shiftClock(bt.at)}</p>
      </div>
      <p className="mt-1 text-[10px] leading-snug text-white/55">
        Every setup since the night book began, replayed with CLAUDE's list and exits on the real Kalshi bid path. CLAUDE took {took.length} of {bt.night.length}:{" "}
        <span style={{ color: col(sum(took, "claudePnl")) }}>{shiftMoney(sum(took, "claudePnl"))}</span>.
      </p>
      <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-3">
        {tiles.map((t) => {
          const v = sum(t.xs, t.main);
          const on = cat === t.c;
          return (
            <button key={t.c} type="button" onClick={() => { setCat(on ? "all" : (t.c as typeof cat)); setLimit(30); }} className="flex flex-col gap-1 rounded-2xl border px-4 py-3 text-left" style={{ borderColor: on ? col(v) : "rgba(255,255,255,0.2)" }}>
              <p className="text-[10px] tracking-[0.22em] text-white">{t.title} · {t.xs.length}</p>
              <p className="font-mono text-xl tabular-nums" style={{ color: col(v), textShadow: `0 0 10px ${col(v)}` }}>{shiftMoney(v)}</p>
              <p className="text-[9px] leading-snug text-white/55">{t.sub}</p>
            </button>
          );
        })}
      </div>
      <div className="mt-3 flex flex-col gap-1.5">
        {list.slice(0, limit).map((r) => (
          <details key={r.ticker} className="rounded-2xl border border-white/15 px-4 py-1.5">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-3">
              <span className="truncate text-[10px] tracking-[0.14em] text-white/85">
                {shiftClock(r.at)} · {r.asset.toUpperCase()} {r.side === "up" ? "LONG" : "SHORT"} · {Number(r.multiple).toFixed(2)}x · {r.claude ? "CLAUDE ✓" : "CLAUDE ✕"}
              </span>
              <span className="shrink-0 font-mono text-[11px] tabular-nums">
                <span style={{ color: col(r.claudePnl) }}>C {money(r.claudePnl)}</span> · <span style={{ color: col(r.newPnl) }}>N {money(r.newPnl)}</span>
              </span>
            </summary>
            <div className="mt-1.5 flex flex-col gap-1 pb-1 text-[11px] leading-snug text-white/70">
              <p>{r.setup} · {(Number(r.hourPT) % 12) || 12} {Number(r.hourPT) < 12 ? "AM" : "PM"} PT · bell {r.bell === "yes" ? "UP" : r.bell === "no" ? "DOWN" : "—"}</p>
              {r.claude ? <p style={{ color: SHIFT_UP }}>CLAUDE took it · {r.claudeExit}</p> : <p style={{ color: SHIFT_DOWN }}>CLAUDE passed: {r.why}</p>}
              <p>NEW {r.newPnl == null ? "didn't take it" : `${money(r.newPnl)} · ${r.newExit ?? ""}`} · ORIGINAL {money(r.origPnl)}</p>
            </div>
          </details>
        ))}
        {list.length > limit ? (
          <button type="button" onClick={() => setLimit(list.length)} className="rounded-2xl border border-white/25 py-2 text-[10px] tracking-[0.22em] text-white/80">SHOW ALL {list.length}</button>
        ) : null}
      </div>
      <p className="mt-4 text-[10px] tracking-[0.24em] text-white/80">THE WEEK · {bt.week.find((w) => w.group === "ALL") ? `SEP 24 – OCT 2 · $${Math.round(50 * scale)} A TRADE` : ""}</p>
      <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
        {["Sep 24-27", "Sep 28-Oct 2"].map((h) => (
          <div key={h} className="rounded-2xl border border-white/15 px-4 py-3">
            <p className="text-[10px] tracking-[0.22em] text-white/85">{h.toUpperCase()}</p>
            {bt.week.filter((w) => w.half === h).map((w) => (
              <p key={w.group} className="mt-1 flex justify-between font-mono text-[11px] tabular-nums text-white/80">
                <span>{w.group} · {w.n}</span>
                <span>{w.winPct}% W · <span style={{ color: col(w.pnl10) }}>{shiftMoney(w.pnl10)}</span></span>
              </p>
            ))}
          </div>
        ))}
      </div>
      <p className="mt-2 text-[9px] leading-snug text-white/45">
        The week is in-sample: CLAUDE's list was chosen from it. The replay leaves out gates / LOCK THE WIN (CLAUDE's only bank profit) and the path guard (rows don't keep the strike), so it reads a little conservative.
      </p>
    </section>
  );
}

type ShiftReview = { flags: string[]; lessons: string[]; exit: string; peakPct: number | null; takeProfitPct: number; record: string };
type ShiftMonitor = { status: { modelOk?: boolean; changed?: string[]; approvedAt?: string | null; notes?: string[] }; reviews: Record<string, ShiftReview> };

type ShiftRules = { lockWin: { on: boolean; arm: number; floor: number }; channelRule: boolean; channelEdge: number; blockedSetups: string[]; blockedAssets?: string[]; tpGates?: boolean; model?: string };

function RuleChip({ on, label, detail, onClick }: { on: boolean; label: string; detail: string; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="flex flex-1 flex-col items-start gap-1 rounded-2xl border px-4 py-3 text-left transition-shadow" style={{ borderColor: on ? SHIFT_UP : "rgba(255,255,255,0.25)", boxShadow: on ? `0 0 14px rgba(61,220,132,0.18)` : "none" }}>
      <span className="text-[10px] tracking-[0.24em]" style={{ color: on ? SHIFT_UP : "rgba(255,255,255,0.7)" }}>{label} · {on ? "ON" : "OFF"}</span>
      <span className="text-[10px] leading-snug text-white/60">{detail}</span>
    </button>
  );
}

export function ShiftBook({ fills, start, held, shadow = [], lotto = [], night = [], bt = null, paperStake = 50, whatIf, truth = null, monitor, rules, onRule, tapes, look: lookIn, card }: { card?: (asset: AssetId) => ReactNode; tapes?: Partial<Record<AssetId, { spark: number[]; spot: number; target: number | null; closeTime?: string }>>; look?: Look; fills: ShiftFill[]; start?: string | null; held: ShiftHeld[]; shadow?: ShiftShadow[]; lotto?: ShiftLotto[]; night?: ShiftNight[]; bt?: ClaudeBt; paperStake?: number; whatIf?: number; truth?: { at: string | null; rows: (ShiftRow & { exit?: string; manual?: number; fees?: number })[]; open: string[] } | null; monitor?: ShiftMonitor; rules?: ShiftRules; onRule?: (patch: { lockOn?: boolean; channelOn?: boolean; gatesOn?: boolean; asset?: "btc" | "gold" | "silver"; assetOn?: boolean; model?: "original" | "new" }) => void }) {
  const from = start || "2026-10-02T01:58:00.000Z";
  const real = Boolean(truth?.rows?.length);
  // CLOSES: this shift, or every Kalshi window on record (Love: "the full history").
  const [allCloses, setAllCloses] = useState(false);
  const [closeLimit, setCloseLimit] = useState(60);
  const rows = useShiftMemo<ShiftRow[]>(() => {
    // Kalshi truth first: every window rebuilt from Kalshi's own fills + settlements, fees included.
    if (truth?.rows?.length) return truth.rows.filter((r) => r.at >= from).map((r) => ({ ...r }));
    const byTicker = new Map<string, ShiftRow>();
    for (const e of fills) {
      if (e.venue !== "kalshi" || e.kind !== "banked" || e.profit == null || e.at < from) continue;
      const cur = byTicker.get(e.ticker);
      if (cur) {
        cur.pnl += e.profit;
        continue;
      }
      byTicker.set(e.ticker, {
        ticker: e.ticker,
        at: e.at,
        asset: String(e.asset),
        side: String(e.side),
        setup: e.pattern || "",
        stake: Number(e.stake) || 0,
        multiple: Number(e.multiple) || 0,
        pnl: e.profit,
      });
    }
    return [...byTicker.values()].sort((a, b) => a.at.localeCompare(b.at));
  }, [fills, from, truth]);
  const s = useShiftMemo(() => {
    const wins = rows.filter((r) => r.pnl > 0.05);
    const losses = rows.filter((r) => r.pnl < -0.05);
    const pnl = rows.reduce((t, r) => t + r.pnl, 0);
    const avg = (xs: ShiftRow[]) => (xs.length ? xs.reduce((t, r) => t + r.pnl, 0) / xs.length : 0);
    const best = rows.reduce((b, r) => (r.pnl > b ? r.pnl : b), 0);
    const decided = wins.length + losses.length;
    return { pnl, wins: wins.length, losses: losses.length, hit: decided ? (wins.length / decided) * 100 : 0, decided, avgWin: avg(wins), avgLoss: avg(losses), best };
  }, [rows]);
  const pnlColor = s.pnl >= 0 ? SHIFT_UP : SHIFT_DOWN;

  return (
    <div className="flex flex-col gap-4">
      <section className="rounded-[22px] border border-white/30 px-5 pb-5 pt-4 shadow-[0_0_24px_rgba(255,255,255,0.07)]">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-[11px] tracking-[0.36em] text-white" style={shiftGlow("rgba(255,255,255,0.75)", 8)}>
              SHIFT
            </p>
            <p className="mt-1 text-[9px] tracking-[0.22em] text-white/60">
              SINCE {shiftClock(from)} · {shiftDay(from)} · {real ? "KALSHI TRUTH ✓ · FEES IN" : "KALSHI LIVE"}
            </p>
            {monitor?.status ? (
              <p
                className="mt-2 inline-flex rounded-full border px-2.5 py-0.5 text-[9px] tracking-[0.2em]"
                style={{ borderColor: monitor.status.modelOk ? SHIFT_UP : SHIFT_DOWN, color: monitor.status.modelOk ? SHIFT_UP : SHIFT_DOWN }}
                title={monitor.status.changed?.length ? `Changed: ${monitor.status.changed.join(", ")}` : "Every model file matches the approved fingerprint."}
              >
                {monitor.status.modelOk ? "MODEL ✓ APPROVED" : `MODEL CHANGED · ${(monitor.status.changed ?? []).join(", ")}`}
              </p>
            ) : null}
          </div>
          <p className="whitespace-nowrap font-mono text-[28px] leading-none tabular-nums sm:text-[34px]" style={{ color: pnlColor, ...shiftGlow(pnlColor, 14) }}>
            {shiftMoney(s.pnl)}
          </p>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <ShiftChip label="WINS" value={String(s.wins)} tone="up" />
          <ShiftChip label="LOSSES" value={String(s.losses)} tone="down" />
          <ShiftChip label="HIT RATE" value={s.decided ? `${s.hit.toFixed(0)}%` : "—"} />
          <ShiftChip label="AVG WIN" value={s.wins ? shiftMoney(s.avgWin) : "—"} tone="up" />
          <ShiftChip label="AVG LOSS" value={s.losses ? shiftMoney(s.avgLoss) : "—"} tone="down" />
          <ShiftChip label="BEST" value={s.best > 0 ? shiftMoney(s.best) : "—"} tone="up" />
        </div>
        <div className="mt-4">
          {rows.length ? (
            <ShiftCurve rows={rows} />
          ) : (
            <p className="py-10 text-center text-[10px] tracking-[0.24em] text-white/60">THE FIRST CLOSE DRAWS THE LINE</p>
          )}
        </div>
          {/* LIVE TAPE per open position (Love, Oct 4: "put that chart for whatever we have open positions on... under the chart on
              shift"). Her tape design on the smooth engine, one per open position, right under the SHIFT curve. */}
          {/* Nothing open (Love, Oct 4: "the chart with the animation isn't here on the shift tab"): the BTC card stays up so the
              tape is always on SHIFT; open positions take its place the moment one is on. */}
          {!held.length && card ? (
            <div className="mt-5">
              <p className="mb-2 text-[9px] tracking-[0.18em] text-white/70">NOTHING OPEN · WATCHING BTC</p>
              <div className="text-left">{card("btc")}</div>
            </div>
          ) : null}
          {held.length
            ? (["btc", "gold", "silver"] as AssetId[]).map((asset) => {
                const mine = held.filter((h) => (/GOLD/i.test(h.ticker) ? "gold" : /SILVER/i.test(h.ticker) ? "silver" : "btc") === asset);
                if (!mine.length) return null;
                const LIVE_BOOKS = ["brick", "cotc", "trend", "claude", "brickc", "sole5", "sole5v"];
                const BOOKNAME: Record<string, string> = { brick: "BRICK", brickc: "BRICK · CLEAN", cotc: "COTC", trend: "CLAUDE · TREND", claude: "CLAUDE", sole5: "5M SOLE", sole5v: "5M SOLE · VANTAGE" };
                const t = tapes?.[asset];
                const whole = card ? card(asset) : null;
                return (
                  <div key={`open-${asset}`} className="mt-5">
                    {mine.map((h) => {
                      const src = night.find((r) => r.ticker === h.ticker && LIVE_BOOKS.includes(r.book) && !r.dnaMode);
                      return (
                        <div key={`w-${h.ticker}`} className="mb-2 flex items-baseline justify-between gap-3">
                          <p className="text-[9px] tracking-[0.18em] text-white/70">
                            {asset.toUpperCase()} · {h.side === "up" ? "LONG" : "SHORT"} · WATCHING · {src ? `${BOOKNAME[src.book] ?? src.book.toUpperCase()} · ${src.setup}` : "YOUR TRADE"}
                          </p>
                          <p className="font-mono text-[11px] tabular-nums" style={{ color: h.profit >= 0 ? SHIFT_UP : SHIFT_DOWN }}>{shiftMoney(h.profit)}</p>
                        </div>
                      );
                    })}
                    {whole ? (
                      <div className="text-left">{whole}</div>
                    ) : t && t.spot > 0 ? (
                      <div className="overflow-hidden rounded-2xl border border-white/15">
                        <Sparkline spark={t.spark} target={mine[0].target ?? t.target} live={t.spot} asset={asset} closeTime={t.closeTime} look={lookIn ?? LOOK_DEFAULT} tapeId={`open-${asset}`} />
                      </div>
                    ) : null}
                  </div>
                );
              })
            : null}
      </section>

      {held.length ? (
        <section className="rounded-[22px] border border-[#6b1524] px-5 py-4 shadow-[0_0_20px_rgba(107,21,36,0.35)]">
          <p className="text-[10px] tracking-[0.28em] text-white/80">OPEN NOW</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {held.map((h) => {
              const c = h.profit >= 0 ? SHIFT_UP : SHIFT_DOWN;
              return (
                <div key={h.ticker} className="flex items-center gap-3 rounded-full border border-white/25 px-4 py-2">
                  <span className="text-[10px] tracking-[0.2em] text-white">
                    {h.name} {h.side === "up" ? "LONG" : "SHORT"}
                  </span>
                  <span className="font-mono text-xs tabular-nums text-white/70">${h.cost.toFixed(2)}</span>
                  <span className="font-mono text-xs tabular-nums" style={{ color: c, ...shiftGlow(c, 6) }}>
                    {shiftMoney(h.profit)}
                  </span>
                </div>
              );
            })}
          </div>
        </section>
      ) : null}

      {rules && onRule ? (
        <section className="flex flex-col gap-2">
          <p className="-mb-1 px-1 text-[9px] tracking-[0.26em] text-white/55">MODEL · ONE TAP TO SWITCH</p>
          <div className="flex gap-2">
            {([["new", "NEW · EVERYTHING FROM OCT 2"], ["original", "ORIGINAL · DEBUGGED BASELINE"]] as const).map(([m, label]) => {
              const on = (rules.model ?? "new") === m;
              return (
                <button
                  key={m}
                  type="button"
                  onClick={() => {
                    if (on) return;
                    if (!window.confirm(`Switch her to ${m === "new" ? "NEW (every rule from Oct 2)" : "the ORIGINAL debugged baseline"}? You can switch back anytime.`)) return;
                    onRule({ model: m });
                  }}
                  className="flex-1 rounded-full border px-4 py-2 text-[10px] tracking-[0.2em] transition-shadow"
                  style={{ borderColor: on ? "#B388FF" : "rgba(255,255,255,0.25)", color: on ? "#B388FF" : "rgba(255,255,255,0.7)", boxShadow: on ? "0 0 14px rgba(179,136,255,0.25)" : "none" }}
                >
                  {label}{on ? " · ACTIVE" : ""}
                </button>
              );
            })}
          </div>
        </section>
      ) : null}
      {rules && onRule ? (
        <p className="-mb-2 px-1 text-[9px] tracking-[0.26em] text-white/55">SYMBOLS · TAP TO TURN ON / OFF</p>
      ) : null}
      {rules && onRule ? (
        <section className="flex flex-wrap gap-2">
          {(["btc", "gold", "silver"] as const).map((a) => {
            const on = !(rules.blockedAssets ?? []).includes(a);
            return (
              <button
                key={a}
                type="button"
                onClick={() => onRule({ asset: a, assetOn: !on })}
                className="flex flex-1 items-center justify-center gap-2 rounded-full border px-4 py-2 text-[10px] tracking-[0.24em] transition-shadow"
                style={{ borderColor: on ? SHIFT_UP : SHIFT_DOWN, color: on ? SHIFT_UP : SHIFT_DOWN, boxShadow: on ? "0 0 12px rgba(61,220,132,0.18)" : "0 0 12px rgba(255,92,92,0.15)" }}
              >
                {a.toUpperCase()} · {on ? "TRADING" : "OFF"}
              </button>
            );
          })}
        </section>
      ) : null}

      {rules && onRule ? <BenchCard /> : null}

      {rules && onRule ? (
        <p className="-mb-2 px-1 text-[9px] tracking-[0.26em] text-white/55">EXIT RULES · APPLY TO EVERY SYMBOL</p>
      ) : null}
      {rules && onRule ? (
        <section className="flex flex-col gap-2 sm:flex-row">
          <RuleChip
            on={rules.tpGates !== false}
            label="TAKE PROFIT + GATES"
            detail="BTC + gold. Take profit +50% under 1.65x, 75% of the max at 1.65x+. Past it she rides and trails 1% under the best quote. Gates (+40% / 55% / 60% of max) and the lock only sell with a reason: gold within $1.50 of the target, BTC within $100, or a band rejection."
            onClick={() => onRule({ gatesOn: !(rules.tpGates !== false) })}
          />
          <RuleChip
            on={rules.lockWin.on}
            label="LOCK THE WIN (SAFETY NET)"
            detail={`BTC + gold. Last net under the gates: once a trade is up +${rules.lockWin.arm}%, she sells if it falls back to +${rules.lockWin.floor}% profit.`}
            onClick={() => onRule({ lockOn: !rules.lockWin.on })}
          />
          <RuleChip
            on={rules.channelRule}
            label="NO MID-CHANNEL"
            detail={`Longs only in the bottom ${Math.round(rules.channelEdge * 100)}% of a channel, shorts only in the top ${Math.round(rules.channelEdge * 100)}%. The middle is a coin flip.`}
            onClick={() => onRule({ channelOn: !rules.channelRule })}
          />
        </section>
      ) : null}

      {/* Love, Oct 8: "match the paper books to the amount we're doing on kalshi so i'm not fooling myself": every paper row
          is now booked at Kalshi's $30, so the cards show them as booked (no paper-size scaling). */}
      <NightCard rows={night} scale={1} size={30} whatIf={whatIf} />

      <ClaudeBacktestCard bt={bt} scale={(paperStake > 0 ? paperStake : 50) / 50} />

      <ShadowCard rows={shadow} />

      <LottoCard rows={lotto} />

      <section className="flex flex-col gap-2">
        <div className="flex items-center justify-between gap-2 px-1">
          <p className="text-[10px] tracking-[0.28em] text-white/80">CLOSES · {(allCloses && truth?.rows?.length ? truth.rows : rows).length}{allCloses ? " · ALL TIME" : " · THIS SHIFT"}</p>
          <button type="button" onClick={() => { setAllCloses((v) => !v); setCloseLimit(60); }} className="rounded-full border border-white/30 px-3 py-1 text-[9px] tracking-[0.2em] text-white/80">
            {allCloses ? "THIS SHIFT" : "FULL HISTORY"}
          </button>
        </div>
        {[...(allCloses && truth?.rows?.length ? (truth.rows as ShiftRow[]) : rows)].reverse().slice(0, closeLimit).map((r) => {
          const c = r.pnl >= 0 ? SHIFT_UP : SHIFT_DOWN;
          const sideColor = r.side === "up" ? SHIFT_UP : SHIFT_DOWN;
          return (
            <div key={r.ticker} className="rounded-2xl border border-white/20 px-4 py-3 transition-shadow hover:shadow-[0_0_16px_rgba(255,255,255,0.12)]">
            <div className="flex items-center justify-between gap-3">
              <div className="flex min-w-0 flex-col gap-1">
                <div className="flex items-center gap-2">
                  <span className="rounded-full border px-2 py-0.5 text-[9px] tracking-[0.2em]" style={{ borderColor: sideColor, color: sideColor }}>
                    {r.asset.toUpperCase()} {r.side === "up" ? "LONG" : "SHORT"}
                  </span>
                  <span className="text-[10px] tracking-[0.16em] text-white/60">{shiftClock(r.at)}</span>
                </div>
                <span className="truncate text-[11px] tracking-[0.08em] text-white/90">{r.setup.replace(/[a-z]/g, (c) => c.toUpperCase())}{(r as { exit?: string }).exit === "sold" ? " · SOLD EARLY" : ""}{(r as { manual?: number }).manual ? " · + OUTSIDE ORDER" : ""}</span>
              </div>
              <div className="flex shrink-0 flex-col items-end gap-1">
                <span className="font-mono text-base tabular-nums" style={{ color: c, ...shiftGlow(c, 8) }}>
                  {shiftMoney(r.pnl)}
                </span>
                <span className="font-mono text-[10px] tabular-nums text-white/55">
                  {r.multiple ? `${r.multiple.toFixed(2)}x · ` : ""}${r.stake.toFixed(2)}
                </span>
              </div>
            </div>
            {monitor?.reviews?.[r.ticker] ? (
              <div className="mt-2 flex flex-col gap-1 border-t border-white/10 pt-2">
                {monitor.reviews[r.ticker].flags.map((t, i) => (
                  <p key={`f${i}`} className="text-[11px] leading-snug" style={{ color: SHIFT_DOWN }}>FLAG · {t}</p>
                ))}
                {monitor.reviews[r.ticker].lessons.map((t, i) => (
                  <p key={`l${i}`} className="text-[11px] leading-snug text-white/75">{t}</p>
                ))}
                <p className="text-[9px] tracking-[0.18em] text-white/45">
                  {monitor.reviews[r.ticker].exit.toUpperCase()} · PEAK {monitor.reviews[r.ticker].peakPct != null ? `${(monitor.reviews[r.ticker].peakPct ?? 0) >= 0 ? "+" : "−"}${Math.abs(monitor.reviews[r.ticker].peakPct ?? 0)}%` : "—"} · RECORD {monitor.reviews[r.ticker].record}
                </p>
              </div>
            ) : null}
            </div>
          );
        })}
        {(allCloses && truth?.rows?.length ? truth.rows.length : rows.length) > closeLimit ? (
          <button type="button" onClick={() => setCloseLimit((n) => n + 120)} className="rounded-2xl border border-white/25 py-2 text-[10px] tracking-[0.22em] text-white/80">
            SHOW MORE · {(allCloses && truth?.rows?.length ? truth.rows.length : rows.length) - closeLimit} LEFT
          </button>
        ) : null}
      </section>
    </div>
  );
}


// ─── TRUTH BOOKS (Claude) ─────────────────────────────────────────────────────
// PAPER and PRIME, told from the real ledger, with what Kalshi actually did on the same trade.
type TruthFill = { at: string; kind: string; venue: string; ticker: string; side: string; asset: string; tradeId: string; stake: number; profit: number | null; pattern: string; multiple: number };

function kalshiByTrade(fills: TruthFill[]) {
  const live = new Map<string, number>();
  for (const r of fills) {
    if (r.venue !== "kalshi" || r.kind !== "banked" || r.profit == null) continue;
    const k = `${r.ticker}|${r.side}`;
    live.set(k, (live.get(k) ?? 0) + r.profit);
  }
  return live;
}

function TruthHeader({ title, sub, chips }: { title: string; sub: string; chips: { label: string; value: string; tone?: "up" | "down" }[] }) {
  return (
    <section className="rounded-[22px] border border-white/30 px-5 pb-4 pt-4 shadow-[0_0_24px_rgba(255,255,255,0.07)]">
      <p className="text-[11px] tracking-[0.32em] text-white" style={shiftGlow("rgba(255,255,255,0.7)", 8)}>{title}</p>
      <p className="mt-1 text-[9px] tracking-[0.2em] text-white/60">{sub}</p>
      <div className="mt-3 flex flex-wrap gap-2">
        {chips.map((c) => (
          <ShiftChip key={c.label} label={c.label} value={c.value} tone={c.tone} />
        ))}
      </div>
    </section>
  );
}

function TruthRow({ when, asset, side, setup, left, right, note }: { when: string; asset: string; side: string; setup: string; left: number | null; right: number | null | "none"; note?: string }) {
  const lc = left == null ? "#ffffff" : left >= 0 ? SHIFT_UP : SHIFT_DOWN;
  const rc = right === "none" || right == null ? "rgba(255,255,255,0.45)" : right >= 0 ? SHIFT_UP : SHIFT_DOWN;
  const sideColor = side === "up" ? SHIFT_UP : SHIFT_DOWN;
  return (
    <div className="flex items-center justify-between gap-3 rounded-2xl border border-white/15 px-4 py-2.5">
      <div className="flex min-w-0 flex-col gap-1">
        <div className="flex items-center gap-2">
          <span className="rounded-full border px-2 py-0.5 text-[9px] tracking-[0.2em]" style={{ borderColor: sideColor, color: sideColor }}>
            {asset.toUpperCase()} {side === "up" ? "LONG" : "SHORT"}
          </span>
          <span className="text-[10px] tracking-[0.14em] text-white/55">{when}</span>
        </div>
        <span className="truncate text-[11px] tracking-[0.06em] text-white/85">{setup.replace(/[a-z]/g, (c) => c.toUpperCase())}</span>
        {note ? <span className="text-[10px] text-white/50">{note}</span> : null}
      </div>
      <div className="flex shrink-0 flex-col items-end gap-0.5 font-mono tabular-nums">
        <span className="text-sm" style={{ color: lc }}>{left == null ? "—" : shiftMoney(left)}</span>
        <span className="text-[10px]" style={{ color: rc }}>
          {right === "none" ? "NOT SENT" : right == null ? "—" : `KALSHI ${shiftMoney(right)}`}
        </span>
      </div>
    </div>
  );
}

export function PaperTruth({ fills }: { fills: TruthFill[] }) {
  const [all, setAll] = useState(false);
  const live = useMemo(() => kalshiByTrade(fills), [fills]);
  const rows = useMemo(() => {
    const seen = new Set<string>();
    const out: TruthFill[] = [];
    for (const r of [...fills].sort((a, b) => b.at.localeCompare(a.at))) {
      if (r.venue !== "paper" || r.kind !== "banked" || r.profit == null || seen.has(r.tradeId)) continue;
      seen.add(r.tradeId);
      out.push(r);
    }
    return out;
  }, [fills]);
  const today = rows.filter((r) => Date.now() - Date.parse(r.at) < 24 * 3600e3);
  const w = today.filter((r) => (r.profit ?? 0) > 0).length;
  const l = today.filter((r) => (r.profit ?? 0) < 0).length;
  const pnl = today.reduce((t, r) => t + (r.profit ?? 0), 0);
  const both = today.filter((r) => live.has(`${r.ticker}|${r.side}`));
  const paperOnBoth = both.reduce((t, r) => t + (r.profit ?? 0), 0);
  const liveOnBoth = both.reduce((t, r) => t + (live.get(`${r.ticker}|${r.side}`) ?? 0), 0);
  return (
    <div className="flex flex-col gap-3">
      <TruthHeader
        title="PAPER · THE REAL LEDGER"
        sub="LAST 24 HOURS · EVERY TRADE, REAL STAKE, NOTHING HIDDEN"
        chips={[
          { label: "RECORD", value: `${w}-${l}` },
          { label: "PAPER P&L", value: shiftMoney(pnl), tone: pnl >= 0 ? "up" : "down" },
          { label: "ALSO ON KALSHI", value: String(both.length) },
          { label: "PAPER ON THOSE", value: shiftMoney(paperOnBoth), tone: paperOnBoth >= 0 ? "up" : "down" },
          { label: "KALSHI ON THOSE", value: shiftMoney(liveOnBoth), tone: liveOnBoth >= 0 ? "up" : "down" },
        ]}
      />
      <div className="flex flex-col gap-1.5">
        {(all ? rows : rows.slice(0, 12)).map((r) => {
          const k = `${r.ticker}|${r.side}`;
          return (
            <TruthRow
              key={r.tradeId}
              when={`${shiftClock(r.at)} · $${Number(r.stake).toFixed(0)} PAPER`}
              asset={r.asset}
              side={r.side}
              setup={r.pattern || ""}
              left={r.profit}
              right={live.has(k) ? (live.get(k) ?? 0) : "none"}
            />
          );
        })}
      </div>
      {rows.length > 12 ? (
        <button type="button" onClick={() => setAll((v) => !v)} className="self-center rounded-full border border-white/30 px-4 py-1.5 text-[10px] tracking-[0.22em] text-white/80">
          {all ? "SHOW LESS" : `SHOW ALL ${rows.length}`}
        </button>
      ) : null}
    </div>
  );
}

type TruthPrime = { id: string; at: string; asset: string; side: string; pattern: string; result: string; ticker?: string; multiple?: number; live?: string };

type TruthRecords = { honest: { yes: number; no: number }; forty: { yes: number; no: number }; fortyOn: boolean };

export function PrimeTruth({ rows, fills, records, onForty }: { rows: TruthPrime[]; fills: TruthFill[]; records?: TruthRecords; onForty: (on: boolean) => void }) {
  const [all, setAll] = useState(false);
  const live = useMemo(() => kalshiByTrade(fills), [fills]);
  const done = rows.filter((r) => r.result === "yes" || r.result === "no");
  const sent = done.filter((r) => r.ticker && live.has(`${r.ticker}|${r.side}`));
  const notSent = done.length - sent.length;
  const real = sent.reduce((t, r) => t + (live.get(`${r.ticker}|${r.side}`) ?? 0), 0);
  const realW = sent.filter((r) => (live.get(`${r.ticker}|${r.side}`) ?? 0) > 0).length;
  const call = done.filter((r) => r.result === "yes").length;
  return (
    <div className="flex flex-col gap-3">
      <TruthHeader
        title="PRIME BOOK · WHAT REALLY HAPPENED"
        sub="THE BOOK'S CALLS VS. YOUR KALSHI FILLS ON THE SAME WINDOW"
        chips={[
          { label: "BOOK CALLED RIGHT", value: done.length ? `${call}/${done.length}` : "—" },
          { label: "SENT TO KALSHI", value: String(sent.length) },
          { label: "NEVER SENT", value: String(notSent) },
          { label: "KALSHI RECORD", value: sent.length ? `${realW}-${sent.length - realW}` : "—" },
          { label: "KALSHI P&L", value: shiftMoney(real), tone: real >= 0 ? "up" : "down" },
        ]}
      />
      {records ? (
        <section className="rounded-[22px] border border-white/20 px-5 py-4">
          <div className="flex items-center justify-between gap-3">
            <p className="text-[10px] tracking-[0.28em] text-white/85">TWO WAYS TO SCORE THE BOOK</p>
            <button
              type="button"
              onClick={() => onForty(!records.fortyOn)}
              className="rounded-full border px-3 py-1 text-[9px] tracking-[0.2em]"
              style={{ borderColor: records.fortyOn ? SHIFT_UP : "rgba(255,255,255,0.35)", color: records.fortyOn ? SHIFT_UP : "rgba(255,255,255,0.75)" }}
              title="When on, the prime book approves setups using the 40% rule instead of the honest record."
            >
              40% RULE {records.fortyOn ? "ON" : "OFF"}
            </button>
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <ShiftChip label="HONEST BOOK" value={`${records.honest.yes}-${records.honest.no}`} />
            <ShiftChip label="HONEST HIT RATE" value={records.honest.yes + records.honest.no ? `${Math.round((records.honest.yes / (records.honest.yes + records.honest.no)) * 100)}%` : "—"} />
            <ShiftChip label="40% BOOK" value={`${records.forty.yes}-${records.forty.no}`} />
            <ShiftChip label="40% HIT RATE" value={records.forty.yes + records.forty.no ? `${Math.round((records.forty.yes / (records.forty.yes + records.forty.no)) * 100)}%` : "—"} />
          </div>
          <p className="mt-2 text-[10px] leading-snug text-white/55">
            Honest: a call counts only if it won at the bell. 40% book: a loser that was up 40% or more first also counts. The toggle decides which one approves setups.
          </p>
        </section>
      ) : null}
      <div className="flex flex-col gap-1.5">
        {(all ? done : done.slice(0, 12)).map((r) => {
          const k = `${r.ticker}|${r.side}`;
          return (
            <TruthRow
              key={r.id}
              when={`${shiftClock(r.at)} · BOOK SAID ${r.result.toUpperCase()}${r.multiple ? ` · ${Number(r.multiple).toFixed(2)}x` : ""}`}
              asset={r.asset}
              side={r.side}
              setup={r.pattern || ""}
              left={null}
              right={r.ticker && live.has(k) ? (live.get(k) ?? 0) : "none"}
            />
          );
        })}
      </div>
      {done.length > 12 ? (
        <button type="button" onClick={() => setAll((v) => !v)} className="self-center rounded-full border border-white/30 px-4 py-1.5 text-[10px] tracking-[0.22em] text-white/80">
          {all ? "SHOW LESS" : `SHOW ALL ${done.length}`}
        </button>
      ) : null}
    </div>
  );
}

// LINEUP MODE chips (Oct 13 ~3:25 AM PT, Love: "i want the model we were using to be able to be brought back at any time").
function LineupModeChips() {
  const q = useQuery({ queryKey: ["lineup-mode"], queryFn: () => getLineupMode(), refetchInterval: 60000 });
  const benchQ = useQuery({ queryKey: ["bench"], queryFn: () => getBench(), refetchInterval: 15000 });
  const [busy, setBusy] = useState(false);
  const [mode, bounce] = String((q.data as string) || "hybrid|on").split("|");
  const opts: [string, string, string][] = [
    ["hybrid", "HYBRID ✨", "trend assassin outside ±1σ of VWAP, both ways inside"],
    ["hybridc", "HYBRID ✓ CONFIRMED", "both ways inside; trend assassin only after 3 one-minute candles CLOSE outside ±1σ (no flip on a poke)"],
    ["allday", "TREND ASSASSIN 🗡️", "the one that ran all day: trades the side of VWAP price is on"],
    ["both", "BOTH WAYS", "both directions everywhere"],
  ];
  return (
    <div className="mb-2 flex flex-wrap items-center gap-1.5 px-1">
      <span className="text-[8px] tracking-[0.22em] text-white/50">HER MODEL</span>
      {opts.map(([k, label, tip]) => (
        <button key={k} type="button" title={tip} disabled={busy} onClick={async () => { if (k === mode) return; setBusy(true); try { await setLineupMode({ data: { mode: k } }); await q.refetch(); } finally { setBusy(false); } }}
          className="rounded-full px-2.5 py-0.5 font-mono text-[9px] tracking-[0.12em]"
          style={k === mode ? { border: "1px solid #3ddc84", color: "#000", background: "#3ddc84" } : { border: "1px solid rgba(255,255,255,0.3)", color: "rgba(255,255,255,0.7)" }}>
          {label}
        </button>
      ))}
      <span className="text-[8px] text-white/40">{opts.find(([k]) => k === mode)?.[2]}</span>
      {/* BREAKER (Oct 14 ~12:10 AM PT, Love: "take off the bench pls and allow me the ability to turn that on or off"):
          3 live losses in a row benches a book for 2 hours. Tap to turn the breaker off / on; tap a bench to lift it. */}
      {benchQ.data ? (
        <button type="button" disabled={busy} title="3 live losses in a row benches a book for 2 hours. Tap to turn it off / on."
          onClick={async () => { setBusy(true); try { await setBench({ data: { breakerOn: !(benchQ.data as any).breaker?.on } }); await benchQ.refetch(); } finally { setBusy(false); } }}
          className="rounded-full px-2.5 py-0.5 font-mono text-[9px] tracking-[0.12em]"
          style={(benchQ.data as any).breaker?.on ? { border: "1px solid #ff9f6b", color: "#ff9f6b" } : { border: "1px solid rgba(255,255,255,0.3)", color: "rgba(255,255,255,0.6)" }}>
          {(benchQ.data as any).breaker?.on ? "BREAKER ON" : "BREAKER OFF"}
        </button>
      ) : null}
      {Object.entries(((benchQ.data as any)?.benched ?? {}) as Record<string, { until: string }>).map(([bk, b]) => (
        <button key={bk} type="button" disabled={busy} title="Lift this bench now"
          onClick={async () => { setBusy(true); try { await setBench({ data: { book: bk, until: b.until } }); await benchQ.refetch(); } finally { setBusy(false); } }}
          className="rounded-full px-2.5 py-0.5 font-mono text-[9px] tracking-[0.12em]" style={{ border: "1px solid #ff5c5c", color: "#ff5c5c" }}>
          {bk.toUpperCase()} BENCHED TIL {new Date(b.until).toLocaleTimeString("en-US", { timeZone: "America/Los_Angeles", hour: "numeric", minute: "2-digit" })} · LIFT
        </button>
      ))}
      <button type="button" disabled={busy} title="ON: a bounce off a band is an entry and a rejection blocks the opposite trade. OFF: her plain band / break entries."
        onClick={async () => { setBusy(true); try { await setLineupMode({ data: { mode: bounce === "on" ? "bounce:off" : "bounce:on" } }); await q.refetch(); } finally { setBusy(false); } }}
        className="ml-auto rounded-full px-2.5 py-0.5 font-mono text-[9px] tracking-[0.12em]"
        style={bounce === "on" ? { border: "1px solid #ffd479", color: "#000", background: "#ffd479" } : { border: "1px solid rgba(255,255,255,0.3)", color: "rgba(255,255,255,0.7)" }}>
        {bounce === "on" ? "BOUNCE 🛡️ ON" : "BOUNCE OFF · PLAIN BREAKS"}
      </button>
    </div>
  );
}
